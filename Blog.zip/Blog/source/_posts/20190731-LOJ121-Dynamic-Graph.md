---
title: 「LOJ 121」动态图连通性（分治 + 并查集）
date: 2019-07-31 00:00:00
mathjax: true
tags:
	- 分治
	- 并查集
---

# 题目大意
[「LOJ 121」动态图连通性](https://loj.ac/problem/121)

给定一个 $n$ 个点的图和 $m$ 个操作。图一开始是空的，每次操作可以在图中加上一条边，删去一条边或者询问两个点是否连通。你要对于所有询问求出答案。

数据范围：$n \le 5 \times 10^3, m \le 5 \times 10^5$。

<!--more-->

# 思路分析
不知道这个 $n \le 5 \times 10^3$ 有什么用 \kel。

如果只有加边的话，我们可以直接使用并查集来做。如果带上删边，我们就可以使用按时间分治的技巧。具体地，我们将每条边出现的时间和被删除的时间处理出来，然后在时间的线段树上插入对应的区间。最后，我们 DFS 一遍线段树就可以求出所有答案了。

那么我们需要支持的操作就是连边和撤销上一次连边。发现并不需要可持久化，我们只需要可回退的并查集就行了。对于一次 merge 操作，我们将它的信息记录下来，撤销的时候再还原即可。注意我们不能路径压缩，所以需要启发式合并来优化。时间复杂度 $O(m \log^2 m)$，具体见代码。

# 代码实现
```cpp
#include <bits/stdc++.h>
#define ls (rt << 1)
#define rs (ls | 1)
#define mid ((l + r) >> 1)
using namespace std;

const int maxn = 5e5, maxm = 1 << 20;
int n, m, o[maxn + 3], u[maxn + 3], v[maxn + 3], fa[maxn + 3], sz[maxn + 3];
int top, st_u[maxn + 3], st_v[maxn + 3], st_o[maxn + 3], st_s[maxn + 3];
bool ans[maxn + 3];
vector<int> S[maxm + 3];
map<pair<int, int>, int> mp;

void modify(int rt, int l, int r, int lx, int rx, int x) {
	if (l >= lx && r <= rx) {
		S[rt].push_back(x);
		return;
	}
	if (lx <= mid) {
		modify(ls, l, mid, lx, rx, x);
	}
	if (rx > mid) {
		modify(rs, mid + 1, r, lx, rx, x);
	}
}

int find(int x) {
	return fa[x] == x ? x : find(fa[x]);
}

void merge(int u, int v) {
	u = find(u), v = find(v);
	if (sz[u] > sz[v]) {
		swap(u, v);
	}
	++top, st_u[top] = u, st_v[top] = v, st_o[top] = fa[u], st_s[top] = sz[u];
	if (u != v) {
		fa[u] = v, sz[v] += sz[u], sz[u] = 0;
	}
}

void split() {
	int u = st_u[top], v = st_v[top], o = st_o[top], s = st_s[top];
	if (u != v) {
		fa[u] = o, sz[v] -= s, sz[u] = s;
	}
	top--;
}

void insert(int x) {
	for (int i = 0; i < S[x].size(); i++) {
		merge(u[S[x][i]], v[S[x][i]]);
	}
}

void erase(int x) {
	for (int i = S[x].size() - 1; i >= 0; i--) {
		split();
	}
}

void solve(int rt, int l, int r) {
	insert(rt);
	if (l == r) {
		if (o[l] == 2) {
			ans[l] = find(u[l]) == find(v[l]);
		}
		erase(rt);
		return;
	}
	solve(ls, l, mid);
	solve(rs, mid + 1, r);
	erase(rt);
}

int main() {
	scanf("%d %d", &n, &m);
	for (int i = 1; i <= m; i++) {
		scanf("%d %d %d", &o[i], &u[i], &v[i]);
		if (u[i] > v[i]) {
			swap(u[i], v[i]);
		}
		if (!o[i]) {
			mp[make_pair(u[i], v[i])] = i;
		} else if (o[i] == 1) {
			modify(1, 1, m, mp[make_pair(u[i], v[i])], i - 1, i);
			mp[make_pair(u[i], v[i])] = 0;
		}
	}
	for (map<pair<int, int>, int>::iterator it = mp.begin(); it != mp.end(); it++) {
		if (it -> second) {
			modify(1, 1, m, it -> second, m, it -> second);
		}
	}
	for (int i = 1; i <= n; i++) {
		fa[i] = i, sz[i] = 1;
	}
	solve(1, 1, m);
	for (int i = 1; i <= m; i++) {
		if (o[i] == 2) {
			puts(ans[i] ? "Y" : "N");
		}
	}
	return 0;
}
```