---
title: 「专题选做」博弈论题目选做 1
date: 2019-12-02 00:00:00
mathjax: true
tags:
	- 专题选做
	- 字典树
	- 博弈论
	- 动态规划
---

# Candy Piles

[「AGC 002E」Candy Piles](https://agc002.contest.atcoder.jp/tasks/agc002_e)

## 题目大意

有 $n$ 个数，两人玩游戏，每次可以取最大的变 $0$ 或把所有的非零数减 $1$，把全部的数变 $0$ 的人会输，问是否先手必胜。

数据范围：$n \le 10^5$。

<!--more-->

## 思路分析

首先发现操作方法是对偶的，可以搞出一个二维 dp，打表发现对角线上的数是一样的，所以我们可以找到和 $(n, a[n])$ 同对角线的 $x$ 坐标最小的点算出 dp 值。时间复杂度 $O(n)$。

## 代码实现

```cpp
#include <bits/stdc++.h>
using namespace std;

const int maxn = 1e5;
int n, a[maxn + 3];

int main() {
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf("%d", &a[i]);
	}
	sort(a + 1, a + n + 1);
	int x = n, y = 1;
	while (x > 1 && y + 1 <= a[x - 1]) {
		x--, y++;
	}
	if (y > a[x - 1]) {
		puts((a[x] - y) & 1 ? "First" : "Second");
	} else {
		int p = (a[x] - y - 1) & 1, z = x - 1;
		while (z > 1 && a[z - 1] == a[z]) z--;
		int q = (x - 1 - z) & 1;
		puts(p && q ? "Second" : "First");
	}
	return 0;
}
```

# Paper-strip Game

[「PE 306」Paper-strip Game](https://projecteuler.net/problem=306)

## 题目描述

有长度为 $n$ 的纸带，两个人轮流操作，每次选相邻的两个白格染黑，不能操作者输。问对于所有 $n \le 10^6$ 的情况有多少种是先手必胜的。

## 思路分析

容易想到 $O(n^2)$ 算法，打表发现有循环节，直接计算即可。答案为 $852938$。

## 代码实现

```cpp
// 打表代码
#include <bits/stdc++.h>
using namespace std;

const int maxn = 1e6;
int n, sg[maxn + 3], m, a[maxn + 3];

int main() {
	scanf("%d", &n);
	sg[0] = 0;
	for (int i = 1; i <= n; i++) {
		m = 0;
		for (int j = 0; j <= i - 2; j++) {
			a[m++] = sg[j] ^ sg[i - 2 - j];
		}
		sort(a , a + m);
		m = unique(a, a + m) - a;
		a[m] = -1;
		for (int j = 0; j <= m; j++) {
			if (a[j] != j) {
				sg[i] = j;
				break;
			}
		}
	}
	for (int i = 1; i <= n; i++) {
		putchar(sg[i] ^ '0');
	}
	puts("");
	return 0;
}
```

# Combat on a Tree

[「SPOJ COT3」Combat on a Tree](https://www.spoj.com/problems/COT3/)

## 题目描述

给定一棵 $n$ 个点的树，每个点有黑白两种颜色。两个人玩游戏，每次可以选一个白点并把它和它的祖先全部变黑，不能操作的人输。问先手是否必胜以及先手必胜时第一步可以选哪些点。

数据范围：$n \le 10^5$。

## 思路分析

选一个点并染黑祖先可以看作把这个点到根的路径删除，分裂出若干个子问题。我们考虑对于每棵子树算出 sg 值，容易得到一个 $O(n^2)$ 的算法。考虑用 01-Trie 维护，我们只要支持单点加入，整体异或以及 Trie 合并，所以时间复杂度 $O(n \log n)$。

## 代码实现

```cpp
#include <bits/stdc++.h>
using namespace std;

const int maxn = 1e5, maxk = maxn * 2, logn = 16, maxm = maxn * (logn + 2);
int n, col[maxn + 3], dp[maxn + 3], f[maxn + 3], g[maxn + 3], rt[maxn + 3];
int tot, val[maxm + 3], ch[maxm + 3][logn + 3], tag[maxm + 3];
int cnt, ter[maxk + 3], nxt[maxk + 3], lnk[maxn + 3];
bool full[maxm + 3];

void add(int u, int v) {
	ter[++cnt] = v, nxt[cnt] = lnk[u], lnk[u] = cnt;
}

#define ls ch[x][0]
#define rs ch[x][1]

void maintain(int x) {
	if (val[x] == -1) {
		return;
	}
	full[x] = full[ls] && full[rs];
}

void push_down(int x) {
	if (val[x] == -1) {
		return;
	}
	if (tag[x] >> val[x] & 1) {
		swap(ls, rs);
		tag[x] ^= 1 << val[x];
	}
	tag[ls] ^= tag[x], tag[rs] ^= tag[x];
	tag[x] = 0;
}

void modify(int x, int y) {
	if (x) {
		tag[x] ^= y;
	}
}

int new_node() {
	int ret, x = ret = ++tot;
	for (int i = logn; ~i; i--) {
		val[x] = i;
		ls = ++tot;
		x = ls;
	}
	val[x] = -1, full[x] = true;
	return ret;
}

int merge(int x, int y) {
	if (!x || !y) {
		return x + y;
	}
	push_down(x);
	push_down(y);
	ls = merge(ch[x][0], ch[y][0]);
	rs = merge(ch[x][1], ch[y][1]);
	maintain(x);
	return x;
}

int mex(int x) {
	if (!x || val[x] == -1) {
		return 0;
	}
	if (full[x]) {
		return 1 << (val[x] + 1);
	}
	push_down(x);
	if (!full[ls]) {
		return mex(ls);
	} else {
		return mex(rs) | 1 << val[x];
	}
}

void dfs(int u, int pa = 0) {
	for (int i = lnk[u], v; i; i = nxt[i]) {
		v = ter[i];
		if (v == pa) continue;
		dfs(v, u);
		f[v] ^= dp[v];
		modify(rt[v], dp[v]);
		rt[u] = merge(rt[u], rt[v]);
		f[u] ^= dp[v];
	}
	if (!col[u]) {
		rt[u] = merge(rt[u], new_node());
	}
	modify(rt[u], f[u]);
	dp[u] = mex(rt[u]);
}

void solve(int u, int pa = 0) {
	g[u] ^= f[u];
	for (int i = lnk[u], v; i; i = nxt[i]) {
		v = ter[i];
		if (v == pa) continue;
		g[v] ^= g[u];
		solve(v, u);
	}
}

int main() {
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf("%d", &col[i]);
	}
	for (int i = 1, u, v; i < n; i++) {
		scanf("%d %d", &u, &v);
		add(u, v), add(v, u);
	}
	dfs(1);
	if (!dp[1]) {
		puts("-1");
	} else {
		solve(1);
		for (int i = 1; i <= n; i++) {
			if (!col[i] && !g[i]) {
				printf("%d\n", i);
			}
		}
	}
	return 0;
}
```

# Fox and Card Game

[「Codeforces 388C」Fox and Card Game](http://codeforces.com/contest/388/problem/C)

## 题目描述

$n$ 堆卡片，第 $i$ 堆有 $m_i$ 张，每张上有一个数。两人轮流取卡片，先手可以取堆顶，后手可以取堆底，每个人都想最大化自己拿到卡片的和，问先手最后拿到卡片的和。

数据范围：$n, m_i \le 100$。

## 思路分析

考虑 $m_i = 1$ 的情况，肯定是从大到小排序后先手取奇数位后手取偶数位。接下来考虑所有情况，发现先手可以每一堆取至少前 $\lfloor \frac{m_i}{2} \rfloor$ 个，后手可以通过模仿先手来保证自己取至少后 $\lfloor \frac{m_i}{2} \rfloor$ 个。如果 $m_i$ 是奇数的话还会剩下中间的一个，就转化成了 $m_i = 1$ 的情况。排序即可，时间复杂度 $O(nm)$。

## 代码实现

```cpp
#include <bits/stdc++.h>
using namespace std;

const int maxn = 100;
int n, m, a[maxn + 3], k, b[maxn + 3], sum, num;

int main() {
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf("%d", &m);
		for (int j = 1; j <= m; j++) {
			scanf("%d", &a[j]);
			sum += a[j];
			if (j * 2 <= m) {
				num += a[j];
			}
		}
		if (m & 1) {
			b[++k] = a[(m + 1) >> 1];
		}
	}
	sort(b + 1, b + k + 1);
	reverse(b + 1, b + k + 1);
	for (int i = 1; i <= k; i += 2) {
		num += b[i];
	}
	printf("%d %d\n", num, sum - num);
	return 0;
}
```

# Tree Game

[「AGC 010F」Tree Game](https://agc010.contest.atcoder.jp/tasks/agc010_f)

## 题目描述

一个 $n$ 个点的树，第 $i$ 个点上有 $a_i$ 颗石子，一开始 $k$ 号点上有旗子。两人博弈，每次一个人拿掉旗子所在点的一个石子，然后把旗子移到某个邻居，不能操作者输。求出所有先手必胜的 $k$。

数据范围：$n \le 3000$。

## 思路分析

对于某个 $k$，考虑以它为根后每个子树的子问题。也就是说，$f(u)$ 表示割掉 $u$ 和父亲的边后，旗子一开始在点 $u$ 是否先手必胜。我们断言：

+ 如果存在儿子 $v$ 满足 $a_u > a_v$ 并且 $f(v)$ 是必败态，那么 $f(u)$ 是必胜态。
+ 否则，$f(u)$ 是必败态。

证明留作习题。直接做即可，时间复杂度 $O(n^2)$。

## 代码实现

```cpp
#include <bits/stdc++.h>
using namespace std;

const int maxn = 3000;
int n, a[maxn + 3];
vector<int> G[maxn + 3];

bool dfs(int u, int pa = 0) {
	bool flag = false;
	for (int i = 0, v; i < G[u].size(); i++) {
		v = G[u][i];
		if (v == pa) continue;
		flag |= a[u] > a[v] && !dfs(v, u);
	}
	return flag;
}

int main() {
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf("%d", &a[i]);
	}
	for (int i = 1, u, v; i < n; i++) {
		scanf("%d %d", &u, &v);
		G[u].push_back(v), G[v].push_back(u);
	}
	for (int i = 1; i <= n; i++) {
		if (dfs(i)) printf("%d ", i);
	}
	puts("");
	return 0;
}
```

# Choosing Carrots

[「Codeforces 794E」Choosing Carrots](https://codeforces.com/contest/794/problem/E)

## 题目描述

有 $n$ 个数 $a_1, a_2, \cdots, a_n$，两人博弈，每次去掉两头的一个数，最后剩下一个数。先手想最大化剩余数，后手想最小化剩余数。问对于每个 $k$，先手一开始随便删掉 $k$ 个数后再开始博弈，最后剩余的数是多少。

数据范围：$n \le 3 \times 10^5$。

## 思路分析

先不考虑 $k$，$n$ 为偶数时显然答案是 $\max(a_{\frac{n}{2}}, a_{\frac{n}{2} + 1})$，$n$ 为奇数时答案就是：
$$
\begin {align*}
& \max(\min(a_\frac{n - 1}{2}, a_\frac{n + 1}{2}), \min(a_\frac{n + 1}{2}, a_\frac{n + 3}{2})) \\
= & \min(a_\frac{n + 1}{2}, \max(a_\frac{n - 1}{2}, a_\frac{n + 3}{2}))
\end {align*}
$$
然后考虑 $k$，分奇偶性讨论，对于每个值考虑它带来的影响。它肯定是对答案数组有一个后缀的更新，所以单点更新完再做前缀最大值即可，时间复杂度 $O(n)$。

## 代码实现

```cpp
#include <bits/stdc++.h>
using namespace std;

const int maxn = 3e5, inf = 1e9;
int n, mx, a[maxn + 3], f[maxn + 3];

void upd(int &x, int y) {
	x = max(x, y);
}

int main() {
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf("%d", &a[i]);
		mx = max(mx, a[i]);
	}
	for (int i = 2; i < n; i++) {
		upd(f[min(i - 1, n - i) * 2 + 1], min(a[i], max(a[i - 1], a[i + 1])));
	}
	for (int i = 1; i < n; i++) {
		upd(f[min(i, n - i) * 2], max(a[i], a[i + 1]));
	}
	for (int i = n - 2; i >= 2; i--) {
		upd(f[i], f[i + 2]);
	}
	for (int i = n; i >= 2; i--) {
		printf("%d ", f[i]);
	}
	printf("%d\n", mx);
	return 0;
}
```

