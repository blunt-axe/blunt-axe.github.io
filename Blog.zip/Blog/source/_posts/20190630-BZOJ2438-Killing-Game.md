---
title: 「BZOJ 2438」杀人游戏（Tarjan + 概率论）
date: 2019-06-30 00:00:03
mathjax: true
tags:
	- Tarjan
	- 概率论

---

# 题目大意
[「BZOJ 2438」杀人游戏](https://www.lydsy.com/JudgeOnline/problem.php?id=2438)

给定一个 $n$ 个点 $m$ 条边的有向无向图，每个点代表一个人，每条单向边代表一组认识关系。已知有一个人是杀手，每个人是杀手的概率都是 $\frac{1}{n}$。有一个警察，每次可以询问一个人，他如果是杀手就会把警察杀掉，如果不是的话他会告诉警察他认识的人中谁是杀手或没有杀手。问警察选择最优策略，查到杀手后还存活的概率。

数据范围：$n \le 10^5, m \le 3 \times 10^5$。

<!--more-->

# 思路分析
首先发现答案等于 $(n - k) / n$，其中 $k$ 表示不知道某人的身份就去查他的次数。然后发现在同一个 SCC 中，我们只需要查一个人即可，并且在缩点后的图中，我们查完一个点就可以查所有它能到达的点。于是，我们统计缩点后的 DAG 度数为 $0$ 的点数即可。

但是有一种特殊情况。因为杀手只有一个，所以在某些情况下我们不需要查完所有点。如果我们查完了 $n - 1$ 个点都是平民，那么剩下的一个点就肯定是杀手。于是我们特判一下，如果缩点后存在一个度数为 $0$ 的点在原图上对应的点数为 $1$，并且它的所有出点的入度都大于 $1$，那么我们就可以不查这个点，也就是将 $k$ 减去一。注意这种操作只能做一次。

这样，我们就解决了这个问题。时间复杂度 $O(n + m)$。这道题告诉我们，一些关于连通性的图论问题往往需要考虑一些特殊情况。

# 代码实现
```cpp
#include <cstdio>
#include <cstdlib>
#include <vector>
using namespace std;

const int maxn = 1e5, maxm = 3e5;
int n, m, u[maxm + 3], v[maxm + 3], tm, dfn[maxn + 3], low[maxn + 3];
int top, st[maxn + 3], cnt, sum[maxn + 3], bel[maxn + 3], deg[maxn + 3];
bool in[maxn + 3], ok[maxn + 3];
vector<int> G[maxn + 3];

void add(int u, int v) {
	G[u].push_back(v);
}

void tarjan(int u) {
	dfn[u] = low[u] = ++tm;
	st[++top] = u, in[u] = true;
	for (int i = 0, v; i < G[u].size(); i++) {
		v = G[u][i];
		if (!dfn[v]) {
			tarjan(v);
			low[u] = min(low[u], low[v]);
		} else if (in[v]) {
			low[u] = min(low[u], dfn[v]);
		}
	}
	if (dfn[u] == low[u]) {
		++cnt;
		do {
			sum[cnt]++;
			bel[st[top]] = cnt;
			in[st[top]] = false;
		} while (st[top--] != u);
	}
}

int main() {
	scanf("%d %d", &n, &m);
	for (int i = 1; i <= m; i++) {
		scanf("%d %d", &u[i], &v[i]);
		add(u[i], v[i]);
	}
	for (int i = 1; i <= n; i++) {
		if (!dfn[i]) {
			tarjan(i);
		}
	}
	for (int i = 1; i <= n; i++) {
		G[i].clear();
	}
	for (int i = 1; i <= m; i++) {
		if (bel[u[i]] != bel[v[i]]) {
			deg[bel[v[i]]]++;
			G[bel[u[i]]].push_back(bel[v[i]]);
		}
	}
	int ans = 0;
	for (int i = 1; i <= cnt; i++) {
		ans += !deg[i];
	}
	for (int i = 1; i <= cnt; i++) {
		if (!deg[i] && sum[i] == 1) {
			bool flag = true;
			for (int j = 0; j < G[i].size(); j++) {
				if (deg[G[i][j]] == 1) {
					flag = false;
					break;
				}
			}
			if (flag) {
				ans--;
				break;
			}
		}
	}
	printf("%.6lf\n", 1. * (n - ans) / n);
	return 0;
}
```