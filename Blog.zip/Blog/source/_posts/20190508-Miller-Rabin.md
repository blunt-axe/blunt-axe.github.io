---
title: 「学习笔记」Miller-Rabin 素数测试
mathjax: true
date: 2019-05-08 00:00:00
tags:
	- 学习笔记
	- 数论
---

Miller-Rabin 素数测试算法是一种能够快速检验一个数是否为素数的算法。

# 算法流程

费马小定理：如果 $n$ 为素数，那么对于 $\forall 1 \le a \le n - 1$，都有 $a^{n - 1} \equiv 1 \bmod n$。

二次探测法：如果 $n$ 为素数，那么方程 $a^2 \equiv 1 \bmod n$ 只有两个解：$a_1 = 1, a_2 = n - 1$。

于是我们可以设计一个算法，对于一个特定的 $a$ 来检验。

<!--more-->

现将 $n - 1$ 表示成 $n - 1 = 2^d \times r$ 的形式，其中 $r$ 为奇数。那么我们依次检验 $a^r, a^{2r}, a^{4r}, \cdots, a^{2^d \times r}$ 是否为 $1$ 或 $n - 1$。如果没有一个数是 $1$ 或 $n - 1$，那么 $n$ **一定不**是素数。

注意如果满足上述性质，那么 $n$ **不一定**是素数；但是如果不满足，$n$ **一定不**是素数。所以我们要进行多次检验。

# 检验需知

+ 在 `int` 范围内，只需检验 $2, 7, 61$ 即可保证正确性。  
+ 在 `long long` 范围内，只需检验 $2, 325, 9375, 28178, 450775, 9780504, 1795265022$。  
+ 当 $n \le 4 \times 10^{13}$ 时，只需检验 $2, 2570940, 211991001, 3749873356$。  
+ 当 $n \le 3 \times 10^{15}$ 时，只需检验 $2, 2570940, 880937, 610386380, 4130785767$。

# 代码实现

```cpp
#include <cstdio>

typedef long long ll;
int T;
ll n;

inline ll mult(const ll &x, const ll &y, const ll &n) {
	return (__int128) x * y % n;
}

ll _pow(ll a, ll b, ll n) {
	ll c = 1;
	for (; b; b >>= 1, a = mult(a, a, n)) {
		if (b & 1) c = mult(a, c, n);
	}
	return c;
}

bool miller(ll m, ll d, ll r, ll n) {
	if (m > n - 2) return true;
	ll x = _pow(m, d, n);
	if (x == 1 || x == n - 1) return true;
	for (int i = 0; i < r; i++) {
		x = mult(x, x, n);
		if (x == n - 1) return true;
	}
	return false;
}

bool is_prime(ll n) {
	if (n <= 2) return n == 2;
	static ll m[] = { 2, 325, 9375, 28178, 450775, 9780504, 1795265022 };
	ll d = n - 1, r = 0;
	while (~d & 1) d >>= 1, r++;
	for (int i = 0; i < 7; i++) {
		if (!miller(m[i], d, r, n)) return false;
	}
	return true;
}

int main() {
	scanf("%d", &T);
	while (T--) {
		scanf("%lld", &n);
		printf("%s\n", is_prime(n) ? "Yes" : "No");
	}
	return 0;
}
```