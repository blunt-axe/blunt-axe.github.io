---
title: 「学习笔记」欧拉回路算法
date: 2019-06-26 00:00:00
mathjax: true
tags:
	- 学习笔记
	- 欧拉回路

---

# 欧拉回路、欧拉图及其判定
在一张图上，一条从某个点出发，经过所有的边后回到原点的路径叫做欧拉回路。有欧拉回路的图叫做欧拉图。

容易发现，欧拉图一定是联通图。它还需要满足以下条件：
+ 如果是无向图，那么每个结点的度数都是偶数。
+ 如果是有向图，那么每个结点的入度和出度相等。

不难理解这是判断欧拉图的充要条件。

<!--more-->

# 欧拉回路算法详解
我们先判断图是否是欧拉图，然后通过 DFS 的方法来找欧拉回路。

DFS 一个点的时候，我们每次找到一条没有使用过的边，然后先 DFS 那个点，再将这条边加入答案栈中。最后将栈中的元素倒序输出即可。

为了优化复杂度，我们使用当前弧优化，不难证明时间复杂度为 $O(n + m)$。

模版提交地址：[「UOJ 117」欧拉回路](http://uoj.ac/problem/117)。

```cpp
#include <cstdio>
#include <algorithm>
using namespace std;

const int maxn = 1e5, maxm = 4e5;
int type, n, m, deg[maxn + 3], top, st[maxm + 3];
int tot, ter[maxm + 3], id[maxm + 3], nxt[maxm + 3], lnk[maxn + 3], cur[maxn + 3];
bool vis[maxm + 3];

void add(int u, int v, int w) {
	ter[++tot] = v, id[tot] = w;
	nxt[tot] = lnk[u], lnk[u] = tot;
}

void dfs(int u) {
	for (int &i = cur[u], x; i; i = nxt[i]) {
		if (!vis[abs(x = id[i])]) {
			vis[abs(x)] = true;
			dfs(ter[i]), st[++top] = x;
		}
	}
}

int main() {
	scanf("%d %d %d", &type, &n, &m);
	type--;
	for (int i = 1, u, v; i <= m; i++) {
		scanf("%d %d", &u, &v);
		add(u, v, i), type ? void() : add(v, u, -i);
		deg[u]++, deg[v] += type ? -1 : 1;
	}
	bool flag = true;
	for (int i = 1; i <= n; i++) {
		type ? flag &= !deg[i] : flag &= ~deg[i] & 1;
	}
	if (!flag) {
		return puts("NO"), 0;
	}
	for (int i = 1; i <= n; i++) {
		cur[i] = lnk[i];
	}
	dfs(ter[1]);
	if (top != m) {
		puts("NO");
	} else {
		puts("YES");
		while (top) {
			printf("%d%c", st[top], " \n"[top == 1]), top--;
		}
	}
	return 0;
}
```

# 欧拉回路算法的应用
## 「BZOJ 3033」太鼓达人
### 题目大意
[「BZOJ 3033」太鼓达人](https://www.lydsy.com/JudgeOnline/problem.php?id=3033)

给定 $n$，要求输出一个长度为 $2^n$ 的，每个位置为 $0, 1$ 的环，使得环上所有连续 $n$ 位组成的二进制数互不相同。如果有多解，输出字典序最小的。

数据范围：$n \le 11$。

### 思路分析
其实这题 $n \le 20$ 也是能做的。

其实这题还可以贪心，但是这里就不讲解了。

考虑将每个长度为 $n$ 的二进制数看作一条边，它连接的两个点分别是它去掉最后一位和它去掉第一位后长度为 $n - 1$ 的二进制数。然后我们在这个点数为 $2^{n - 1}$，边数为 $2^n$ 的图上跑欧拉回路即可。

注意到这题要求字典序最小的方案。于是我们注意加边顺序即可。时间复杂度 $O(2^n)$。

### 代码实现
```cpp
#include <cstdio>

const int maxn = 11, maxm = 1 << maxn;
int n, m, tot, ter[maxm + 3], wei[maxm + 3], nxt[maxm + 3], lnk[maxm + 3], cur[maxm + 3], top, st[maxm + 3];
bool vis[maxm + 3];

void add(int u, int v, int w) {
	ter[++tot] = v, wei[tot] = w;
	nxt[tot] = lnk[u], lnk[u] = tot;
}

void dfs(int u) {
	for (int &i = cur[u], x; i; i = nxt[i]) if (!vis[i]) {
		vis[i] = true, x = wei[i];
		dfs(ter[i]), st[++top] = x;
	}
}

int main() {
	scanf("%d", &n);
	printf("%d ", 1 << n);
	if (n == 1) {
		return puts("01"), 0;
	}
	for (int i = 1; ~i; i--) {
		for (int msk = 0; msk < 1 << (n - 1); msk++) {
			add(msk + 1, ((msk * 2 + i) & ((1 << (n - 1)) - 1)) + 1, i);
		}
	}
	for (int i = 1; i <= 1 << (n - 1); i++) {
		cur[i] = lnk[i];
	}
	dfs((1 << (n - 1)));
	while (top) {
		putchar(st[top--] + '0');
	}
	puts("");
	return 0;
}
```

## 「POI 2010」Bridges（BZOJ 2095）
### 题目大意
[「POI 2010」Bridges（BZOJ 2095）](https://www.lydsy.com/JudgeOnline/problem.php?id=2095)

待更 ......
