---
title: 「学习笔记」莫比乌斯反演进阶篇
date: 2019-11-28 00:00:00
mathjax: true
tags:
	- 学习笔记
	- 数论
---

# 杜教筛

杜教筛可以快速求一些积性函数的前缀和。假设我们要求 $S(n) = \sum_{i = 1}^{n} f(i)$，杜教筛方法如下：
$$
\begin {align*}
& \sum_{i = 1}^{n} (f * g)(i) = \sum_{i = 1}^{n} g(i) S(\lfloor \frac{n}{i} \rfloor) \\
\Leftrightarrow \ & g(1) S(n) = \sum_{i = 1}^{n} (f * g)(i) + \sum_{i = 2}^{n} g(i) S(\lfloor \frac{n}{i} \rfloor) 
\end {align*}
$$
<!--more-->

对于积性函数 $f$，如果能找到积性函数 $g$，使得 $g, (f * g)$ 的前缀和都容易计算，那么我们就可以先用线性筛预处理出 $S(1), S(2), \cdots, S(\text{lim})$，然后使用整除分块和记忆化搜索计算 $S(n)$ $(n > \text{lim})$。当 $\text{lim} = n^{\frac{2}{3}}$ 时，算法的复杂度为 $O(n ^ {\frac{2}{3}})$，实际上 $\text{lim}$ 取得更大一点会更优。

例子：求 $\mu$ 的前缀和时，我们可以取 $g = 1$，这样 $(f * g) = \epsilon$，而 $1, \epsilon$ 的前缀和都可以快速计算。

# YY 的 GCD

[「Luogu 2257」YY 的 GCD](https://www.luogu.com.cn/problem/P2257)

## 题目描述

$T$ 次询问 $n, m$，求：

$$\sum_{i = 1}^{n} \sum_{j = 1}^{m} [\gcd(i, j) \in P]$$

其中 $P$ 表示素数集合。

数据范围：$T \le 10^4, n, m \le 10^7$。

## 思路分析

设数论函数 $p(n)$ 满足当 $n$ 为素数时 $p(n) = 1$，否则 $p(n) = 0$。那么答案为：
$$
\begin {align*}
& \sum_{i = 1}^{n} \sum_{j = 1}^{m} [p(\text{gcd}(i, j))] \\
= & \sum_{k = 1}^{\min(n, m)} p(k) \sum_{i = 1}^{\lfloor \frac{n}{k} \rfloor} \sum_{j = 1}^{\lfloor \frac{m}{k} \rfloor} [(i, j) = 1] \\
= & \sum_{k = 1}^{\min(n, m)} p(k) \sum_{i = 1}^{\lfloor \frac{n}{k} \rfloor} \sum_{j = 1}^{\lfloor \frac{m}{k} \rfloor} \sum_{t | i, j} \mu(t) \\
= & \sum_{t = 1}^{n} \mu(t) \sum_{k = 1}^{\lfloor \frac{n}{t} \rfloor} p(k) \lfloor \frac{n}{kt} \rfloor \lfloor \frac{m}{kt} \rfloor \\
= & \sum_{i = 1}^{n} \lfloor \frac{n}{i} \rfloor \lfloor \frac{m}{i} \rfloor \sum_{d | i} \mu(d) p(\frac{i}{d}) \\
\end {align*}
$$
我们记 $f(n) = \sum_{d | n} \mu(d) p(\frac{n}{d})$，考虑枚举 $\frac{n}{d}$，这样就可以 $O(n \log \log n)$ 预处理出 $f(1), f(2), \cdots, f(n)$。然后用整除分块回答每组询问即可。时间复杂度 $O(n \log \log n + T \sqrt n)$。

## 代码实现

```cpp
#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn = 1e7;
int T, n, m, cnt, prm[maxn + 3], mu[maxn + 3], f[maxn + 3];
bool vis[maxn + 3];

void prework(int n) {
	mu[1] = 1;
	for (int i = 2; i <= n; i++) {
		if (!vis[i]) {
			prm[++cnt] = i;
			mu[i] = -1;
		}
		for (int j = 1; j <= cnt && i * prm[j] <= n; j++) {
			vis[i * prm[j]] = true;
			if (i % prm[j] == 0) {
				mu[i * prm[j]] = 0;
				break;
			}
			mu[i * prm[j]] = -mu[i];
		}
	}
	for (int i = 1; i <= cnt; i++) {
		int x = prm[i];
		for (int j = 1; j * x <= n; j++) {
			f[j * x] += mu[j];
		}
	}
	for (int i = 1; i <= n; i++) {
		f[i] += f[i - 1];
	}
}

int main() {
	prework(maxn);
	scanf("%d", &T);
	while (T --> 0) {
		scanf("%d %d", &n, &m);
		ll ans = 0;
		for (int l = 1, r = 1; l <= min(n, m); l = r + 1) {
			r = min(n / (n / l), m / (m / l));
			ans += 1ll * (f[r] - f[l - 1]) * (n / l) * (m / l);
		}
		printf("%lld\n", ans);
	}
	return 0;
}
```

# Siyuan GCD

[「LOJ 6686」Stupid GCD](https://loj.ac/problem/6686)

## 题目描述

给定 $n$，求：
$$
\sum_{i = 1}^{n} \gcd(\sqrt[3]{i}, i)
$$
数据范围：$n \le 10^{30}$。

## 思路分析

见我的博客：[「LOJ 6686」Stupid GCD（数论）](/2019/07/28/20190728-LOJ6686-Stupid-GCD/)

## 代码实现

```cpp
#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef __int128 lll;
const int maxn = 2e7, mod = 998244353;
int tot, a[100];
int cnt, prm[maxn / 10 + 3], phi[maxn + 3], pid[maxn + 3];
bool vis[maxn + 3];
map<ll, int> map_1, map_2;
ll m, p[100];
lll n;

void read(lll &x) {
	static char ch;
	static bool neg;
	for (ch = neg = 0; ch < '0' || ch > '9'; neg |= (ch == '-'), ch = getchar());
	for (x = 0; ch >= '0' && ch <= '9'; (x *= 10) += (ch ^ 48), ch = getchar());
	neg && (x = -x);
}

void dfs(int &ret, lll n, int dep, ll cur, ll num) {
	if (dep > tot) {
		ret = (ret + n / cur % mod * num) % mod;
		return;
	}
	dfs(ret, n, dep + 1, cur, num);
	cur *= p[dep], num *= p[dep] - 1;
	dfs(ret, n, dep + 1, cur, num);
	for (int i = 2; i <= a[dep]; i++) {
		cur *= p[dep], num *= p[dep];
		dfs(ret, n, dep + 1, cur, num);
	}
}

int solve_1(lll n, ll m) {
	int ret = m % mod;
	for (int i = 2; 1ll * i * i <= m; i++) {
		if (m % i == 0) {
			p[++tot] = i;
			while (m % i == 0) {
				m /= i, a[tot]++;
			}
		}
	}
	if (m > 1) {
		p[++tot] = m, a[tot] = 1;
	}
	dfs(ret, n, 1, 1, 1);
	return ret;
}

int func(int x) {
	return x < mod ? x : x - mod;
}

void prework(int n) {
	phi[1] = pid[1] = 1;
	for (int i = 2; i <= n; i++) {
		if (!vis[i]) {
			prm[++cnt] = i;
			phi[i] = i - 1;
		}
		pid[i] = 1ll * phi[i] * i % mod;
		for (int j = 1; j <= cnt && i * prm[j] <= n; j++) {
			vis[i * prm[j]] = true;
			if (i % prm[j] == 0) {
				phi[i * prm[j]] = phi[i] * prm[j];
				break;
			}
			phi[i * prm[j]] = phi[i] * (prm[j] - 1);
		}
	}
	for (int i = 2; i <= n; i++) {
		phi[i] = func(phi[i] + phi[i - 1]);
		pid[i] = func(pid[i] + pid[i - 1]);
	}
}

int func_1(ll n) {
	return (lll) n * (n + 1) / 2 % mod;
}

int func_2(ll n) {
	return (lll) n * (n + 1) * (n * 2 + 1) / 6 % mod;
}

int sum_1(ll n) {
	if (n <= maxn) {
		return phi[n];
	}
	if (map_1.count(n)) {
		return map_1[n];
	}
	int &ret = map_1[n] = func_1(n);
	for (ll l = 2, r = 2; l <= n; l = r + 1) {
		r = n / (n / l);
		ret = (ret + 1ll * (r - l + 1) % mod * (mod - sum_1(n / l))) % mod;
	}
	return ret;
}

int sum_2(ll n) {
	if (n <= maxn) {
		return pid[n];
	}
	if (map_2.count(n)) {
		return map_2[n];
	}
	int &ret = map_2[n] = func_2(n);
	for (ll l = 2, r = 2; l <= n; l = r + 1) {
		r = n / (n / l);
		ret = (ret + 1ll * func(func_1(r) - func_1(l - 1) + mod) * (mod - sum_2(n / l))) % mod;
	}
	return ret;
}

int solve_2(ll n) {
	prework(min((ll) maxn, n));
	int ans = 0;
	for (ll l = 1, r = 1; l <= n; l = r + 1, r = 0) {
		r = n / (n / l);
		ans = (ans + 1ll * (sum_1(r) - sum_1(l - 1) + mod) * func_1(n / l)) % mod;
		ans = (ans + 1ll * (sum_2(r) - sum_2(l - 1) + mod) * func_2(n / l)) % mod;
	}
	return (3ll * ans + func_1(n)) % mod;
}

int main() {
	read(n);
	m = powl(n + .5, 1. / 3);
	while ((lll) m * m * m > n) m--;
	while ((lll) (m + 1) * (m + 1) * (m + 1) <= n) m++;
	printf("%d\n", func(solve_1(n - (lll) m * m * m, m) + solve_2(m - 1)));
	return 0;
}
```

*下面原本写了 4 道题的题解，然后因为 bug 没掉了，所以这里引用黄队的博客中较重要的两题，并稍作修改。*

#密码解锁 

[「Luogu 5348」密码解锁](https://www.luogu.com.cn/problem/P5348)

## 题目描述

已知：
$$
\sum_{d|x,x\le n}f(x)=\mu(d)
$$
求 $f(m)$。

数据范围：$m\le 10^9,\dfrac{n}{m}\le 10^9$。

## 思路分析

由莫比乌斯反演推论可以得到：
$$
\begin{split}f(m)=&\sum_{m|i,i\le n}\mu(i)\mu\left(\frac{i}{m}\right)\\=&\sum_{i=1}^{\left\lfloor\frac{n}{m}\right\rfloor}\mu(im)\mu\left(i\right)\\=&\sum_{i=1}^{\left\lfloor\frac{n}{m}\right\rfloor}\mu^2(i)\mu(m)[i\perp m]\\=&\mu(m)\sum_{i=1}^{\left\lfloor\frac{n}{m}\right\rfloor}\mu^2(i)[i\perp m]\end{split}
$$

考虑把这个和式做一个递归：
$$
\begin{split}
S(n,k)=&\sum_{i=1}^n\mu^2(i)[i\perp k]\\
=&\sum_{i=1}^n\mu^2(i)\sum_{d|i,d|k}\mu(d)\\
=&\sum_{d|k}\mu(d)\sum_{i=1}^{\left\lfloor\frac{n}{d}\right\rfloor}\mu^2(id)\\
=&\sum_{d|k}\mu^3(d)\sum_{i=1}^{\left\lfloor\frac{n}{d}\right\rfloor}\mu^2(i)[i\perp d]\\
=&\sum_{d|k}\mu(d)S\left(\left\lfloor\frac{n}{d}\right\rfloor,d\right)
\end{split}
$$
递归边界为 $S(n,1)=\sum_{i=1}^n\mu^2(i)$。我们考虑 $\mu^2(i)$ 的贡献。当且仅当 $i$ 不含平方及以上的因子时，$\mu^2(i)=1$，否则 $\mu^2(i)=0$。

因此我们要求 $[1, n]$ 中无平方因子的数的个数。那么考虑容斥，用整体减掉含有平方因子的数：
$$
\begin{split}
& \sum_{i=1}^n\mu^2(i)=n+\sum_{i=2}^n\mu(i)\left\lfloor \frac{n}{i^2} \right\rfloor\\
= & \sum_{i=1}^n\mu(i)\left\lfloor \frac{n}{i^2} \right\rfloor=\sum_{i=1}^\sqrt{n}\mu(i)\left\lfloor \frac{n}{i^2} \right\rfloor
\end{split}
$$
$\mu(i)$ 是容斥系数。我们记忆化计算 $S$ 即可，时间复杂度不超过 $O(\sqrt{\frac{n}{m}} \sigma_0(m))$，可以通过。

## 代码实现

```cpp
#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn = 1e7;
int T, n, m, cnt, prm[maxn + 3], mu[maxn + 3], tot, p[100], a[100];
bool vis[maxn + 3];
map<int, int> M_mu;
map<pair<int, int>, int> M;
ll k;

void prework(int n) {
	mu[1] = 1;
	for (int i = 2; i <= n; i++) {
		if (!vis[i]) {
			prm[++cnt] = i;
			mu[i] = -1;
		}
		for (int j = 1; j <= cnt && i * prm[j] <= n; j++) {
			vis[i * prm[j]] = true;
			if (i % prm[j] == 0) {
				mu[i * prm[j]] = 0;
				break;
			}
			mu[i * prm[j]] = -mu[i];
		}
	}
}

int get_mu(int x) {
	return x <= maxn ? mu[x] : M_mu[x];
}

void dfs(int x, int cur, int val) {
	if (x > tot) {
		if (cur > maxn) {
			M_mu[cur] = val;
		}
		return;
	}
	dfs(x + 1, cur, val);
	cur *= p[x], val *= -1;
	dfs(x + 1, cur, val);
	for (int i = 2; i <= a[x]; i++) {
		cur *= p[x];
		dfs(x + 1, cur, 0);
	}
}

int S(int n, int m) {
	if (n == 0) {
		return 0;
	}
	if (M.count(make_pair(n, m))) {
		return M[make_pair(n, m)];
	}
	int &ret = M[make_pair(n, m)] = 0;
	if (m == 1) {
		for (int i = 1; i * i <= n; i++) {
			ret += n / (i * i) * mu[i];
		}
	} else {
		for (int i = 1; i * i <= m; i++) {
			if (m % i == 0) {
				ret += get_mu(i) * S(n / i, i);
			}
		}
		for (int i = 1; i * i < m; i++) {
			if (m % i == 0) {
				ret += get_mu(m / i) * S(n / (m / i), m / i);
			}
		}
	}
	return ret;
}

int main() {
	prework(maxn);
	scanf("%d", &T);
	while (T --> 0) {
		scanf("%lld %d", &k, &m);
		n = k / m;
		tot = 0;
		int cur = m;
		for (int i = 2; i * i <= cur; i++) {
			if (cur % i == 0) {
				p[++tot] = i, a[tot] = 0;
				while (cur % i == 0) {
					a[tot]++, cur /= i;
				}
			}
		}
		if (cur > 1) {
			p[++tot] = cur, a[tot] = 1;
		}
		dfs(1, 1, 1);
		printf("%d\n", S(n, m) * get_mu(m));
	}
	return 0;
}
```

# FSF’s Game

[「HDU 4944」FSF's Game](http://acm.hdu.edu.cn/showproblem.php?pid=4944)

## 题目描述

给定 $n$，求：
$$
\sum_{i=1}^n\sum_{j=i}^n\sum_{k|i,k|j}\frac{ij}{\gcd\left(\frac{i}{k},\frac{j}{k}\right)}
$$
数据范围：$T,n\le 5\times 10^5$。

## 思路分析

$$
\begin{split}
&\sum_{i=1}^n\sum_{j=i}^n\sum_{k|i,k|j}\frac{ij}{\gcd\left(\frac{i}{k},\frac{j}{k}\right)}\\
=&\sum_{k=1}^nk^2\sum_{i=1}^{\left\lfloor\frac{n}{k}\right\rfloor}\sum_{j=i}^{\left\lfloor\frac{n}{k}\right\rfloor}\operatorname{lcm}(i,j)
\end{split}
$$

设 $f(n)=\sum_{i=1}^n\sum_{j=i}^n\operatorname{lcm}(i,j)=\sum_{j=1}^n\sum_{i=1}^j\operatorname{lcm}(i,j)$。

设 $g(n)=\sum_{i=1}^n\gcd(n,i)$。那么可以用两两配对的思路反演得到：
$$
g(n)=\frac{1}{2}n\left[\left(\sum_{d|n}d\cdot \varphi(d)\right)-1\right]+n
$$
那么我们做一个 $g(n)$ 的前缀和就得到了 $f(n)$。现在原式化简为了：
$$
F(n)=\sum_{k=1}^nk^2f\left(\left\lfloor\frac{n}{k}\right\rfloor\right)
$$
发现对于 $f(i)$，它对区间 $[ij, (i + 1)j - 1]$ 中的 $F$ 有 $f(i) \times j^2$ 的贡献。枚举 $i, j$，使用前缀和优化来预处理即可，时间复杂度 $O(n \log n)$。

## 代码实现

```cpp
#include <bits/stdc++.h>
using namespace std;

typedef unsigned ui;
typedef long long ll;
const int maxn = 5e5;
int T, cnt, prm[maxn + 3];
ll num[maxn + 3], iphi[maxn + 3];
ui lcm[maxn + 3], res[maxn + 3];
bool vis[maxn + 3];

void prework(int n) {
	iphi[1] = 1;
	for (int i = 2; i <= n; i++) {
		if (!vis[i]) {
			prm[++cnt] = i;
			iphi[i] = 1ll * i * (i - 1);
		}
		for (int j = 1; j <= cnt && i * prm[j] <= n; j++) {
			vis[i * prm[j]] = true;
			if (i % prm[j] == 0) {
				iphi[i * prm[j]] = iphi[i] * prm[j] * prm[j];
				break;
			}
			iphi[i * prm[j]] = iphi[i] * prm[j] * (prm[j] - 1);
		}
	}
	for (int i = 1; i <= n; i++) {
		for (int j = i; j <= n; j += i) {
			num[j] += iphi[i];
		}
	}
	for (int i = 1; i <= n; i++) {
		num[i] = (num[i] + 1) * i / 2;
		lcm[i] = lcm[i - 1] + num[i];
	}
	for (int i = 1; i <= n; i++) {
		for (int j = 1; i * j <= n; j++) {
			res[i * j] += lcm[i] * (ui) j * (ui) j;
			res[min(n + 1, (i + 1) * j)] -= lcm[i] * (ui) j * (ui) j;
		}
	}
	for (int i = 1; i <= n; i++) {
		res[i] += res[i - 1];
	}
}

int main() {
	prework(maxn);
	scanf("%d", &T);
	for (int x, _ = 1; _ <= T; _++) {
		scanf("%d", &x);
		printf("Case #%d: %u\n", _, res[x]);
	}
	return 0;
}
```



