---
title: 「学习笔记」分治算法入门
date: 2019-07-29 00:00:00
mathjax: true
tags:
	- 学习笔记
	- 分治

---

# 目录
+ [按时间分治](/2019/07/29/20190729-Divide-And-Conquer/#按时间分治)
+ [CDQ 分治](/2019/07/29/20190729-Divide-And-Conquer/#CDQ-分治)
+ [整体二分](/2019/07/29/20190729-Divide-And-Conquer/#整体二分)

<!--more-->

# 按时间分治
不多说了，直接看题吧。

## 题目大意
有 $n$ 个时间点，每个时间点都有某个数 $x$ 出现或消失，对于每个时间点，求当前数的子集最大异或和。

## 思路分析
可以把问题看作每个数都有一个出现时间和消失时间。考虑对时间建线段树，每个结点是一个 `std::vector`。然后对于每一个元素，我们在线段树上将它对应的区间 `push_back` 进这个元素。最后回答询问的时候，我们将线段树 DFS 一遍，求出每个结点到根上的所有数的线性基即可。时间复杂度 $O(n \log n)$。

其实这个做法运用的思想就是对时间进行分治。

## 代码实现
```cpp
#include <bits/stdc++.h>
#define ls (rt << 1)
#define rs (ls | 1)
#define mid ((l + r) >> 1)
using namespace std;

const int maxn = 5e5, maxm = 1 << 20, logn = 31, logm = 20;
int n, a[maxn + 3], b[logm + 3][logn + 3], ans[maxn + 3];
map<int, int> mp;
vector<int> seg[maxm + 3];

void modify(int rt, int l, int r, int lx, int rx, int x) {
	if (l >= lx && r <= rx) {
		seg[rt].push_back(x);
		return;
	}
	if (lx <= mid) {
		modify(ls, l, mid, lx, rx, x);
	}
	if (rx > mid) {
		modify(rs, mid + 1, r, lx, rx, x);
	}
}

void insert(int b[], int x) {
	for (int i = logn - 1; ~i; i--) {
		if (x >> i & 1) {
			if (!b[i]) {
				b[i] = x;
				break;
			}
			x ^= b[i];
		}
	}
}

int query(int b[]) {
	int x = 0;
	for (int i = logn - 1; ~i; i--) {
		x = max(x, x ^ b[i]);
	}
	return x;
}

void solve(int rt, int l, int r, int dep = 1) {
	for (int i = 0; i < seg[rt].size(); i++) {
		insert(b[dep], seg[rt][i]);
	}
	if (l == r) {
		ans[l] = query(b[dep]);
		return;
	}
	memcpy(b[dep + 1], b[dep], sizeof(b[dep]));
	solve(ls, l, mid, dep + 1);
	memcpy(b[dep + 1], b[dep], sizeof(b[dep]));
	solve(rs, mid + 1, r, dep + 1);
}

int main() {
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf("%d", &a[i]);
		if (a[i] > 0) {
			mp[a[i]] = i;
		} else {
			a[i] = -a[i];
			modify(1, 1, n, mp[a[i]], i - 1, a[i]);
			mp[a[i]] = 0;
		}
	}
	for (map<int, int>::iterator it = mp.begin(); it != mp.end(); it++) {
		if (it -> second) {
			modify(1, 1, n, it -> second, n, it -> first);
		}
	}
	solve(1, 1, n);
	for (int i = 1; i <= n; i++) {
		printf("%d\n", ans[i]);
	}
	return 0;
}
```

# CDQ 分治
CDQ 分治是一类特殊的分治，指的是在分治过程中计算左半部分对右半部分产生的贡献。

偏序问题是 CDQ 分治的经典例题。

## 题目大意
[「HDU 5126」Stars](http://acm.hdu.edu.cn/showproblem.php?pid=5126)

有 $n$ 次操作，分为两种：
+ `1 x y z` 添加一颗坐标为 $(x, y, z)$ 的星星。
+ `2 lx ly lz rx ry rz` 询问以 $(lx, ly, lz)$ 为左下角，$(rx, ry, rz)$ 为右上角的长方体内有多少星星。

数据范围：$n \le 5 \times 10^4$。

## 思路分析
这题的本质是四维偏序问题（前三维是显然的，另一维是时间），可以使用两次 CDQ 分治 + 树状数组解决（当然你也可以写树套树套树）。

先将每个长方体询问转化成 $8$ 个前缀询问，这样我们只需考虑在某个前缀询问之前，三维坐标都不大于它的星星个数。我们可以把每个操作看作一个五元组 $(i, x, y, z, \text{type})$，$i$ 表示操作的标号，$(x, y, z)$ 表示坐标，$\text{type}$ 表示操作类型。

我们对操作的标号 $i$ 做一遍分治。假设一次分治时左端点是 $l$，右端点是 $r$。我们令 $\text{mid} = \lfloor \frac{l + r}{2} \rfloor$，那么我们只考虑 $i \le \text{mid}$ 的修改对 $i > \text{mid}$ 询问的贡献。这样做完后，我们发现对于每个询问，它之前的修改都恰好对它自己做了一次贡献，也就是答案的计算不重复也不遗漏。这样分治以后，总共的时间复杂度多了一个 $\log$，但是问题的维数减少了一。

将 $i$ 这一维去掉以后，问题就变成了对于每个询问，求三维坐标都不大于它的星星个数，不用再考虑星星和询问的相对位置了。之后，我们用同样的方法去掉 $x$，这样问题就从三维降到了二维。对于二维的问题，我们将二元组按照第一维排序，然后使用树状数组计算答案即可。总共的复杂度为 $O(n\log^3 n)$。

## 代码实现
```cpp
#include <bits/stdc++.h>
using namespace std;

const int maxn = 4e5;
int T, Q, n, m, q, sz, tmp[maxn + 3], ans[maxn + 3], bit[maxn + 3];
bool bel[maxn + 3], tb[maxn + 3];

struct event {
	int type, x, y, z;
	event(int type = 0, int x = 0, int y = 0, int z = 0): type(type), x(x), y(y), z(z) {}
} eve[maxn + 3], cur[maxn + 3], mrg[maxn + 3];

void add_event(int type, int x, int y, int z) {
	n++, eve[n] = event(type, x, y, z);
}

void add(int x, int y) {
	for (int i = x; i <= sz; i += i & -i) {
		bit[i] += y;
	}
}

int sum(int x) {
	int y = 0;
	for (int i = x; i; i ^= i & -i) {
		y += bit[i];
	}
	return y;
}

void solve(int l, int r) {
	if (l == r) {
		return;
	}
	int mid = (l + r) / 2;
	solve(l, mid);
	solve(mid + 1, r);
	int p = l, q = mid + 1, cnt = 0;
	while (p <= mid || q <= r) {
		if (q > r || (p <= mid && cur[p].y <= cur[q].y)) {
			if (bel[p] == false && !cur[p].type) {
				add(cur[p].z, 1);
			}
			tb[++cnt] = bel[p];
			mrg[cnt] = cur[p++];
		} else {
			if (bel[q] == true && cur[q].type) {
				int x = cur[q].type > 0 ? cur[q].type : -cur[q].type, y = cur[q].type > 0 ? 1 : -1;
				ans[x] += y * sum(cur[q].z);
			}
			tb[++cnt] = bel[q];
			mrg[cnt] = cur[q++];
		}
	}
	for (int i = l; i <= mid; i++) {
		if (bel[i] == false && !cur[i].type) {
			add(cur[i].z, -1);
		}
	}
	for (int i = l; i <= r; i++) {
		bel[i] = tb[i - l + 1];
		cur[i] = mrg[i - l + 1];
	}
}

void cdq(int l, int r) {
	if (l == r) {
		return;
	}
	int mid = (l + r) / 2;
	cdq(l, mid);
	cdq(mid + 1, r);
	int p = l, q = mid + 1;
	m = 0;
	while (p <= mid || q <= r) {
		if (q > r || (p <= mid && eve[p].x <= eve[q].x)) {
			cur[++m] = eve[p++], bel[m] = false;
		} else {
			cur[++m] = eve[q++], bel[m] = true;
		}
	}
	for (int i = l; i <= r; i++) {
		eve[i] = cur[i - l + 1];
	}
	solve(1, m);
}

int main() {
	scanf("%d", &T);
	while (T--) {
		for (int i = 1; i <= q; i++) {
			ans[i] = 0;
		}
		scanf("%d", &Q);
		n = q = 0;
		for (int i = 1, type, x, y, z, lx, ly, lz, rx, ry, rz; i <= Q; i++) {
			scanf("%d", &type);
			if (type == 1) {
				scanf("%d %d %d", &x, &y, &z);
				add_event(0, x, y, z);
			} else {
				scanf("%d %d %d %d %d %d", &lx, &ly, &lz, &rx, &ry, &rz);
				lx--, ly--, lz--, q++;
				add_event(q, rx, ry, rz);
				add_event(-q, lx, ry, rz);
				add_event(-q, rx, ly, rz);
				add_event(-q, rx, ry, lz);
				add_event(q, rx, ly, lz);
				add_event(q, lx, ry, lz);
				add_event(q, lx, ly, rz);
				add_event(-q, lx, ly, lz);
			}
		}
		for (int i = 1; i <= n; i++) {
			tmp[i] = eve[i].z;
		}
		sort(tmp + 1, tmp + n + 1);
		sz = unique(tmp + 1, tmp + n + 1) - (tmp + 1);
		for (int i = 1; i <= n; i++) {
			eve[i].z = lower_bound(tmp + 1, tmp + sz + 1, eve[i].z) - tmp;
		}
		cdq(1, n);
		for (int i = 1; i <= q; i++) {
			printf("%d\n", ans[i]);
		}
	}
	return 0;
}
```

# 整体二分
整体二分是一种分治算法，让我们直接看题吧。

## 题目大意
[「ZJOI 2013」K 大数查询（Luogu 3332）](https://www.luogu.org/problem/P3332)

有 $n$ 个栈，一开始为空。有 $m$ 次操作，共分两种：
+ `1 a b c` 表示在第 $a$ 个栈到第 $b$ 个栈中各添加一个权值为 $c$ 的元素。
+ `2 l r k` 表示询问第 $l$ 个栈到第 $r$ 个栈中第 $k$ 大的元素。

数据范围：$n, m \le 5 \times 10^4$。

## 思路分析
想要求一个集合的第 $k$ 大，考虑使用二分的方法。每次查询 $> x$ 的数的个数，设结果为 $y$。如果 $y < k$，则答案 $\le x$；否则，答案 $>x$。

但是发现 $1$ 操作不好用数据结构维护，不能在线地做二分。考虑离线，然后使用整体二分的方法。具体地，我们定义函数 `solve(A[], L, R)`，其中 $A$ 表示所有操作形成的序列，$L, R$ 表示 $A$ 中所有的修改涉及到的数，以及所有询问的答案都在区间 $[L, R]$ 内部，也就是分治的子问题。为了方便起见，我们令 $M$ 表示区间 $[L, R]$ 的中点，也就是 $\lfloor \frac{L + R}{2} \rfloor$。

我们考虑通过 `solve` 函数把原问题递归到它的子问题。也就是说，我们要判断 $A$ 中的每个询问的答案是否 $\le M$。对 $c_i > M$ 的修改和所有询问按照发生的时间依次考虑，我们要计算对于每个询问，有多少 $> M$ 的数在它的区间内部。使用支持区间加法，区间查询的线段树即可。我们将计算结果记作 $\text{res}(i)$，并新建两个序列 $A_l, A_r$，表示递归到左边的序列和递归到右边的序列。

之后，扫一遍 $A$。如果某个元素是修改，则根据它的 $c$ 将其加入 $A_l$ 或 $A_r$ 中。如果是询问，就将 $\text{res(i)}$ 和 $k_i$ 做比较。如果 $\text{res(i)} \ge k_i$，则将它放入 $A_{r}$ 中；否则将它放到 $A_l$ 中，并将 $k_i \leftarrow k_i - \text{res}(i)$，因为已经有 $\text{res}(i)$ 个数排在它前面了。最后，递归求解 `solve(Al, L, M)` 以及 `solve(Ar, M + 1, R)` 即可。不难发现最多递归的层数是 $\log c$，并且每层最多有 $m$ 个元素。再加上线段树的复杂度 $O(\log n)$，总共的复杂度是 $O(m \log n \log c)$，可以通过本题。

## 代码实现
```cpp
#include <bits/stdc++.h>
#define ls (rt << 1)
#define rs (ls | 1)
#define mid ((l + r) >> 1)
using namespace std;

typedef long long ll;
const int maxn = 5e4, maxm = maxn << 2;
int n, m, q, ans[maxn + 3];
ll tag[maxm + 3], sum[maxm + 3], res[maxn + 3];

struct event {
	int id, a, b, c;
} e[maxn + 3], tmp[maxn + 3];

void push_down(int rt, int l, int r) {
	tag[ls] += tag[rt], sum[ls] += tag[rt] * (mid - l + 1);
	tag[rs] += tag[rt], sum[rs] += tag[rt] * (r - mid);
	tag[rt] = 0;
}

void maintain(int rt) {
	sum[rt] = sum[ls] + sum[rs];
}

ll query(int rt, int l, int r, int lx, int rx) {
	if (l >= lx && r <= rx) {
		return sum[rt];
	}
	push_down(rt, l, r);
	ll ans = 0;
	if (lx <= mid) {
		ans += query(ls, l, mid, lx, rx);
	}
	if (rx > mid) {
		ans += query(rs, mid + 1, r, lx, rx);
	}	return ans;

}

void modify(int rt, int l, int r, int lx, int rx, int x) {
	if (l >= lx && r <= rx) {
		tag[rt] += x, sum[rt] += (r - l + 1) * x;
		return;
	}
	push_down(rt, l ,r);
	if (lx <= mid) {
		modify(ls, l, mid, lx, rx, x);
	}
	if (rx > mid) {
		modify(rs, mid + 1, r, lx, rx, x);
	}
	maintain(rt);
}

void solve(int l, int r, int L, int R) {
	if (l > r) {
		return;
	}
	if (L == R) {
		for (int i = l; i <= r; i++) {
			if (e[i].id) {
				ans[e[i].id] = L;
			}
		}
		return;
	}
	int M = (L + R) / 2;
	for (int i = l; i <= r; i++) {
		if (!e[i].id && e[i].c > M) {
			modify(1, 1, n, e[i].a, e[i].b, 1);
		} else {
			res[i] = query(1, 1, n, e[i].a, e[i].b);
		}
	}
	for (int i = l; i <= r; i++) {
		if (!e[i].id && e[i].c > M) {
			modify(1, 1, n, e[i].a, e[i].b, -1);
		}
	}
	int p = l, q = r;
	for (int i = l; i <= r; i++) {
		if (!e[i].id) {
			if (e[i].c <= M) {
				tmp[p++] = e[i];
			} else {
				tmp[q--] = e[i];
			}
		} else {
			if (res[i] < e[i].c) {
				tmp[p] = e[i];
				tmp[p++].c -= res[i];
			} else {
				tmp[q--] = e[i];
			}
		}
	}
	reverse(tmp + q + 1, tmp + r + 1);
	for (int i = l; i <= r; i++) {
		e[i] = tmp[i];
	}
	solve(l, p - 1, L, M);
	solve(p, r, M + 1, R);
}

int main() {
	scanf("%d %d", &n, &m);
	for (int i = 1, t; i <= m; i++) {
		scanf("%d %d %d %d", &t, &e[i].a, &e[i].b, &e[i].c);
		e[i].id = t == 1 ? 0 : ++q;
	}
	solve(1, m, 0, n);
	for (int i = 1; i <= q; i++) {
		printf("%d\n", ans[i]);
	}
	return 0;
}
```