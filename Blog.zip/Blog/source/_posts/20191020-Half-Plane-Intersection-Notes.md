---
title: 「学习笔记」半平面交与凸包的对偶
date: 2019-10-20 00:00:00
mathjax: true
tags:
	- 学习笔记
	- 计算几何
---



# 前言

以后的博客中可能会有一些计算几何的内容。

李超线段树已经在路上了。

~~又水了一篇博客呢~~

<!--more-->

# 算法

本文主要参考[这篇博客](http://trinkle.blog.uoj.ac/blog/235)。

问题：给定一些形如 $y \le kx + b$ 的半平面，求它们的交。

![](/images/20191020-Half-Plane-Intersection-Notes-0.png)

不难发现这个图形的轮廓一定是某个上凸壳。

结论：将一条线视作一个点 $(k_i, b_i)$，做这些点的上凸壳，在凸壳上的点都在半平面交上。证明如下：

考虑怎么求半平面交。首先将斜率从大到小排序，然后将直线依次加入半平面交。发现半平面交一定满足：相邻两直线的交点横坐标单调递增。维护一个栈表示当前的半平面交，栈顶元素是其中斜率最小的。现在我们要加入一条斜率比栈中任何一个元素都小的直线。我们记新直线为 $l_1$，此时的栈顶为 $l_2$，栈顶下面的元素为 $l_3$。

![](/images/20191020-Half-Plane-Intersection-Notes-1.png)

如图，如果 $l_1$ 和 $l_2$ 的交点在 $l_1, l_3$ 交点的右边（蓝色线），那么就直接把新的线加入栈中；否则（红色线），我们就需要弹出栈顶元素。也就是说，我们要一直弹栈，直到 $\frac{b_2 - b_1}{k_1 - k_2} > \frac{b_3 - b_1}{k_1 - k_3}$。

相信聪明的你已经已经看出，这个式子和凸包的式子十分类似。于是我们就可以用解凸包的方法来解半平面交了。

# 代码实现

这里放了一道 ZR 的题目，题意转化后就变成了给定 $n$ 条直线，每次询问编号在一个区间内部的直线中某个横坐标上的最小值。考虑建出线段树，然后每个节点维护一个多条直线的最小值的轮廓（其实就是半平面交）就行了。求半平面交的内容在结构体 `ds` 内部。时间复杂度 $O(n \log^2 n)$。（其实可以 $O(n \log n)$ 但是懒得写）

```cpp
#include <bits/stdc++.h>
using namespace std;

namespace __main__ {
	typedef long long ll;
	typedef __int128 lll;
	typedef double db;
	const int maxn = 1e5, maxm = 1 << 18, logn = 17, maxk = maxn * 18, inf = 1e9;
	const ll infl = ll(1e18 + .5);
	int n, m, q, l_2[maxn + 3];

	struct ds {
		int n, a[maxn + 3], mn[logn + 3][maxn + 3], top, st[maxn + 3];
		int tot, lft[maxm + 3], cnt[maxm + 3], id[maxk + 3];
		ll b[maxn + 3], s[maxn + 3], p[maxk + 3];
		pair<int, ll> pr[maxn + 3];

		#define mid ((l + r) >> 1)
		#define ls (x << 1)
		#define rs (ls | 1)

		bool check(int i, int j, int k) {
			return (lll) (b[i] - b[j]) * (a[i] - a[k]) < (lll) (b[i] - b[k]) * (a[i] - a[j]);
		}

		void bao(int l, int r) {
			top = 0;
			for (int i = l, id; i <= r; i++) {
				id = pr[i].second;
				while (top > 1 && !check(id, st[top], st[top - 1])) {
					top--;
				}
				st[++top] = id;
			}
		}

		void build(int x, int l, int r) {
			if (l == r) {
				pr[l] = make_pair(-a[l], l);
			} else {
				build(ls, l, mid);
				build(rs, mid + 1, r);
				inplace_merge(pr + l, pr + mid + 1, pr + r + 1);
			}
			bao(l, r);
			cnt[x] = top, lft[x] = tot + 1;
			for (int i = 1; i <= top; i++) {
				id[++tot] = st[i];
				if (i < top) {
					db t = -1. * (b[st[i + 1]] - b[st[i]]) / (a[st[i + 1]] - a[st[i]]);
					p[tot] = t - 3;
					while (p[tot] * a[st[i]] + b[st[i]] <= p[tot] * a[st[i + 1]] + b[st[i + 1]]) {
						p[tot]++;
					} 
					p[tot]--;
				}
			}
			p[tot] = infl;
		}

		ll query(int x, int l, int r, int lx, int rx, int k) {
			if (l >= lx && r <= rx) {
				int t = lower_bound(p + lft[x], p + lft[x] + cnt[x], k) - p;
				return 1ll * k * a[id[t]] + b[id[t]];
			}
			ll ans = infl;
			if (lx <= mid) {
				ans = min(ans, query(ls, l, mid, lx, rx, k));
			}
			if (rx > mid) {
				ans = min(ans, query(rs, mid + 1, r, lx, rx, k));
			}
			return ans;
		}

		#undef mid
		#undef ls
		#undef rs

		void init() {
			for (int i = 1; i <= n; i++) {
				b[i] = 2ll * i * a[i] - 2 * s[i - 1];
				s[i] = s[i - 1] + a[i];
				mn[0][i] = a[i];
			}
			for (int k = 1; 1 << k <= n; k++) {
				for (int i = 1, j = (1 << (k - 1)) + 1; i <= n - (1 << k) + 1; i++, j++) {
					mn[k][i] = min(mn[k - 1][i], mn[k - 1][j]);
				}
			}
			build(1, 1, n);
		}

		ll sum(int l, int r) {
			return s[r] - s[l - 1];
		}

		int rmq(int l, int r) {
			if (l > r) return inf;
			int x = l_2[r - l + 1];
			return min(mn[x][l], mn[x][r - (1 << x) + 1]);
		}

		ll solve(int x, int y) {
			return query(1, 1, n, max(1	, x - y / 2), max(1, x - 1), y - 2 * x) + 2 * s[x - 1];
		}
	} a, b, c, d;

	void main() {
		scanf("%d %d %d", &n, &m, &q);
		a.n = n - 1, c.n = n - 1;
		b.n = m - 1, d.n = m - 1;
		for (int i = 2; i <= max(n, m); i++) {
			l_2[i] = l_2[i >> 1] + 1;
		}
		for (int i = 1, x; i < n; i++) {
			scanf("%d", &x);
			a.a[i] = x, c.a[n - i] = x;
		}
		for (int i = 1, x; i < m; i++) {
			scanf("%d", &x);
			b.a[i] = x, d.a[m - i] = x;
		}
		a.init(), b.init();
		c.init(), d.init();

		for (int i = 1, x_1, y_1, x_2, y_2, d_a, d_b, x; i <= q; i++) {
			scanf("%d %d %d %d", &x_1, &y_1, &x_2, &y_2);
			if (x_1 > x_2) swap(x_1, x_2);
			if (y_1 > y_2) swap(y_1, y_2);
			d_a = x_2 - x_1, d_b = y_2 - y_1;
			x_2--, y_2--;
			ll ans = a.sum(x_1, x_2) + b.sum(y_1, y_2);
			if (d_a < d_b) {
				x = d_b - d_a;
				if (x & 1) x--;
				ans += min(1ll * a.rmq(x_1, x_2) * x, min(a.solve(x_1, x), c.solve(n - x_2, x)));
			} else {
				x = d_a - d_b;
				if (x & 1) x--;
				ans += min(1ll * b.rmq(y_1, y_2) * x, min(b.solve(y_1, x), d.solve(m - y_2, x)));
			}
			printf("%lld\n", ans);
		}
	}
}

int main() {
	__main__::main();
	return 0;
}
```

