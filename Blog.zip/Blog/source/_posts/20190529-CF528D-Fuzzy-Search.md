---
title: 「Codeforces 528D」Fuzzy Search（多项式）
date: 2019-05-29 00:00:00
mathjax: true
tags:
	- 多项式
---

# 题目大意
[「Codeforces 528D」Fuzzy Search](https://codeforces.com/problemset/problem/528/D)

给定两个字符串 $S, T$（只包含 $4$ 个字母）和非负整数 $k$，定义模式串和文本串的一段是模糊匹配的，当且仅当对于模式串中的每个位置 $i$，都能在文本串中找到字符 $S_j = T_i$ 且 $\vert i - j \vert \le k$。

问模式串被匹配了几次。

我们记 $n = \vert S \vert, m = \vert T \vert$。

数据范围：$n, m, k \le 2 \times 10^5$。

<!--more-->

$k = 1$ 时的样例：
![样例图示](/images/20190529-CF528D-Fuzzy-Search-1.png)

# 思路分析
由于字符集很小，我们考虑对于每种字符计算它能在那些位置出现。这显然可以通过差分 + 前缀和在线性时间内解决。

我们将字符 $ch$ 的可出现位置集合看作一个 01 串 $A(ch)$，那么答案就等于对于每个 $1 \le i \le m$，$A(T_i)$ 左移 $m - i$ 位后得到的 $m$ 个 01 串的交的大小。

于是我们可以对模式串中每个不同的字母构造多项式 $B_{ch}$，和 $A_{ch}$ 相乘后的多项式中，某项系数对应的位置合法当且仅当它的系数等于 $T$ 中 $ch$ 出现的次数。所以计算完这些我们最后就只需计算 $4$ 个 01 串的交。

时间复杂度瓶颈在于卷积，用 FFT 可以优化到 $O(n \log n)$。

# 代码实现
```cpp
#include <cmath>
#include <cstdio>
#include <algorithm>
using namespace std;

typedef double db;
const int maxn = 2e5, maxm = 1 << 19;
const db pi = acos(-1);
int n, m, L, M[200], a[5][maxn + 3], b[5][maxn + 3], c[5][maxn + 3], k, rev[maxm + 3];
char s[maxn + 3];

struct complex {
	db r, i;
	complex(db r = 0, db i = 0): r(r), i(i) {}
	friend complex operator+ (const complex &a, const complex &b) {
		return complex(a.r + b.r, a.i + b.i);
	}
	friend complex operator- (const complex &a, const complex &b) {
		return complex(a.r - b.r, a.i - b.i);
	}
	friend complex operator* (const complex &a, const complex &b) {
		return complex(a.r * b.r - a.i * b.i, a.r * b.i + a.i * b.r);
	}
	friend complex operator/ (const complex &a, const db &b) {
		return complex(a.r / b, a.i / b);
	}
};

complex A[maxm + 3], B[maxm + 3], C[maxm + 3];

void dft(complex a[], int n, int type) {
	for (int i = 0; i < n; i++) if (i < rev[i]) {
		swap(a[i], a[rev[i]]);
	}
	for (int k = 1; k < n; k *= 2) {
		complex x = complex(cos(pi / k), type * sin(pi / k));
		for (int i = 0; i < n; i += k * 2) {
			complex y = 1;
			for (int j = i; j < i + k; j++, y = x * y) {
				complex p = a[j], q = a[j + k] * y;
				a[j] = p + q, a[j + k] = p - q;
			}
		}
	}
	if (type == -1) {
		for (int i = 0; i < n; i++) {
			a[i] = a[i] / n;
		}
	}
}

inline int id(char ch) {
	return M[ch];
}

int main() {
	M['A'] = 0, M['T'] = 1, M['G'] = 2, M['C'] = 3;
	scanf("%d %d %d %s", &n, &m, &L, s + 1);
	for (int i = 1; i <= n; i++) {
		int x = id(s[i]), l = max(1, i - L), r = min(n, i + L);
		a[x][l - 1]++, a[x][r]--;
	}
	for (int k = 0; k < 4; k++) {
		for (int i = 1; i < n; i++) {
			a[k][i] += a[k][i - 1];
		}
		for (int i = 0; i < n; i++) {
			a[k][i] = a[k][i] > 0;
		}
	}
	scanf("%s", s + 1);
	for (int i = 1; i <= m; i++) {
		b[id(s[i])][m - i] = 1;
	}
	for (k = 0; 1 << k <= n + m - 2; k++);
	for (int i = 1; i < 1 << k; i++) {
		rev[i] = (rev[i >> 1] >> 1) | ((i & 1) << (k - 1));
	}
	for (int t = 0; t < 4; t++) {
		int sum = 0;
		for (int i = 0; i <= n - 1; i++) {
			A[i] = a[t][i];
		}
		for (int i = n; i < 1 << k; i++) {
			A[i] = 0;
		}
		for (int i = 0; i <= m - 1; i++) {
			B[i] = b[t][i], sum += b[t][i];
		}
		for (int i = m; i < 1 << k; i++) {
			B[i] = 0;
		}
		dft(A, 1 << k, 1), dft(B, 1 << k, 1);
		for (int i = 0; i < 1 << k; i++) {
			C[i] = A[i] * B[i];
		}
		dft(C, 1 << k, -1);
		for (int i = m - 1; i < n; i++) {
			int x = C[i].r + .5;
			if (x == sum) {
				c[t][i + 1] = 1;
			}
		}
	}
	int ans = 0;
	for (int i = m; i <= n; i++) {
		if (c[0][i] && c[1][i] && c[2][i] && c[3][i]) {
			ans++;
		}
	}
	printf("%d\n", ans);
	return 0;
}
```

# 课后练习
[「BZOJ 4259」残缺的字符串（权限题）](https://www.lydsy.com/JudgeOnline/problem.php?id=4259)