---
title: 「学习笔记」快速傅立叶变换
date: 2019-05-26 00:00:00
mathjax: true
tags:
	- 学习笔记
	- 多项式
---

快速傅立叶变换（Fast Fourier Transformation）可以将多项式在系数表示法和（单位复根的）点值表示法之间互相转化，而它的时间复杂度仅为 $O(n \log n)$。

# 推荐阅读

[Algocode 算法博客](https://algocode.net/2018/05/03/20180503-KB-Fast-Fourier-Transform/)

<!--more-->

# 代码实现

快速傅立叶变换（FFT）：

```cpp
#include <cmath>
#include <cstdio>
#include <algorithm>
using namespace std;

typedef double db;
const int maxn = 1e5, maxm = 1 << 18;
const db pi = acos(-1);
int n, m, k, rev[maxm + 3], ans[maxm + 3];

struct complex {
	db r, i;
	complex(db r = 0, db i = 0): r(r), i(i) {}
	friend complex operator+ (const complex &a, const complex &b) {
		return complex(a.r + b.r, a.i + b.i);
	}
	friend complex operator- (const complex &a, const complex &b) {
		return complex(a.r - b.r, a.i - b.i);
	}
	friend complex operator* (const complex &a, const complex &b) {
		return complex(a.r * b.r - a.i * b.i, a.r * b.i + a.i * b.r);
	}
	friend complex operator/ (const complex &a, const db &b) {
		return complex(a.r / b, a.i / b);
	}
};

complex a[maxm + 3], b[maxm + 3], c[maxm + 3];

void dft(complex a[], int n, int type) {
	for (int i = 0; i < n; i++) if (i < rev[i]) {
		swap(a[i], a[rev[i]]);
	}
	for (int k = 1; k < n; k *= 2) {
		complex x = complex(cos(pi / k), type * sin(pi / k));
		for (int i = 0; i < n; i += k * 2) {
			complex y = 1;
			for (int j = i; j < i + k; j++, y = x * y) {
				complex p = a[j], q = a[j + k] * y;
				a[j] = p + q, a[j + k] = p - q;
			}
		}
	}
	if (type == -1) {
		for (int i = 0; i < n; i++) {
			a[i] = a[i] / n;
		}
	}
}

int main() {
	scanf("%d %d", &n, &m);
	for (int i = 0, x; i <= n; i++) {
		scanf("%d", &x), a[i].r = x;
	}
	for (int i = 0, x; i <= m; i++) {
		scanf("%d", &x), b[i].r = x;
	}
	for (k = 0; 1 << k <= n + m; k++);
	for (int i = 1; i < 1 << k; i++) {
		rev[i] = (rev[i >> 1] >> 1) | ((i & 1) << (k - 1));
	}
	dft(a, 1 << k, 1), dft(b, 1 << k, 1);
	for (int i = 0; i < 1 << k; i++) {
		c[i] = a[i] * b[i];
	}
	dft(c, 1 << k, -1);
	for (int i = 0; i <= n + m; i++) {
		ans[i] = c[i].r + .5;
	}
	for (int i = 0; i <= n + m; i++) {
		printf("%d%c", ans[i], " \n"[i == n + m]);
	}
	return 0;
}
```

快速数论变换（NTT）：

```cpp
#include <cstdio>
#include <algorithm>
using namespace std;

const int maxn = 1e5, maxm = 1 << 18, mod = 998244353, g = 3;
int n, m, k, rev[maxm + 3], a[maxm + 3], b[maxm + 3], c[maxm + 3];

inline int func(int x, int y = mod) {
	return x < 0 ? x + y : x < y ? x : x - y;
}

int qpow(int a, int b) {
	int c = 1;
	for (; b; b >>= 1, a = 1ll * a * a % mod) {
		if (b & 1) c = 1ll * a * c % mod;
	}
	return c;
}

void dft(int a[], int n, int type) {
	for (int i = 0; i < n; i++) if (i < rev[i]) {
		swap(a[i], a[rev[i]]);
	}
	for (int k = 1; k < n; k *= 2) {
		int x = qpow(g, func(type * (mod - 1) / (k * 2), mod - 1));
		for (int i = 0; i < n; i += 2 * k) {
			int y = 1;
			for (int j = i; j < i + k; j++, y = 1ll * x * y % mod) {
				int p = a[j], q = 1ll * a[j + k] * y % mod;
				a[j] = func(p + q), a[j + k] = func(p - q);
			}
		}
	}
	if (type == -1) {
		int x = qpow(n, mod - 2);
		for (int i = 0; i < n; i++) {
			a[i] = 1ll * a[i] * x % mod;
		}
	}
}

int main() {
	scanf("%d %d", &n, &m);
	for (int i = 0; i <= n; i++) {
		scanf("%d", &a[i]);
	}
	for (int i = 0; i <= m; i++) {
		scanf("%d", &b[i]);
	}
	for (k = 0; 1 << k <= n + m; k++);
	for (int i = 1; i < 1 << k; i++) {
		rev[i] = (rev[i >> 1] >> 1) | ((i & 1) << (k - 1));
	}
	dft(a, 1 << k, 1), dft(b, 1 << k, 1);
	for (int i = 0; i < 1 << k; i++) {
		c[i] = 1ll * a[i] * b[i] % mod;
	}
	dft(c, 1 << k, -1);
	for (int i = 0; i <= n + m; i++) {
		printf("%d%c", c[i], " \n"[i == n + m]);
	}
	return 0;
}
```