---
title: 「学习笔记」朱 - 刘算法求解最小树形图
date: 2019-06-25 00:00:00
mathjax: true
tags:
	- 最小生成树

---

# 什么是最小树形图
无向图上有最小生成树，那么有向图上呢？有向图上的最小生成树称为 “最小树形图”，英文叫 Directed Minimum Spanning Tree。

如果把一个树形图的有向边替换成无向边，它会变成一棵生成树。但与生成树不同的是，树形图中会确定一个根，它必须满足根能够到达每个结点。最小树形图是所有树形图中边权和最小的一个。

<!--more-->

# 朱 - 刘算法简介
一般来讲在图中求最小树形图时会确定一个根结点。有一个时间复杂度为 $O(nm)$ 的算法可以解决这个问题：朱 - 刘算法（英文 Chu - Liu Algorithm），是两个中国人一起发明的算法。

朱 - 刘算法的基本思想是每次贪心地选出每个点最小的父亲，得出的图如果不是树形图，那么将选出的环进行缩点，对边权进行修改，然后迭代这个过程，直到图变为最小树形图为止。

# 朱 - 刘算法模版
建议看一下[「模板」最小树形图（Luogu 4716）
](https://www.luogu.org/problemnew/show/P4716)这题的题解，里面有确定根结点的最小树形图详细的讲解。注意大部分题解的时间复杂度都是 $O(n^3)$ 而不是 $O(nm)$ 的，问题出在它们找环的过程不能保证复杂度。如果不会找环的话可以看看[「NOIP 2015」信息传递（Luogu 2661）](https://www.luogu.org/problemnew/show/P2661)这题，题解中的复杂度都是正确的。

```cpp
#include <cstdio>

const int maxn = 100, maxm = 1e4, inf = 1e9 + 1;
int n, m, rt, mn[maxn + 3], fa[maxn + 3], bel[maxn + 3], id[maxn + 3];

struct edge {
	int u, v, w;
} e[maxm + 3];

int chu_liu() {
	int ans = 0;
	while (true) {
		for (int i = 1; i <= n; i++) {
			mn[i] = inf, fa[i] = 0, bel[i] = 0, id[i] = 0;
		}
		for (int i = 1; i <= m; i++) if (e[i].u != e[i].v) {
			if (e[i].w < mn[e[i].v]) {
				mn[e[i].v] = e[i].w, fa[e[i].v] = e[i].u;
			}
		}
		for (int i = 1; i <= n; i++) {
			if (i != rt && !fa[i]) return -1;
		}
		int cnt = 0;
		for (int i = 1; i <= n; i++) if (i != rt) {
			ans += mn[i];
			int x = i;
			while (!bel[x] && x != rt) {
				bel[x] = i, x = fa[x];
			}
			if (bel[x] == i) {
				++cnt;
				do {
					id[x] = cnt, x = fa[x];
				} while (!id[x]);
			}
		}
		if (!cnt) {
			break;
		}
		for (int i = 1; i <= n; i++) {
			if (!id[i]) id[i] = ++cnt;
		}
		for (int i = 1; i <= m; i++) {
			int u = e[i].u, v = e[i].v;
			e[i].u = id[u], e[i].v = id[v];
			if (id[u] != id[v]) e[i].w -= mn[v];
		}
		rt = id[rt];
		n = cnt;
	}
	return ans;
}

int main() {
	scanf("%d %d %d", &n, &m, &rt);
	for (int i = 1; i <= m; i++) {
		scanf("%d %d %d", &e[i].u, &e[i].v, &e[i].w);
	}
	printf("%d\n", chu_liu());
	return 0;
}
```

# 朱 - 刘算法的应用
## 不确定根的最小树形图
这次我们不规定树形图的根，要求最小树形图。

容易发现我们建立一个超级源点，然后向每一个结点连长度为 $\inf$ 的边，最后算出答案后减去 $\inf$ 即可。发现为了使答案更优，最多只会从超级源点连出一条边，从而保证了去掉超级源点后的根是唯一的。

时间复杂度 $O(nm)$。

## 「BZOJ 4349」最小树形图
### 题目大意
[「BZOJ 4349」最小树形图](https://www.lydsy.com/JudgeOnline/problem.php?id=4349)

有 $n$ 个堡垒，第 $i$ 个堡垒的防御力是 $A_i$，一共要打 $B_i$ 次。有 $m$ 组关系，每组形如 “打了 $x$ 号堡垒以后 $y$ 号堡垒的防御力都会降低为 $z$”，问打完所有堡垒的最小代价。

数据范围：$n \le 50$。

### 思路分析
容易发现最优策略是所有堡垒打完一遍再慢慢打剩下的，现在问题变成了决定第一次打堡垒的顺序。建立超级源点，向每个堡垒连权值为 $A_i$ 的边。对于每一条关系，从 $x$ 号堡垒向 $y$ 号堡垒连权值为 $z$ 的边即可。根据建图方式容易证明算法正确性。

时间复杂度 $O(nm)$。

### 代码实现
```cpp
#include <cstdio>
#include <algorithm>
using namespace std;

typedef double db;
const int maxn = 60, maxm = 3e3;
const db inf = 1e9 + 1;
int n, m, rt, B[maxn + 3], fa[maxn + 3], bel[maxn + 3], id[maxn + 3];
db A[maxn + 3], C[maxn + 3], mn[maxn + 3];

struct edge {
	int u, v;
	db w;
} e[maxm + 3];

db chu_liu() {
	db ans = 0;
	while (true) {
		for (int i = 1; i <= n; i++) {
			mn[i] = inf, fa[i] = 0, bel[i] = 0, id[i] = 0;
		}
		for (int i = 1; i <= m; i++) if (e[i].u != e[i].v) {
			if (e[i].w < mn[e[i].v]) {
				mn[e[i].v] = e[i].w, fa[e[i].v] = e[i].u;
			}
		}
		int cnt = 0;
		for (int i = 1; i <= n; i++) if (i != rt) {
			ans += mn[i];
			int x = i;
			while (!bel[x] && x != rt) {
				bel[x] = i, x = fa[x];
			}
			if (bel[x] == i) {
				++cnt;
				do {
					id[x] = cnt, x = fa[x];
				} while (!id[x]);
			}
		}
		if (!cnt) {
			break;
		}
		for (int i = 1; i <= n; i++) {
			if (!id[i]) id[i] = ++cnt;
		}
		for (int i = 1; i <= m; i++) {
			int u = e[i].u, v = e[i].v;
			e[i].u = id[u], e[i].v = id[v];
			if (id[u] != id[v]) e[i].w -= mn[v];
		}
		rt = id[rt];
		n = cnt;
	}
	return ans;
}

int main() {
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf("%lf %d", &A[i], &B[i]);
		C[i] = A[i];
	}
	scanf("%d", &m);
	for (int i = 1; i <= m; i++) {
		scanf("%d %d %lf", &e[i].u, &e[i].v, &e[i].w);
		C[e[i].v] = min(C[e[i].v], e[i].w);
	}
	db ans = 0;
	for (int i = 1; i <= n; i++) {
		ans += C[i] * (B[i] - 1);
	}
	for (int i = 1; i <= n; i++) {
		e[++m].u = n + 1, e[m].v = i, e[m].w = A[i];
	}
	rt = ++n;
	ans += chu_liu();
	printf("%.2lf\n", ans);
	return 0;
}
```
## 「SCOI 2012」滑雪
### 题目大意
[「SCOI 2012」滑雪（Luogu 2573）](https://www.luogu.org/problemnew/show/P2573)

给定 $n$ 个地点 $m$ 条边，每个地点有高度，每条边有通过时间，且起点高度大于等于终点高度。问这个图以 $1$ 为根的最小树形图。

数据范围：$n \le 10^5, m \le 10^6$。

### 思路分析
朴素算法不能通过，考虑利用这题的性质。

我们先搜出能够到达的所有点，再将边以终点高度为第一关键字，边权为第二关键字排序后，跑 Kruskal 即可。

时间复杂度 $O(m \log m)$。

### 代码实现
```cpp
#include <cstdio>
#include <algorithm>
using namespace std;

typedef long long ll;
const int maxn = 1e5, maxm = 2e6;
int n, m, k, cnt, h[maxn + 3], tot, ter[maxm + 3], wei[maxm + 3], nxt[maxm + 3], lnk[maxn + 3], fa[maxn + 3];
bool vis[maxn + 3];

struct edge {
	int u, v, w;
	friend bool operator < (const edge &a, const edge &b) {
		return h[a.v] == h[b.v] ? a.w < b.w : h[a.v] > h[b.v];
	}
} e[maxm + 3];

void add(int u, int v, int w) {
	ter[++tot] = v, wei[tot] = w;
	nxt[tot] = lnk[u], lnk[u] = tot;
}

void dfs(int u) {
	vis[u] = true;
	cnt++;
	for (int i = lnk[u], v, w; i; i = nxt[i]) {
		v = ter[i], w = wei[i];
		e[++k].u = u, e[k].v = v, e[k].w = w;
		if (!vis[v]) {
			dfs(v);
		}
	}
}

int find(int x) {
	return fa[x] == x ? x : fa[x] = find(fa[x]);
}

int main() {
	scanf("%d %d", &n, &m);
	for (int i = 1; i <= n; i++) {
		scanf("%d", &h[i]);
	}
	for (int i = 1, u, v, w; i <= m; i++) {
		scanf("%d %d %d", &u, &v, &w);
		if (h[u] >= h[v]) add(u, v, w);
		if (h[v] >= h[u]) add(v, u, w);
	}
	dfs(1);
	sort(e + 1, e + k + 1);
	for (int i = 1; i <= n; i++) {
		fa[i] = i;
	}
	ll ans = 0;
	for (int i = 1; i <= k; i++) {
		int u = find(e[i].u), v = find(e[i].v);
		if (u == v) continue;
		fa[u] = v, ans += e[i].w;
	}
	printf("%d %lld\n", cnt, ans);
	return 0;
}
```