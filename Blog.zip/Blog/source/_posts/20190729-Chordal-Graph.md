---
title: 「学习笔记」弦图与完美消除序列
date: 2019-07-29 00:00:01
mathjax: true
tags:
	- 学习笔记
	- 其他

---

# 弦图
弦图是一类特殊的无向图。弦图上的所有简单环上都至少有一条弦，其中弦是联结环上两个不相邻的点的边。

这个限制等价于图中存在至少一个完美消除序列。

（好像学了一个没啥用的东西）

<!--more-->

# 完美消除序列
一个完美消除序列是一个排列 $a_1, a_2, \cdots, a_n$，满足对于任意的 $i$，都有 $a_i, a_{i + 1}, \cdots, a_n$ 形成的导出子图中与 $a_i$ 相邻的点两两之间有边。

如何求完美消除序列呢？共有两种算法，可以在 [CDQ 的 PPT](https://wenku.baidu.com/view/6f9f2223dd36a32d73758126.html) 中学习，时间复杂度可以做到 $O(n + m)$。

# 例题
## 题目大意
给定一个 $n$ 个点 $m$ 条边的弦图，求它的色数。

数据范围：$n \le 10^4, m \le 10^6$。

## 思路分析
求出一个完美消除序列，然后贪心地倒着染色。不难发现这肯定是对的，因为与当前点相邻的染过色的点的颜色互不相同。

因为图的色数是 $O(\sqrt m)$ 的，所以总共染色的复杂度是 $O(n \sqrt m)$，可以通过本题。

## 代码实现
```cpp
#include <bits/stdc++.h>
using namespace std;

const int maxn = 2e4;
int n, m, a[maxn + 3], c[maxn + 3], l[maxn + 3], r[maxn + 3], col[maxn + 3], vis[maxn + 3];
bool b[maxn + 3];
vector<int> G[maxn + 3];

void get_array() {
	for (int i = 0; i <= 2 * n; i++) {
		l[i] = r[i] = -1;
	}
	for (int i = 1, t = 0; i <= n; i++) {
		l[n + i] = t, r[t] = n + i, t = n + i;
	}
	int mx = 0;
	for (int k = 1; k <= n; k++) {
		while (r[mx] == -1) {
			mx--;
		}
		int u = r[mx] - n, t = r[u + n];
		l[t] = mx, r[mx] = t;
		a[k] = u, b[u] = true;
		for (int i = 0, v, lx, rx; i < G[u].size(); i++) {
			v = G[u][i];
			if (b[v]) {
				continue;
			}
			lx = l[n + v], rx = r[n + v];
			r[lx] = rx, l[rx] = lx, c[v]++;
			l[n + v] = r[n + v] = -1;
			if (~r[c[v]]) {
				l[r[c[v]]] = n + v, r[n + v] = r[c[v]];
			}
			r[c[v]] = n + v, l[n + v] = c[v];
		}
		mx++;
	}
}

int main() {
	scanf("%d %d", &n, &m);
	for (int i = 1, u, v; i <= m; i++) {
		scanf("%d %d", &u, &v);
		G[u].push_back(v), G[v].push_back(u);
	}
	get_array();
	int ans = 0;
	for (int _ = 1, i; _ <= n; _++) {
		i = a[_];
		for (int j = 0; j < G[i].size(); j++) {
			vis[col[G[i][j]]] = i;
		}
		for (int j = 1; j <= n; j++) {
			ans = max(ans, j);
			if (vis[j] != i) {
				col[i] = j;
				break;
			}
		}
	}
	printf("%d\n", ans);
	return 0;
}
```