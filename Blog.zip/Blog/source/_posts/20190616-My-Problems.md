---
title: 我出的一些题目
date: 2019-06-16 00:00:00
mathjax: true
top: true
tags:
	- 出题
---

博主无聊时会出一些题目，难度不等。欢迎大家来玩！

注意：题目前带 `*` 的表示还没造完 / 已经投给某个比赛了，所以暂时不能查看。

<!--more-->

# 目录
## 星空夜
[「Luogu U71500 / EOJ 191C」星空夜（提高组）](https://www.luogu.org/problemnew/show/U71500)

命题报告：[「Luogu U71500 / EOJ 191C」星空夜 命题报告](/2019/07/26/20190726-EOJ191C-LCM2)

## 大白菜的疑惑
[「Luogu U74074」大白菜的疑惑（普及组）](https://www.luogu.org/problemnew/show/U74074)

命题报告：[「Luogu U74074」大白菜的疑惑 命题报告](/2019/06/20/20190620-U74074-Math/)

## 黄队的宫殿
[「Luogu U85089」黄队的宫殿（普及组）](https://www.luogu.org/problemnew/show/U85089)

命题报告：它在一个神秘的地方，自己找吧。

## * 草
[「Luogu U85053」草（提高组）](https://www.luogu.org/problem/U85053)

## * 定点飞行
[*「Luogu U75331」定点飞行（省选）](https://www.luogu.org/problemnew/show/U75331)

## * 拆塔
[*「Luogu U81838」拆塔（省选）](https://www.luogu.org/problemnew/show/U81838)
