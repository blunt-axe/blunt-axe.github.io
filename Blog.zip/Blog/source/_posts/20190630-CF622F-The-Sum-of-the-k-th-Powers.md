---
title: 「Codeforces 622F」The Sum of the k-th Powers（多项式）
date: 2019-06-30 00:00:02
mathjax: true
tags:
	- 多项式

---

# 题目大意
[「Codeforces 622F」The Sum of the k-th Powers](https://codeforces.com/problemset/problem/622/F)

求 $\sum_{i = 1}^{n} i^k \bmod 10^9 + 7$。

数据范围：$n \le 10^9, k \le 10^6$。

<!--more-->

# 思路分析
直接做显然是不行的，我们猜想 $\sum_{i = 1}^{n} i^k$ 是一个 $k + 2$ 次多项式。我们先对于 $1 \le i \le k + 2$ 计算出 $a_i = \sum_{j = 1}^{i} j^k$ 的值，然后使用[拉格朗日插值](/2019/06/30/20190630-Lagrange-Interpolation/)来求出该多项式在 $n$ 处的值即可。然而拉格朗日插值的复杂度是 $O(k^2)$ 的，不能通过此题。

考虑拉格朗日插值的过程。根据拉格朗日插值公式，答案为：
$$
\begin {align}
f(n) &= \sum_{i} a_i \prod_{i \neq j} \frac{n - j}{i - j} \\
&= \left( \prod_{i} (n - i) \right) \times \sum_i \frac{a_i}{n - i} \prod_{i \neq j} \frac{1}{i - j} \\
&= \left( \prod_{i} (n - i) \right) \times \sum_i \frac{a_i}{n - i} \left( \prod_{i > j} \frac{1}{i - j} \times \prod_{i < j} \frac{1}{i - j} \right) 
\end {align} 
$$

而我们有：
$$\prod_{i > j} \frac{1}{i - j} \times \prod_{i < j} \frac{1}{i - j} =  (i - 1)! \times (-1)^{k + 2 - i} (k + 2 - i)!$$

所以我们只需要预处理阶乘即可计算答案了。由于一开始的 $k$ 次方和计算和计算答案时需要求逆元，时间复杂度为 $O(k \log k)$。

能不能线性呢？答案是肯定的。注意到 $\text{ID}_k(x)$ 是完全积性函数，我们可以使用线性筛在 $O(k + \frac{k \log k}{\ln k}) = O(k)$ 的时间内算出它的前缀和。对于逆元，我们只需要使用线性求逆元的科技即可。这样，时间复杂度就优化成了 $O(k)$。

# 代码实现
```cpp
#include <cstdio>

const int maxn = 1e6, mod = 1e9 + 7;
int n, k, m, p[maxn + 3], f[maxn + 3], fact[maxn + 3], finv[maxn + 3];
int num[maxn + 3], suf[maxn + 3], inv[maxn + 3];
bool b[maxn + 3];

int func(int x) {
	return x < 0 ? x + mod : x < mod ? x : x - mod;
}

int qpow(int a, int b) {
	int c = 1;
	for (; b; b >>= 1, a = 1ll * a * a % mod) {
		if (b & 1) c = 1ll * a * c % mod;
	}
	return c;
}

void prework(int n) {
	f[1] = 1;
	for (int i = 2; i <= n; i++) {
		if (!b[i]) {
			f[i] = qpow(i, k);
			p[++m] = i;
		}
		for (int j = 1; j <= m && i * p[j] <= n; j++) {
			b[i * p[j]] = true;
			f[i * p[j]] = 1ll * f[i] * f[p[j]] % mod;
			if (!i % p[j]) {
				break;
			}
		}
	}
	for (int i = 1; i <= n; i++) {
		f[i] += f[i - 1];
		f[i] < mod ? 0 : f[i] -= mod;
	}
	fact[0] = 1;
	for (int i = 1; i <= n; i++) {
		fact[i] = 1ll * fact[i - 1] * i % mod;
	}
	finv[n] = qpow(fact[n], mod - 2);
	for (int i = n; i; i--) {
		finv[i - 1] = 1ll * finv[i] * i % mod;
	}
}

void solve(int pre[], int inv[], int n) {
	pre[0] = pre[n + 1] = 1;
	for (int i = 0; i <= n + 1; i++) {
		suf[i] = pre[i];
	}
	for (int i = 1; i <= n; i++) {
		pre[i] = 1ll * pre[i - 1] * pre[i] % mod;
	}
	for (int i = n; i; i--) {
		suf[i] = 1ll * suf[i + 1] * suf[i] % mod;
	}
	int x = qpow(pre[n], mod - 2);
	for (int i = 1; i <= n; i++) {
		inv[i] = 1ll * x * pre[i - 1] % mod * suf[i + 1] % mod;
	}
}

int main() {
	scanf("%d %d", &n, &k);
	prework(k + 2);
	if (n <= k + 2) {
		printf("%d\n", f[n]);
		return 0;
	}
	for (int i = 1; i <= k + 2; i++) {
		num[i] = n - i;
	}
	solve(num, inv, k + 2);
	int ans = 0;
	for (int i = 1; i <= k + 2; i++) {
		int x = 1ll * f[i] * inv[i] % mod;
		x = 1ll * x * finv[i - 1] % mod * finv[k + 2 - i] % mod;
		if ((k + 2 - i) & 1) x = func(-x);
		ans = func(ans + x);
	}
	for (int i = 1; i <= k + 2; i++) {
		ans = 1ll * ans * (n - i) % mod;
	}
	printf("%d\n", ans);
	return 0;
}
```