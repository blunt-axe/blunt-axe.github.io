---
title: 「学习笔记」挑战多项式
date: 2019-07-27 00:00:00
mathjax: true
tags:
	- 多项式

---

挑战失败 :(

暂时只会多项式加法，多项式减法，多项式乘法，多项式除法，多项式求逆，多项式积分，多项式求导。

还不会的：多项式对数函数，多项式指数函数，多项式开根，多项式快速幂，多项式多点求值，多项式快速插值。

<!--more-->

部分多项式算法模版：

```cpp
#include <bits/stdc++.h>
#define debug(...) fprintf(stderr, __VA_ARGS__)
using namespace std;

const int maxn = 1 << 18, mod = 998244353, rt = 3;
int mx, lg, rev[maxn + 3], n, m, a[maxn + 3], b[maxn + 3], q[maxn + 3], r[maxn + 3];

void settings() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
}

int qpow(int a, int b) {
	b < 0 ? b += mod - 1 : 0;
	int c = 1;
	for (; b; b >>= 1, a = 1ll * a * a % mod) {
		if (b & 1) c = 1ll * a * c % mod;
	}
	return c;
}

void dft(int A[], int n, int type) {
	for (int i = 0; i < n; i++) {
		if (i < rev[i]) swap(A[i], A[rev[i]]);
	}
	for (int k = 1; k < n; k <<= 1) {
		int x = qpow(rt, type * (mod - 1) / (k << 1));
		for (int i = 0; i < n; i += k << 1) {
			int y = 1;
			for (int j = i; j < i + k; j++, y = 1ll * x * y % mod) {
				int p = A[j], q = 1ll * A[j + k] * y % mod;
				A[j] = p + q, A[j] < mod ? 0 : A[j] -= mod;
				A[j + k] = p - q, A[j + k] < 0 ? A[j + k] += mod : 0;
			}
		}
	}
	if (type == -1) {
		int x = qpow(n, mod - 2);
		for (int i = 0; i < n; i++) {
			A[i] = 1ll * A[i] * x % mod;
		}
	}
}

void poly_conv(int A[], int B[], int C[], int n) {
	static int X[maxn + 3], Y[maxn + 3];
	copy(A, A + n + 1, X), copy(B, B + n + 1, Y);
	for (lg = 0, mx = 1; mx <= n << 1; mx <<= 1) lg++;
	for (int i = 1; i < mx; i++) {
		rev[i] = (rev[i >> 1] >> 1) | ((i & 1) << (lg - 1));
	}
	fill(X + n + 1, X + mx, 0), fill(Y + n + 1, Y + mx, 0);
	dft(X, mx, 1), dft(Y, mx, 1);
	for (int i = 0; i < mx; i++) {
		C[i] = 1ll * X[i] * Y[i] % mod;
	}
	dft(C, mx, -1);
}

void poly_add(int A[], int B[], int C[], int n) {
	for (int i = 0; i <= n; i++) {
		C[i] = A[i] + B[i], C[i] < mod ? 0 : C[i] -= mod;
	}
}

void poly_sub(int A[], int B[], int C[], int n) {
	for (int i = 0; i <= n; i++) {
		C[i] = A[i] - B[i], C[i] < 0 ? C[i] += mod : 0;
	}
}

void poly_inv(int A[], int B[], int n) {
	if (n == 0) {
		B[0] = qpow(A[0], mod - 2);
		return;
	}
	poly_inv(A, B, n >> 1);
	static int X[maxn + 3];
	for (lg = 0, mx = 1; mx <= n << 1; mx <<= 1) lg++;
	for (int i = 1; i < mx; i++) {
		rev[i] = (rev[i >> 1] >> 1) | ((i & 1) << (lg - 1));
	}
	copy(A, A + n + 1, X), fill(X + n + 1, X + mx, 0);
	dft(X, mx, 1), dft(B, mx, 1);
	for (int i = 0; i < mx; i++) {
		B[i] = 1ll * (2 + mod - 1ll * X[i] * B[i] % mod) * B[i] % mod;
	}
	dft(B, mx, -1), fill(B + n + 1, B + mx, 0);
}

void poly_div(int A[], int B[], int Q[], int R[], int n, int m) {
	static int X[maxn + 3];
	fill(X, X + maxn, 0), reverse(A, A + n + 1), reverse(B, B + m + 1);
	poly_inv(B, X, n - m), poly_conv(A, X, Q, n - m);
	reverse(A, A + n + 1), reverse(B, B + m + 1);
	fill(Q + n - m + 1, Q + maxn, 0), reverse(Q, Q + n - m + 1);
	poly_conv(B, Q, X, n), poly_sub(A, X, R, n), fill(R + m, R + maxn, 0);
}

void poly_int(int A[], int B[], int n) {
	B[0] = 0;
	for (int i = 1; i <= n + 1; i++) {
		B[i] = 1ll * A[i - 1] * qpow(i, mod - 2) % mod;
	}
}

void poly_deriv(int A[], int B[], int n) {
	for (int i = 1; i <= n; i++) {
		B[i - 1] = 1ll * A[i] * i % mod;
	}
	B[n] = 0;
}

int main() {
	settings();
	scanf("%d %d", &n, &m);
	for (int i = 0; i <= n; i++) {
		scanf("%d", &a[i]);
	}
	for (int i = 0; i <= m; i++) {
		scanf("%d", &b[i]);
	}
	poly_div(a, b, q, r, n, m);
	for (int i = 0; i <= n - m; i++) {
		printf("%d%c", q[i], " \n"[i == n - m]);
	}
	for (int i = 0; i < m; i++) {
		printf("%d%c", r[i], " \n"[i == m - 1]);
	}
	return 0;
}
```