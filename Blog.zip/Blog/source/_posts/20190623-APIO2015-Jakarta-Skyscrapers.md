---
title: 「APIO 2015」Jakarta Skyscrapers（BFS）
date: 2019-06-23 00:00:00
mathjax: true
tags:
	- BFS

---

# 题目大意
[「APIO 2015」Jakarta Skyscrapers（Luogu 3645）](https://www.luogu.org/problemnew/show/P3645)

有 $n$ 个位置，$m$ 只 doge，第 $i$ 只在位置 $b_i$ 上。一开始给 $1$ 号 doge 传达信息，第 $i$ 只 doge 在收到信息后，可以进行如下操作：

+ 自己向左后向右移动 $p_i$ 个位置，花费 $1$ 个单位时间。
+ 将携带的信息传达给在同一个位置上的 doge，花费 $0$ 个单位时间。

问信息传达给 $2$ 号 doge 所需要的最少时间。

数据范围：$n, m \le 3 \times 10^4$。

<!--more-->

# 思路分析
最容易想到的是一个暴力算法：我们每次让 doge 向左或向右跳，碰到一个 doge 就传达信息。考虑对于每一个位置建一个点，每新来一个 doge 就对于每一个它能够跳到的位置新建一个辅助点。然后：

+ 每个辅助点向对应位置的点连一条长度为 $0$ 的边。
+ 从 $b_i$ 向 $b_i$ 的辅助点连一条长度为 $0$ 的边。
+ 如果 doge 能够跳到位置 $x$，就从 $x$ 的辅助点向 $x - p_i$ 或 $x + p_i$ 的辅助点连长度为 $1$ 的边（取决于 $x$ 和 $b_i$ 的相对位置）。

不幸的是，我们发现这样的点数，边数都是 $O(nm)$ 的，无法通过此题。注意到我们的算法在 $p_i$ 较大的时候不会出现问题，而 $p_i$ 较小的时候的点数，边数较大。具体来讲，我们的点数是不超过 $n + \frac{nm}{P_0}$ 的，边数是不超过 $m + \frac{2mn}{P_0}$ 的，其中 $P_0$ 是所有 $p_i$ 的最小值。

那么，有没有在 $p_i$ 较小的时候可行的算法呢？发现 $p_i$ 较小的时候很多 doge 能跳到的位置集合都是完全相同的。也就是说，如果两个 doge $p_i$ 相同，$b_i \bmod p_i$ 同余，那么我们考虑将它们一起解决。对于每一个位置再建立 $P_1$ 个辅助点，其中 $P_1$ 是所有 $p_i$ 的最大值。我们记第 $i$ 个点的第 $j$ 个辅助点为 $\text{pnt}(i, j)$。建如下的图：

+ 每个 $\text{pnt}(i, j)$ 向 $i$ 点连一条长度为 $0$ 的边。
+ 每个 $\text{pnt}(i, j)$ 向 $\text{pnt}(i - j, j), \text{pnt}(i + j, j)$ 连长度为 $1$ 的边。
+ 对于每个 doge，从 $b_i$ 向 $\text{pnt}(b_i, p_i)$ 连长度为 $0$ 的边。

经过计算，这个图的点数不超过 $n + P_1 \times n$，边数不超过 $2 P_1 \times n + m$。单独来看它还是 $O(nm)$ 的，但是我们可以将其与前一种建图方法结合起来。设定阈值 $\text{Bound}$，如果 $p_i > \text{Bound}$ 就使用第一种建图方法，否则使用第二种建图方法。这样图的点数不超过 $n + \text{Bound} \times n + \frac{nm}{\text{Bound}}$，边数不超过 $2n \times \text{Bound} + \frac{2nm}{\text{Bound}} + m$。发现 $\text{Bound} = \sqrt{m}$ 时最优，建完图后跑最短路即可。当然由于这个图的边权只有 $0, 1$，所以可以直接 BFS。时间复杂度 $O(\sqrt{m}(n + m))$。

# 代码实现
```cpp
#include <cmath>
#include <cstdio>
#include <cstring>
using namespace std;

const int maxn = 3e4, maxb = 175, maxv = 1.05e7, maxe = 2.1e7, magic = 1 << 20;
int n, m, cnt, bnd, s, t, l, r, Q[magic + 3], pnt[maxb + 3][maxn + 3], tot, msk[maxe + 3], nxt[maxe + 3], lnk[maxv + 3], dist[maxv + 3];
bool vis[maxb + 3][maxb + 3];

void add(int u, int v, int w) {
	msk[++tot] = v * 2 + w;
	nxt[tot] = lnk[u], lnk[u] = tot;
}

int main() {
	scanf("%d %d", &n, &m);
	cnt = n, bnd = sqrt(m) + .5;
	for (int i = 1, b, p; i <= m; i++) {
		scanf("%d %d", &b, &p);
		b++;
		if (i == 1) s = b;
		if (i == 2) t = b;
		if (p > bnd) {
			int x = ++cnt, u = x, v;
			add(b, x, 0);
			for (int i = b - p; i >= 1; i -= p) {
				v = ++cnt;
				add(u, v, 1);
				add(v, i, 0);
				u = v;
			}
			u = x;
			for (int i = b + p; i <= n; i += p) {
				v = ++cnt;
				add(u, v, 1);
				add(v, i, 0);
				u = v;
			}
		} else {
			if (!vis[p][b % p]) {
				vis[p][b % p] = 1;
				int x = (b - 1) % p + 1;
				for (int i = x; i <= n; i += p) {
					add(pnt[p][i] = ++cnt, i, 0);
					if (i > x) {
						add(pnt[p][i], pnt[p][i - p], 1);
						add(pnt[p][i - p], pnt[p][i], 1);
					}
				}
			}
			add(b, pnt[p][b], 0);
		}
	}
	memset(dist, -1, sizeof(dist));
	Q[r++] = s;
	dist[s] = 0;
	while (l != r) {
		int u = Q[l++];
		if (l == magic) l = 0;
		if (u == t) break;
		for (int i = lnk[u], v, w; i; i = nxt[i]) {
			v = msk[i] >> 1, w = msk[i] & 1;
			if (~dist[v]) continue;
			dist[v] = dist[u] + w;
			if (w) {
				Q[r++] = v;
				if (r == magic) r = 0;
			} else {
				if (--l < 0) l = magic - 1;
				Q[l] = v;
			}
		}
	}
	printf("%d\n", dist[t]);
	return 0;
}
```