---
title: 「BZOJ 4773」负环（倍增 + 最短路）
date: 2019-06-27 00:00:00
mathjax: true
tags:
	- 倍增
	- 最短路

---

# 题目大意
[「BZOJ 4773」负环](https://www.lydsy.com/JudgeOnline/problem.php?id=4773)

给定一个 $n$ 个点 $m$ 条边的带权有向图，问图中最短的负环的长度。

数据范围：$n \le 300$。

<!--more-->

# 思路分析
令 $\text{dp}(k, i, j)$ 表示从 $i$ 走 $k$ 步到 $j$，经过的边权和的最小值。我们暴力地对它进行转移，$k$ 每次加一时我们都要使用一次类似矩阵乘法的操作（将乘号换成加号，将求和换成取 $\max$）。我们一直进行转移，直到存在 $\text{dp}(k, i, i) < 0$ 时我们就找到了一个长度为 $k$ 的负环。时间复杂度 $O(n^4)$，不足以通过本题。

但是我们发现矩阵乘法是可以通过倍增的方法优化的。我们令 $\text{dp}(k, i, j)$ 表示从 $i$ 走 $2^k$ 步到 $j$，经过的边权和的最小值。这样我们就可以倍增地在 $O(n^3 \log n)$ 的时间内算出所有这样的矩阵。

在计算答案的时候，我们使用类似倍增找 LCA 的方法，按 $k$ 由大到小的顺序贪心地尝试乘上当前答案矩阵，再看结果矩阵是否有 $\text{dp}(i, i) < 0$。如果没有，则这次尝试是成功的。最后输出一共乘上矩阵的次数 $+1$ 即可。时间复杂度 $O(n^3 \log n)$。

# 代码实现
```cpp
#include <cstdio>
#include <algorithm>
using namespace std;

const int maxn = 300, logn = 8, inf = 1e9 + 1;
int n, m, f[logn + 3][maxn + 3][maxn + 3], g[maxn + 3][maxn + 3], t[maxn + 3][maxn + 3];

int main() {
	scanf("%d %d", &n, &m);
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) {
			f[0][i][j] = g[i][j] = (i == j ? 0 : inf);
		}
	}
	for (int i = 1, u, v, w; i <= m; i++) {
		scanf("%d %d %d", &u, &v, &w);
		if (w < f[0][u][v]) {
			f[0][u][v] = w;
		}
	}
	for (int d = 1; d <= logn; d++) {
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				f[d][i][j] = inf;
				for (int k = 1; k <= n; k++) {
					f[d][i][j] = min(f[d][i][j], f[d - 1][i][k] + f[d - 1][k][j]); 
				}
			}
		}
	}
	int ans = 0;
	bool ok = false;
	for (int d = logn; ~d; d--) {
		bool flag = false;
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= n; j++) {
				t[i][j] = inf;
				for (int k = 1; k <= n; k++) {
					t[i][j] = min(t[i][j], g[i][k] + f[d][k][j]);
				}
				if (i == j && t[i][j] < 0) {
					flag = true;
					break;
				}
			}
			if (flag) {
				break;
			}
		}
		if (!flag) {
			ans += 1 << d;
			for (int i = 1; i <= n; i++) {
				for (int j = 1; j <= n; j++) {
					g[i][j] = t[i][j];
				}
			}
		} else {
			ok = true;
		}
	}
	printf("%d\n", ok ? ans + 1 : 0);
	return 0;
}
```