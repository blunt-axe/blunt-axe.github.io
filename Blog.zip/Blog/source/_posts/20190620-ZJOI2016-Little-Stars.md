---
title: 「ZJOI 2016」小星星（容斥原理 + 动态规划）
date: 2019-06-20 00:00:00
mathjax: true
tags:
	- 容斥原理
	- 动态规划

---

# 题目大意
[「ZJOI 2016」小星星（Luogu 3349）](https://www.luogu.org/problemnew/show/P3349)

给定一个 $n$ 个结点 $m$ 条边的无向图和一棵 $n$ 个结点的树。现在要把树中的每个结点不重复，不遗漏地对应到图中的每个结点上，满足对应后形成的树是图的一棵生成树。求合法方案的数量。

数据范围：$n \le 17$。

<!--more-->

# 思路分析
先考虑如果没有不重复，不遗漏这个条件怎么做。相当于给树上的每个结点都染个颜色，满足相邻的两个结点的颜色之间对应有边。记 $\text{dp}(i, j)$ 表示结点 $i$ 染成颜色 $j$ 的方案数，我们只要暴力枚举儿子的颜色即可转移。时间复杂度 $O(n ^ 3)$。

但是现在有 “所有颜色都要用到” 这个条件。考虑最一般的容斥原理。对于上述的 DP，我们记对于颜色集合 $A$ 算出的答案为 $f(A)$。我们只要每次枚举一个颜色的子集 $S$ 不能使用，然后把 $(-1)^{\vert A \vert} \times f(S - A)$ 贡献到答案里就行了，其中 $S$ 是颜色的全集。时间复杂度 $O(2 ^ n \times n ^ 3)$。

# 代码实现
```cpp
#include <cstdio>
#include <cstring>
#include <vector>
using namespace std;

typedef long long ll;
const int maxn = 18;
int n, m, cur_msk;
ll dp[maxn + 3][maxn + 3];
bool a[maxn + 3][maxn + 3];
vector<int> G[maxn + 3];

void add(int u, int v) {
	G[u].push_back(v);
}

int bit_cnt(int x) {
	return __builtin_popcount(x);
}

void dfs(int u, int pa = 0) {
	for (int i = 1; i <= n; i++) {
		dp[u][i] = ~cur_msk >> (n - i) & 1;
	}
	for (int i = 0, v; i < G[u].size(); i++) {
		v = G[u][i];
		if (v == pa) continue;
		dfs(v, u);
		for (int i = 1; i <= n; i++) if (dp[u][i]) {
			ll sum = 0;
			for (int j = 1; j <= n; j++) {
				if (a[i][j]) sum += dp[v][j];
			}
			dp[u][i] *= sum;
		}
	}
}

int main() {
	scanf("%d %d", &n, &m);
	for (int i = 1, u, v; i <= m; i++) {
		scanf("%d %d", &u, &v);
		a[u][v] = a[v][u] = true;
	}
	for (int i = 1, u, v; i < n; i++) {
		scanf("%d %d", &u, &v);
		add(u, v), add(v, u);
	}
	ll ans = 0, res;
	for (int msk = 0; msk < (1 << n) - 1; msk++) {
		cur_msk = msk;
		dfs(1);
		res = 0;
		for (int i = 1; i <= n; i++) {
			res += dp[1][i];
		}
		if (~bit_cnt(msk) & 1) {
			ans += res;
		} else {
			ans -= res;
		}
	}
	printf("%lld\n", ans);
	return 0;
}
```