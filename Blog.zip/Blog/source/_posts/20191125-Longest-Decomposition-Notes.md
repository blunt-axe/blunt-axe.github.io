---
title: 「学习笔记」长链剖分
date: 2019-11-25 00:00:00
mathjax: true
tags:
	- 学习笔记
	- 长链剖分
	- 线段树
---

# 简介

长链剖分是一种树链剖分，与重链剖分不同的是，每个点的关键儿子是它向下高度最大的儿子。

长链剖分有许多优美的性质。例如，某个点的 $k$ 级祖先所在链的边数一定不小于 $k$；任意两点之间只会跨过 $\sqrt n$ 条链。另外，长链剖分还可以在线性的时间内解决状态规模为子树高度的许多 dp。

<!--more-->

# k 级祖先

[「Vijos 巴蜀中学」lxhgww 的奇思妙想](https://vijos.org/d/Bashu_OIers/p/5a79a3e1d3d8a103be7e2b81)

## 题目描述

给定一棵 $n$ 个点的树，$q$ 次询问点 $x$ 的 $k$ 级祖先。

强制在线，复杂度要求 $O(n \log n) - O(1)$。

## 思路分析

考虑利用简介中提到的一个性质：“某个点的 $k$ 级祖先所在链的长度一定不小于 $k$”。我们先用倍增预处理出每个点向上跳 $2^t$ 步会到达哪个点。考虑 $k$ 在二进制下的最高位 $b$，记 $x$ 的 $2^b$ 级祖先为 $y$，然后我们只要求 $y$ 的 $k - 2^b$ 级祖先。首先有 $y$ 所在链的长度不小于 $2^b$，然后发现 $k - 2^b < 2^b$，所以 $y$ 所在链的长度一定超过 $k - 2^b$。我们只需要处理出每个链顶向上跳不超过链长步会到达哪些点，存进 `std::vector` 中即可 $O(1)$ 查询 $y$ 的 $k - 2^b$ 级祖先。时间复杂度 $O(n \log n) - O(1)$。

## 代码实现

这题 RE on #6, 7, 8 实在调不出来了，代码仅供参考。

```cpp
#include <bits/stdc++.h>
using namespace std;

const int maxn = 3e5, logn = 18;
int n, m, dep[maxn + 3], mx[maxn + 3], ch[maxn + 3], fa[maxn + 3][logn + 3];
int top[maxn + 3], bot[maxn + 3], len[maxn + 3], ans, lg[maxn + 3];
vector<int> G[maxn + 3], S[maxn + 3];

void dfs(int u, int pa = 0) {
	for (int i = 1; (fa[u][i] = fa[fa[u][i - 1]][i - 1]); i++);
	for (int i = 0, v; i < G[u].size(); i++) {
		v = G[u][i];
		if (v == pa) continue;
		fa[v][0] = u;
		dep[v] = dep[u] + 1;
		dfs(v, u);
		if (mx[v] + 1 > mx[u]) {
			mx[u] = mx[v] + 1, ch[u] = v;
		}
	}
}

void solve(int u, int pa = 0, int t = 1) {
	top[u] = t;
	for (int i = 0, v; i < G[u].size(); i++) {
		v = G[u][i];
		if (v == pa || v == ch[u]) continue;
		solve(v, u, v);
	}
	if (ch[u]) {
		len[top[u]]++;
		solve(ch[u], u, t);
	} else {
		bot[top[u]] = u;
	}
	S[top[u]].push_back(u);
	if (u == t) {
		for (int i = 1, x = u; i <= len[u]; i++) {
			S[u].push_back(x = fa[x][0]);
		}
	}
}

int query(int x, int k) {
	if (k == 0) {
		return x;
	} else if (k > dep[x]) {
		return 0;
	}
	int t = lg[k];
	x = fa[x][t], k -= 1 << t;
	return S[top[x]][dep[bot[top[x]]] - dep[x] + k];
}

int main() {
	scanf("%d", &n);
	for (int i = 2; i <= n; i++) {
		lg[i] = lg[i >> 1] + 1;
	}
	for (int i = 1, u, v; i < n; i++) {
		scanf("%d %d", &u, &v);
		G[u].push_back(v), G[v].push_back(u);
	}
	dfs(1);
	solve(1);
	scanf("%d", &m);
	for (int x, k; m --> 0; ) {
		scanf("%d %d", &x, &k);
		x ^= ans, k ^= ans;
		printf("%d\n", ans = query(x, k));
	}
	return 0;
}
```

# 贪心

[「BZOJ 3252」攻略](http://darkbzoj.tk/problem/3252)

## 题目描述

给定点带权的点数为 $n$ 的树，要选出 $k$ 条包含 $1$ 的祖先后代链，使得它们并的点权和最大。

$n \le 2 \times 10^5, 1 \le a_i < 2^{31}$。

## 思路分析

考虑带权的长链剖分，剖出的链取前 $k$ 条加起来即可。时间复杂度 $O(n \log n)$。

## 代码实现

```cpp
#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn = 2e5;
int n, k, a[maxn + 3], id[maxn + 3];
ll mx[maxn + 3];
vector<int> G[maxn + 3];

void dfs(int u, int pa = 0) {
	ll x = 0;
	for (int i = 0, v; i < G[u].size(); i++) {
		v = G[u][i];
		if (v == pa) continue;
		dfs(v, u);
		if (mx[id[v]] + a[u] > x) {
			x = mx[id[v]] + a[u], id[u] = id[v];
		}
	}
	if (id[u]) {
		mx[id[u]] += a[u];
	} else {
		mx[u] = a[u], id[u] = u;
	}
}

int main() {
	scanf("%d %d", &n, &k);
	for (int i = 1; i <= n; i++) {
		scanf("%d", &a[i]);
	}
	for (int i = 1, u, v; i < n; i++) {
		scanf("%d %d", &u, &v);
		G[u].push_back(v), G[v].push_back(u);
	}
	dfs(1);
	sort(mx + 1, mx + n + 1);
	reverse(mx + 1, mx + n + 1);
	ll ans = 0;
	for (int i = 1; i <= k; i++) {
		ans += mx[i];
	}
	printf("%lld\n", ans);
	return 0;
}
```

# 模版题

[「CF 1009F」Dominant Indices](https://codeforces.com/problemset/problem/1009/F)

## 题目描述

记 $f(u, i)$ 为 $u$ 往下走 $i$ 步到达的点数，给定 $n$ 个点的树，对于每个点求出序列 $[f(u, 0), f(u, 1), \cdots]$ 中的最大值的最小下标。

数据范围：$n \le 10^6$。

## 思路分析

考虑长链剖分求 $f$，对于一个点，先继承特殊儿子的答案，然后对于其他儿子暴力更新即可。时间复杂度 $O(n)$。

## 代码实现

用 `std::vector` 实现，代码更短哦！

```cpp
#include <bits/stdc++.h>
using namespace std;

const int maxn = 1e6;
int n, mx[maxn + 3], ch[maxn + 3], id[maxn + 3], ans[maxn + 3], res[maxn + 3];
vector<int> G[maxn + 3], f[maxn + 3];

void dfs(int u, int pa = 0) {
	for (int i = 0, v; i < G[u].size(); i++) {
		v = G[u][i];
		if (v == pa) continue;
		dfs(v, u);
		if (mx[v] + 1 > mx[u]) {
			mx[u] = mx[v] + 1, ch[u] = v;
		}
	}
	int x = id[u] = ch[u] ? id[ch[u]] : u;
	ans[u] = ch[u] ? ans[ch[u]] + 1 : 0, res[u] = ch[u] ? res[ch[u]] : 1;
	f[x].push_back(1);
	if (res[u] == 1) {
		ans[u] = 0;
	}
	for (int i = 0, v; i < G[u].size(); i++) {
		v = G[u][i];
		if (v == pa || v == ch[u]) continue;
		int y = id[v];
		for (int j = 0; j < f[y].size(); j++) {
			int p = f[x].size() - f[y].size() + j - 1;
			f[x][f[x].size() - f[y].size() + j - 1] += f[y][j];
			int id = f[x].size() - p - 1, val = f[x][p];
			if (val > res[u] || (val == res[u] && id < ans[u])) {
				ans[u] = id, res[u] = val;
			}
		}
	}
}

int main() {
	scanf("%d", &n);
	for (int i = 1, u, v; i < n; i++) {
		scanf("%d %d", &u, &v);
		G[u].push_back(v), G[v].push_back(u);
	}
	dfs(1);
	for (int i = 1; i <= n; i++) {
		printf("%d\n", ans[i]);
	}
	return 0;
}
```

# 重建计划

[「WC 2010」重建计划](http://darkbzoj.tk/problem/1758)

## 题目描述

给定边带权的 $n$ 个点的树，选出一条长度在 $[L, U]$ 内的链，使得边权的平均值最小。

数据范围：$n \le 10^5$。

## 思路分析

首先可以想到二分答案，问题变成链的最大权值和是否超过 $0$。考虑长链剖分，设 $f(u, i)$ 表示 $u$ 的子树内以 $u$ 为端点的权值最大的长度为 $i$ 的路径长度。我们考虑使用线段树维护 $f$，从特殊儿子继承时只需要区间加，从其他儿子先更新答案（线段树区间最大值），后更新 $f$（暴力）即可。时间复杂度 $O(n \log^2 n)$。

## 代码实现

注意这个题不能用 `std::vector`，而是要使用内存分配的技巧。对于每一条链，我们改变 dfs 的顺序，使得每条链的 dfs 序连续。这样开一个全局的线段树，一条链上的一段就可以对应线段树的一个区间了。推荐简单题使用 `std::vector`，难题使用内存分配的方法。（因为难题用 `std::vector` 会写自闭的，详见 HOT Hotels）

```cpp
#include <bits/stdc++.h>
using namespace std;

typedef double db;
const int maxn = 1e5, maxm = 1 << 18;
const db inf = 1e18;
int n, L, U, mxd[maxn + 3], ch[maxn + 3], top[maxn + 3], bot[maxn + 3];
int cnt, wei[maxn + 3], dfn[maxn + 3];
db val[maxn + 3], ans, mx[maxm + 3], tag[maxm + 3];
vector<int> G[maxn + 3], W[maxn + 3];

void add(int u, int v, int w) {
	G[u].push_back(v), W[u].push_back(w);
}

void dfs_1(int u, int pa = 0) {
	for (int i = 0, v, w; i < G[u].size(); i++) {
		v = G[u][i], w = W[u][i];
		if (v == pa) continue;
		wei[v] = w;
		dfs_1(v, u);
		if (mxd[v] + 1 > mxd[u]) {
			mxd[u] = mxd[v] + 1, ch[u] = v;
		}
	}
}

void dfs_2(int u, int pa = 0, int t = 1) {
	dfn[u] = ++cnt;
	top[u] = t;
	if (ch[u]) {
		dfs_2(ch[u], u, t);
		bot[u] = bot[ch[u]];
	} else {
		bot[u] = u;
	}
	for (int i = 0, v; i < G[u].size(); i++) {
		v = G[u][i];
		if (v == pa || v == ch[u]) continue;
		dfs_2(v, u, v);
	}
}

void upd(db &x, db y) {
	x < y ? x = y : 0;
}

#define ls (x << 1)
#define rs (ls | 1)
#define mid ((l + r) >> 1)

void build(int x, int l, int r) {
	mx[x] = 0, tag[x] = 0;
	if (l == r) {
		return;
	}
	build(ls, l, mid);
	build(rs, mid + 1, r);
}

void push_down(int x) {
	mx[ls] += tag[x], tag[ls] += tag[x];
	mx[rs] += tag[x], tag[rs] += tag[x];
	tag[x] = 0;
}

void maintain(int x) {
	mx[x] = max(mx[ls], mx[rs]);
}

void chk_max(int x, int l, int r, int y, db z) {
	if (l == r) {
		mx[x] = max(mx[x], z);
		return;
	}
	push_down(x);
	if (y <= mid) {
		chk_max(ls, l, mid, y, z);
	} else {
		chk_max(rs, mid + 1, r, y, z);
	}
	maintain(x);
}

void modify(int x, int l, int r, int lx, int rx, db y) {
	if (l >= lx && r <= rx) {
		mx[x] += y, tag[x] += y;
		return;
	}
	push_down(x);
	if (lx <= mid) {
		modify(ls, l, mid, lx, rx, y);
	}
	if (rx > mid) {
		modify(rs, mid + 1, r, lx, rx, y);
	}
	maintain(x);
}

db query(int x, int l, int r, int lx, int rx) {
	if (l >= lx && r <= rx) {
		return mx[x];
	}
	push_down(x);
	db ret = -inf;
	if (lx <= mid) {
		upd(ret, query(ls, l, mid, lx, rx));
	}
	if (rx > mid) {
		upd(ret, query(rs, mid + 1, r, lx, rx));
	}
	return ret;
}

db get(int x) {
	return query(1, 1, n, x, x);
}

#undef ls
#undef rs
#undef mid

void solve(int u, int pa = 0) {
	int x = dfn[u];
	if (ch[u]) {
		solve(ch[u], u);
		modify(1, 1, n, x + 1, dfn[bot[u]], val[ch[u]]);
		int lft = x + L, rht = min(dfn[bot[u]], x + U);
		if (lft <= rht) {
			upd(ans, query(1, 1, n, lft, rht));
		}
	}
	for (int i = 0, v; i < G[u].size(); i++) {
		v = G[u][i];
		if (v == pa || v == ch[u]) continue;
		solve(v, u);
		int y = dfn[v];
		for (int j = 0; j <= dfn[bot[v]] - y; j++) {
			int lft = max(x + L - 1 - j, x), rht = min(x + U - 1 - j, dfn[bot[u]]);
			if (lft <= rht) {
				upd(ans, query(1, 1, n, lft, rht) + get(y + j) + val[v]);
			}
		}
		for (int j = 0; j <= dfn[bot[v]] - y; j++) {
			chk_max(1, 1, n, dfn[u] + j + 1, get(y + j) + val[v]);
		}
	}
}

bool check(db x) {
	build(1, 1, n);
	for (int i = 2; i <= n; i++) {
		val[i] = wei[i] - x;
	}
	ans = -inf;
	solve(1);
	return ans >= 0;
}

int main() {
	scanf("%d %d %d", &n, &L, &U);
	for (int i = 1, u, v, w; i < n; i++) {
		scanf("%d %d %d", &u, &v, &w);
		add(u, v, w), add(v, u, w);
	}
	dfs_1(1);
	dfs_2(1);
	db l = 0, r = 1e6, mid;
	while (l + 1e-4 < r) {
		mid = (l + r) / 2;
		if (check(mid)) {
			l = mid;
		} else {
			r = mid;
		}
	}
	printf("%.3lf\n", l);
	return 0;
}
```

# HOT Hotels

[「POJ 2014」HOT Hotels](http://darkbzoj.tk/problem/4543)

##  题目描述

给定 $n$ 个点的树，求有多少点的三元组满足它们两两之间距离相等。

数据范围：$n \le 10^5$。

## 思路分析

发现三元组肯定有一个中心到三个点距离相等。记 $f(u, i)$ 表示 $u$ 子树内和它距离为 $i$ 的点数，$g(u, i)$ 表示 $u$ 子树内有多少点对满足它们到 LCA 的距离都为 $t$ 且 LCA 到 $u$ 的距离为 $t - i$（也就是说在上面加上长度为 $i$ 的链后可以形成方案）。那么转移方程如下：

```cpp
for(int i = 0;i <= n;i ++) ans += g[x][i] * (i == 0 ? 0 : f[to][i-1]) + g[to][i+1] * f[x][i];
for(int i = 0;i <= n;i ++) g[x][i] += f[x][i] * (i == 0 ? 0 : f[to][i-1]) + g[to][i+1];
for(int i = 1;i <= n;i ++) f[x][i] += f[to][i-1];
```

（转自 [Treaker 的博客](https://www.luogu.com.cn/blog/Treaker/solution-p3565)）

注意 $f(u, 0)$ 的初值为 $1$，dfs 完 $u$ 时还要让 $\text{ans} \leftarrow \text{ans} + g(u, 0)$。

那么使用长链剖分优化即可。时间复杂度 $O(n)$。

## 代码实现

用 `std::vector` 写的，由于 $g$ 数组转移的特殊，下标的变化很玄学，细节比较多。使用分配内存的方法就可以减少细节量。

```cpp
// f[x][i] = p[x][f[x].size() - i - 1]
// g[x][i] = q[x][i - mx(x) + 1]
// p[x][i] = f[x][f[x].size() - i - 1]
// q[x][i] = g[x][i + mx(x) - 1]

#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn = 1e5;
int n, tot, ch[maxn + 3], mx[maxn + 3], id[maxn + 3];
ll ans;
vector<int> G[maxn + 3];
vector<ll> f[maxn + 3], g[maxn + 3];

void dfs(int u, int pa = 0) {
	for (int i = 0, v; i < G[u].size(); i++) {
		v = G[u][i];
		if (v == pa) continue;
		dfs(v, u);
		if (mx[v] + 1 > mx[u]) {
			mx[u] = mx[v] + 1, ch[u] = v;
		}
	}
	int x = id[u] = ch[u] ? id[ch[u]] : ++tot;
	f[x].push_back(1);
	if (ch[u]) {
		for (int t = 0; t < 2; t++) {
			g[x].push_back(0);
		}
	}
	for (int i = 0, v; i < G[u].size(); i++) {
		v = G[u][i];
		if (v == pa || v == ch[u]) continue;
		int y = id[v];
		for (int j = 1; j < f[x].size(); j++) if (j + mx[v] < g[y].size()) {
			ans += f[x][f[x].size() - j - 1] * g[y][j + mx[v]];
		}
		for (int j = 0; j < f[y].size(); j++) {
			ans += g[x][j + mx[u]] * f[y][f[y].size() - j - 1];
		}
		if (ch[v]) for (int j = 0; j <= mx[v]; j++) {
			g[x][j - 1 + mx[u] - 1] += g[y][j + mx[v] - 1];
		}
		for (int j = 0; j < f[y].size(); j++) {
			g[x][j + mx[u]] += f[x][f[x].size() - (j + 1) - 1] * f[y][f[y].size() - j - 1];
		}
		for (int j = 0; j < f[y].size(); j++) {
			f[x][j + f[x].size() - f[y].size() - 1] += f[y][j];
		}
	}
	if (ch[u]) {
		ans += g[x][mx[u] - 1];
		if (mx[u] - 2 >= 0) {
			g[x][mx[u] - 2] = 0;
		} 
	}
}

int main() {
	scanf("%d", &n);
	for (int i = 1, u, v; i < n; i++) {
		scanf("%d %d", &u, &v);
		G[u].push_back(v), G[v].push_back(u);
	}
	dfs(1);
	printf("%lld\n", ans);
	return 0;
}
```

