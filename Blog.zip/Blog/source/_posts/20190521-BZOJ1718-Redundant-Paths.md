---
title: 「BZOJ 1718」Redundant Paths（Tarjan）
mathjax: true
date: 2019-05-21 00:00:00
tags:
    - Tarjan
---

# 题目大意
[「BZOJ 1718」Redundant Paths](https://www.lydsy.com/JudgeOnline/problem.php?id=1718)

给定一个 $n$ 个点 $m$ 条边的无向图，问至少再加几条边就能使得整个图形成一个边双联通分量。

边双联通分量的定义：一个图中的任意两个结点之间都有两条路径，满足它们的边没有交。

数据范围：$n, m \le 10^6$。

<!--more-->

# 思路分析
不难发现答案为：根据边双联通分量缩点后得到的森林中的每一个联通块的叶子结点的个数的一半向上取整之和。

时间复杂度 $O(n + m)$。

# 代码实现

```cpp
#include <cstdio>
#include <algorithm>
using namespace std;

const int maxn = 1e6, maxm = maxn * 2;
int n, m, u[maxm + 3], v[maxm + 3];
int tm, dfn[maxn + 3], low[maxn + 3], top, st[maxn + 3];
int cnt, bel[maxn + 3], deg[maxn + 3], cur;
int tot, ter[maxm + 3], nxt[maxm + 3], lnk[maxn + 3];
bool vis[maxn + 3];

void add(int u, int v) {
    ter[++tot] = v, nxt[tot] = lnk[u], lnk[u] = tot;
}

int adj(int x) {
    return x & 1 ? x + 1 : x - 1;
}

void tarjan(int u, int e = 0) {
    dfn[u] = low[u] = ++tm;
    st[++top] = u;
    for (int i = lnk[u], v; i; i = nxt[i]) {
        v = ter[i];
        if (!dfn[v]) {
            tarjan(v, i);
            low[u] = min(low[u], low[v]);
        } else if (i != adj(e)) {
            low[u] = min(low[u], dfn[v]);
        }
    }
    if (dfn[u] == low[u]) {
        cnt++;
        do {
            bel[st[top]] = cnt;
        } while (st[top--] != u);
    }
}

void dfs(int u, int pa = 0) {
    if (pa) {
        cur -= (deg[u] == 1) + (deg[pa] == 1);
        deg[u]++, deg[pa]++;
        cur += (deg[u] == 1) + (deg[pa] == 1);
    }
    vis[u] = true;
    for (int i = lnk[u], v; i; i = nxt[i]) {
        v = ter[i];
        if (!vis[v]) {
            dfs(v, u);
        }
    }
}

int main() {
    scanf("%d %d", &n, &m);
    for (int i = 1; i <= m; i++) {
        scanf("%d %d", &u[i], &v[i]);
        add(u[i], v[i]), add(v[i], u[i]);
    }
    for (int i = 1; i <= n; i++) {
        if (!dfn[i]) tarjan(i);
    }
    tot = 0;
    for (int i = 1; i <= n; i++) {
        lnk[i] = 0;
    }
    for (int i = 1; i <= m; i++) if (bel[u[i]] != bel[v[i]]) {
        add(bel[u[i]], bel[v[i]]), add(bel[v[i]], bel[u[i]]);
    }
    int ans = 0;
    for (int i = 1; i <= cnt; i++) if (!vis[i]) {
        cur = 0, dfs(i);
        ans += (cur + 1) / 2;
    }
    printf("%d\n", ans);
    return 0;
}
```