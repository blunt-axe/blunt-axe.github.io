---
title: 「HNOI 2012」矿场搭建（Tarjan）
date: 2019-06-29 00:00:02
mathjax: true
tags:
	- Tarjan

---

# 题目大意
[「HNOI 2012」矿场搭建（Luogu 3225）](https://www.luogu.org/problemnew/show/P3225)

给定一个 $n$ 个点 $m$ 条边的无向连通图，你要选择若干个关键点，使得在图中任意删除一个点后（可以删除任何点），图中剩余的点都可以到达某一个关键点。

数据范围：$n, m \le 10^6$。

<!--more-->

# 思路分析
根据割点的定义，发现只有删掉割点才会使某两个结点不联通。所以在一个点双连通分量内部，我们只需要任意选一个点即可。但是并不是所有的点双连通分量都需要选。我们考虑根据割点建一棵树，一个点双连通分量向与之相邻的割点连一条边。这样我们得到了一个割点和点双连通分量相间的树。发现只需要度数为 $1$ 的点双连通分量选上即可，因为树上删掉任意一个点，剩下的所有结点肯定可以跑到某个度数为 $1$ 的点；如果有一个度数为 $1$ 的点没选，那么我们只需删掉与它相邻的那个点即可让这个点无法走到一个关键点。于是我们使用 Tarjan 跑割点，然后将建好的树上度数为 $1$ 的点的 $\text{size}$ 相乘即可。时间复杂度 $O(n + m)$。

你交了上去，发现 WA 了。原因是有一个特殊情况：没有割点。这样你必须选两个点才可行，因为如果只选一个点而那个点被删除了，就不剩下任何关键点了。这样的方案数是 $\binom{n}{2}$。特判一下就可以通过此题了。

实现的时候我们其实不需要把树给建出来，我们只需要对于每一个结点 DFS 出去，找与它所在的联通块相邻的割点个数即可。

# 代码实现
```cpp
#include <cstdio>
#include <vector>
using namespace std;

typedef long long ll;
const int maxn = 1e6;
int T, n, m, tm, dfn[maxn + 3], low[maxn + 3], cc, sz, vis[maxn + 3];
bool cut[maxn + 3];
vector<int> G[maxn + 3];

void add(int u, int v) {
	G[u].push_back(v);
}

void tarjan(int u, bool is_rt = true) {
	dfn[u] = low[u] = ++tm;
	int son = 0;
	for (int i = 0, v; i < G[u].size(); i++) {
		v = G[u][i];
		if (!dfn[v]) {
			tarjan(v, false);
			low[u] = min(low[u], low[v]);
			if (!is_rt && low[v] == dfn[u]) {
				cut[u] = true;
			}
			son++;
		} else {
			low[u] = min(low[u], dfn[v]);
		}
	}
	if (is_rt && son >= 2) {
		cut[u] = true;
	}
}

void dfs(int u) {
	vis[u] = tm;
	sz++;
	for (int i = 0, v; i < G[u].size(); i++) {
		v = G[u][i];
		if (vis[v] != tm) {
			if (cut[v]) {
				cc++;
				vis[v] = tm;
			} else {
				dfs(v);
			}
		}
	}
}

int main() {
	while (scanf("%d", &m), m) {
		for (int i = 1; i <= n; i++) {
			G[i].clear(), vis[i] = 0;
			dfn[i] = 0, cut[i] = false;
		}
		n = 0;
		for (int i = 1, u, v; i <= m; i++) {
			scanf("%d %d", &u, &v);
			n = max(n, u), n = max(n, v);
			add(u, v), add(v, u);
		}
		tm = 0;
		tarjan(1);
		tm = 0;
		int res = 0;
		ll ans = 1;
		for (int i = 1; i <= n; i++) {
			if (!cut[i] && !vis[i]) {
				cc = 0, sz = 0, ++tm;
				dfs(i);
				if (cc == 1) {
					res++, ans *= sz;
				}
			}
		}
		printf("Case %d: ", ++T);
		if (res == 0) {
			printf("2 %lld\n", 1ll * n * (n - 1) / 2);
		} else {
			printf("%d %lld\n", res, ans);
		}
	}
	return 0;
}
```