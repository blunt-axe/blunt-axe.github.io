---
title: 「SDOI 2018」战略游戏（圆方树 + 虚树）
date: 2019-05-22 00:00:00
mathjax: true
tags:
	- 圆方树
	- 虚树
---

# 题目大意
[「SDOI 2018」战略游戏（Luogu 4606）](https://www.luogu.org/problemnew/show/P4606)

给定 $n$ 个点 $m$ 条边的无向图，$q$ 次询问，每次询问点集 $S$，求图中有多少个点满足删掉它之后 $S$ 中至少两个点不联通。

$n, q \le 10^5, m, \sum \vert S \vert \le 2 \times 10^5$。

<!--more-->

# 思路分析
> 圆方树上建虚树，欢乐多又多

其实这是广义圆方树和虚树的学习笔记。

不难发现答案为 $S$ 在广义圆方树上形成的虚树中的圆点个数减去 $\vert S \vert$。建出广义圆方树和虚树即可。

时间复杂度 $O(n \log n)$。

# 代码实现
```cpp
#include <cstdio>
#include <vector>
#include <algorithm>
using namespace std;

const int maxn = 1e5, maxm = 2 * maxn, maxk = 2 * maxm, logk = 18;
int T, n, m, q, tm, cnt, dfn[maxn + 3], low[maxn + 3], top, st[maxm + 3];
int tot, ter[maxk + 3], nxt[maxk + 3], lnk[maxn + 3];
int tm_t, dfn_t[maxm + 3], dep[maxm + 3], fa[maxm + 3], sz[maxm + 3];
int pnt[maxk + 3][logk + 3], lg[maxk + 3], id[maxm + 3], ans;
bool vis[maxn + 3];
vector<int> G[maxm + 3];

void add(int u, int v) {
	ter[++tot] = v, nxt[tot] = lnk[u], lnk[u] = tot;
}

void add_vec(int u, int v) {
	G[u].push_back(v), G[v].push_back(u);
}

void tarjan(int u) {
	dfn[u] = low[u] = ++tm;
	vis[u] = true, st[++top] = u;
	for (int i = lnk[u], v; i; i = nxt[i]) {
		v = ter[i];
		if (!dfn[v]) {
			tarjan(v);
			low[u] = min(low[u], low[v]);
			if (low[v] >= dfn[u]) {
				add_vec(++cnt, u);
				do {
					add_vec(cnt, st[top]);
				} while (st[top--] != v);
			}
		} else {
			low[u] = min(low[u], dfn[v]);
		}
	}
	vis[u] = false;
}

void dfs_t(int u, int pa = 0) {
	dfn_t[u] = ++tm_t;
	pnt[tm_t][0] = u;
	sz[u] = sz[pa] + (u <= n);
	for (int i = 0, v; i < G[u].size(); i++) {
		v = G[u][i];
		if (v == pa) continue;
		dep[v] = dep[u] + 1;
		fa[v] = u;
		dfs_t(v, u);
		pnt[++tm_t][0] = u;
	}
}

int lca(int a, int b) {
	a = dfn_t[a], b = dfn_t[b];
	if (a > b) swap(a, b);
	int c = lg[b - a + 1];
	a = pnt[a][c], b = pnt[b - (1 << c) + 1][c];
	if (dep[a] <= dep[b]) return a;
	else return b;
}

bool comp(int i, int j) {
	return dfn_t[i] < dfn_t[j];
}

void insert(int x) {
	if (x == st[1]) return;
	int y = lca(x, st[top]);
	if (y != st[top]) {
		while (top > 1 && dfn_t[y] < dfn_t[st[top - 1]]) {
			ans += sz[st[top]] - sz[st[top - 1]], top--;
		}
		if (dfn_t[y] > dfn_t[st[top - 1]]) {
			ans += sz[st[top]] - sz[y];
			st[top] = y;
		} else {
			ans += sz[st[top--]] - sz[y];
		}
	}
	st[++top] = x;
}

int main() {
	scanf("%d", &T);
	while (T--) {
		scanf("%d %d", &n, &m);
		tot = 0, fill(lnk + 1, lnk + n + 1, 0);
		for (int i = 1, u, v; i <= m; i++) {
			scanf("%d %d", &u, &v);
			add(u, v), add(v, u);
		}
		tm = tm_t = 0;
		fill(dfn + 1, dfn + n + 1, 0);
		cnt = n, top = 0;
		for (int i = 1; i <= 2 * n; i++) {
			G[i].clear();
		}
		for (int i = 1; i <= n; i++) if (!dfn[i]) {
			tarjan(i);
		}
		dfs_t(1);
		for (int i = 2; i <= tm_t; i++) {
			lg[i] = lg[i / 2] + 1;
		}
		for (int k = 1; 1 << k <= tm_t; k++) {
			for (int i = 1, j = (1 << (k - 1)) + 1; i <= tm_t - (1 << k) + 1; i++, j++) {
				if (dep[pnt[i][k - 1]] <= dep[pnt[j][k - 1]]) pnt[i][k] = pnt[i][k - 1];
				else pnt[i][k] = pnt[j][k - 1];
			}
		}
		scanf("%d", &q);
		while (q--) {
			scanf("%d", &m);
			for (int i = 1; i <= m; i++) {
				scanf("%d", &id[i]);
			}
			int x = lca(id[1], id[2]);
			for (int i = 3; i <= m; i++) {
				x = lca(x, id[i]);
			}
			sort(id + 1, id + m + 1, comp);
			top = 0, ans = (x <= n) - m;
			st[++top] = x;
			for (int i = 1; i <= m; i++) {
				insert(id[i]);
			}
			for (int i = 1; i < top; i++) {
				ans += sz[st[i + 1]] - sz[st[i]];
			}
			printf("%d\n", ans);
		}
	}
	return 0;
}
```