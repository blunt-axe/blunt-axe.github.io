---
title: 「十二省联考 2019」字符串问题（后缀数组 + 线段树）
date: 2019-06-24 00:00:03
mathjax: true
tags:
	- 后缀数组
	- 线段树

---

# 题目大意
[「十二省联考 2019」字符串问题（Luogu 5284）](https://www.luogu.org/problemnew/show/P5284)

题太长了，自己读吧 QAQ。

令 $n = \vert S \vert$，则：

+ 对于 $40 \%$ 的数据，$n_a \times n_b \le 2 \times 10^5$。
+ 对于 $80 \%$ 的数据，$\vert A_i \vert \ge \vert B_i \vert$。
+ 对于 $100 \%$ 的数据，$n, n_a, n_b, m \le 2 \times 10^5$。

<!--more-->

# 思路分析
## 算法一
直接借助 Hash 暴力建图，做拓扑排序后 DP 求最长链即可。

时间复杂度 $O(n + n_a \times n_b + m)$，期望得分 $40$ 分。

## 算法二
可以发现复杂度的瓶颈在于 “如果 $B_j$ 是 $A_i$ 的前缀，则从 $B_j$ 向 $A_i$ 连一条边” 这一部分。如果有 $\vert A_i \vert \ge \vert B_i \vert$，那么连边的条件等价于：

$$\text{lcp}(\text{Suf}(L_{a_i}), \text{Suf}(L_{b_j})) \ge \vert B_j \vert$$

对于串后缀排序，则 $B_j$ 对应的 $A$ 就会形成一段区间。这段区间可以通过在 $\text{height}$ 数组上倍增来找到。找到区间以后，我们使用线段树优化建图即可。

我们将 $n, n_a, n_b, m$ 看作同阶，时间复杂度 $O(n \log n)$，期望得分 $80$ 分。

## 算法三
如果不保证 $\vert A_i \vert \ge \vert B_i \vert$，那么连边的条件就多了一个，也就是增加了一维的限制。我们使用主席树来代替线段树优化建边即可。

我们将 $n, n_a, n_b, m$ 看作同阶，时间复杂度 $O(n \log n)$，期望得分 $100$ 分。

# 代码实现
```cpp
#include <cstdio>
#include <cstring>
#include <queue>
#include <vector>
#include <algorithm>
using namespace std;

#define mid ((l + r) / 2)
typedef long long ll;

struct event {
	int type, id, x, y;
	event(int type = 0, int id = 0, int x = 0, int y = 0): type(type), id(id), x(x), y(y) {}
	friend bool operator< (const event &a, const event &b) {
		return a.x == b.x ? a.type < b.type : a.x > b.x;
	}
};

const int maxn = 2e5, maxm = 2 * maxn, maxv = 5e6, logn = 17;
int T, len, sa[maxn + 3], rnk[maxn + 3], _cnt[maxn + 3], a[maxn + 3], b[maxn + 3], hei[logn + 3][maxn + 3];
int n, m, k, lg, l1[maxn + 3], ln1[maxn + 3], l2[maxn + 3], ln2[maxn + 3], deg[maxv + 3], tot, cnt, rt, ch[maxv + 3][2];
char s[maxn + 3];
event e[maxm + 3];
queue<int> Q;
vector<int> G[maxv + 3];
ll dp[maxv + 3];

void radix_sort(int a[], int b[], int k[], int n) {
	fill(_cnt + 1, _cnt + n + 1, 0);
	for (int i = 1; i <= n; i++) _cnt[k[i]]++;
	for (int i = 2; i <= n; i++) _cnt[i] += _cnt[i - 1];
	for (int i = n; i; i--) b[_cnt[k[a[i]]]--] = a[i];
}

void suffix_sort(int n) {
	for (int i = 1; i <= n; i++) _cnt[s[i] - 'a' + 1] = 1;
	for (int i = 2; i <= 26; i++) _cnt[i] += _cnt[i - 1];
	for (int i = 1; i <= n; i++) rnk[i] = _cnt[s[i] - 'a' + 1];
	if (_cnt[26] == n) { for (int i = 1; i <= n; i++) sa[rnk[i]] = i; return; }
	for (int k = 1; k < n; k *= 2) {
		for (int i = 1; i <= n; i++) {
			a[i] = rnk[i], b[i] = (i + k <= n ? rnk[i + k] : 0) + 1;
		}
		for (int i = 1; i <= n; i++) sa[i] = i;
		radix_sort(sa, rnk, b, n), radix_sort(rnk, sa, a, n);
		rnk[sa[1]] = 1;
		for (int i = 2; i <= n; i++) {
			rnk[sa[i]] = rnk[sa[i - 1]] + (a[sa[i]] != a[sa[i - 1]] || b[sa[i]] != b[sa[i - 1]]);
		}
		if (rnk[sa[n]] == n) return;
	}
}

void get_height(int n) {
	for (int i = 1, j, t = 0; i <= n; hei[0][rnk[i++] - 1] = t) {
		for (t = max(0, t - 1), j = sa[rnk[i] - 1]; s[i + t] == s[j + t]; t++);
	}
}

void add_edge(int u, int v) {
	G[u].push_back(v), deg[v]++;
}


int build(int l, int r) {
	int x = ++tot;
	if (l == r) return ch[x][0] = 0, ch[x][1] = 0, x;
	return ch[x][0] = build(l, mid), ch[x][1] = build(mid + 1, r), x;
}

int grow(int bs, int l, int r, int y, int z) {
	int x = ++tot;
	ch[x][0] = ch[bs][0], ch[x][1] = ch[bs][1], add_edge(x, bs);
	if (l == r) return add_edge(x, y), x;
	if (z <= mid) ch[x][0] = grow(ch[bs][0], l, mid, y, z), add_edge(x, ch[x][0]);
	else ch[x][1] = grow(ch[bs][1], mid + 1, r, y, z), add_edge(x, ch[x][1]);
	return x;
}

void solve(int x, int l, int r, int lx, int rx, int y) {
	if (!x) return;
	if (l >= lx && r <= rx) return add_edge(y, x), void();
	if (lx <= mid) solve(ch[x][0], l, mid, lx, rx, y);
	if (rx > mid) solve(ch[x][1], mid + 1, r, lx, rx, y);
}

int main() {
	scanf("%d", &T);
	while (T--) {
		scanf("%s", s + 1), len = strlen(s + 1);
		suffix_sort(len), get_height(len);
		lg = 0;
		for (int k = 1; 1 << k <= len - 1; k++) {
			lg = k;
			for (int i = 1, j = (1 << (k - 1)) + 1; i <= len - (1 << k); i++, j++) {
				hei[k][i] = min(hei[k - 1][i], hei[k - 1][j]);
			}
		}
		cnt = 0;
		scanf("%d", &n);
		for (int i = 1; i <= n; i++) {
			scanf("%d %d", &l1[i], &ln1[i]), ln1[i] = ln1[i] - l1[i] + 1;
			e[++cnt] = event(1, i, ln1[i], l1[i]);
		}
		scanf("%d", &m);
		for (int i = 1; i <= m; i++) {
			scanf("%d %d", &l2[i], &ln2[i]), ln2[i] = ln2[i] - l2[i] + 1;
			e[++cnt] = event(2, i, ln2[i], l2[i]);
		}
		sort(e + 1, e + cnt + 1);
		scanf("%d", &k);
		for (int i = 1, x, y; i <= k; i++) {
			scanf("%d %d", &x, &y), add_edge(x, y + n);
		}
		tot = n + m, rt = 0;
		rt = build(1, len);
		for (int i = 1; i <= cnt; i++) {
			if (e[i].type == 1) {
				rt = grow(rt, 1, len, e[i].id, rnk[e[i].y]);
			} else {
				int l = rnk[e[i].y], r = l;
				for (int k = lg; ~k; k--) {
					if (l - (1 << k) > 0 && hei[k][l - (1 << k)] >= e[i].x) l -= 1 << k;
				}
				for (int k = lg; ~k; k--) {
					if (r + (1 << k) <= len && hei[k][r] >= e[i].x) r += 1 << k;
				}
				solve(rt, 1, len, l, r, e[i].id + n);
			}
		}
		for (int i = 1; i <= tot; i++) {
			dp[i] = i <= n ? ln1[i] : 0;
			if (!deg[i]) Q.push(i);
		}
		cnt = 0;
		ll ans = 0;
		while (!Q.empty()) {
			int u = Q.front();
			cnt++, Q.pop(), ans = max(ans, dp[u]);
			for (int i = 0, v; i < G[u].size(); i++) {
				v = G[u][i];
				dp[v] = max(dp[v], dp[u] + (v <= n ? ln1[v] : 0));
				if (!--deg[v]) Q.push(v);
			}
		}
		if (cnt != tot) puts("-1");
		else printf("%lld\n", ans);
		for (int i = 1; i <= tot; i++) {
			G[i].clear(), deg[i] = 0;
		}
	}
	return 0;
}
```