---
title: 「学习笔记」斯特林数
date: 2019-11-26 00:00:00
mathjax: true
tags:
	- 学习笔记
	- 斯特林数
	- 容斥原理

---

# 第一类斯特林数

第一类斯特林数 $s(n, m)$ 表示长度为 $n$ 的置换有 $m$ 个环的方案数。

第一类斯特林数有递推式 $s(n, m) = s(n - 1, m - 1) + s(n - 1, m) \times (n - 1)$，（讨论第 $n$ 个数新开一个环或者接在之前某个数后面），还有 $s(n, m) = \sum_{i = 1}^n s(n - i, m - 1) \times (i - 1)! \times C(n - 1, i - 1)$（枚举第一个数所在的环的大小，并考虑其他数的排法）。

可以用分治 FFT 在 $O(n \log^2 n)$ 的时间内求出第一类斯特林数的一行。

<!--more-->

## Count The Buildings

[「HDU 4372」Count the Buildings](http://acm.hdu.edu.cn/showproblem.php?pid=4372)

### 题目描述

求前缀递增单调栈长度为 $x$，后缀递增单调栈长度为 $y$ 的长度为 $n$ 的排列个数。

数据范围：$T \le 10^5, n, x, y \le 2000$。

### 思路分析

考虑排列中 $n$ 的位置，它左边形成了 $x - 1$ 组 $a_{l_i}, a_{l_i + 1}, \cdots, a_{r_i}$，其中 $l_i \le r_i, r_i + 1 = l_{i - 1}$，满足 $a_{l_i} > a_{l_i + 1}, a_{l_i + 2}, \cdots, a_{r_i}$，并且 $a_{l_{i}} < a_{l_{i + 1}}$。其实就是左边的置换有 $x - 1$ 个环的方案数（对于每个环把最大值转到第一位，并把环按照最大值排序），右边同理。问题变成了左边 $x - 1 + y - 1$ 个置换，选 $x - 1$ 个放左边的方案数，也就是 $s(n - 1, x + y - 2) \times C(x + y - 2, x - 1)$。

### 代码实现

```cpp
#include <bits/stdc++.h>
using namespace std;

const int maxn = 2e3, mod = 1e9 + 7;
int T, n, l, r, c[maxn + 3][maxn + 3], s[maxn + 3][maxn + 3];

int main() {
    s[0][0] = 1;
    for (int i = 0; i <= maxn; i++) {
        c[i][0] = 1;
    }
    for (int i = 1; i <= maxn; i++) {
        for (int j = 1; j <= i; j++) {
            c[i][j] = (c[i - 1][j - 1] + c[i - 1][j]) % mod;
            s[i][j] = (s[i - 1][j - 1] + 1ll * s[i - 1][j] * (i - 1)) % mod;
        }
    }
    scanf("%d", &T);
    while (T --> 0) {
        scanf("%d %d %d", &n, &l, &r);
        if (l + r - 2 > n - 1) {
            puts("0");
        } else {
            printf("%lld\n", 1ll * s[n - 1][l + r - 2] * c[l + r - 2][l - 1] % mod);
        }
    }
    return 0;
}
```

# 第二类斯特林数

第二类斯特林数 $S(n, m)$ 表示 $n$ 个不同元素分成 $m$ 个集合的方案数。

第二类斯特林数有递推式 $S(n, m) = S(n - 1, m - 1) + S(n - 1,m) \times m$（枚举最后一个数新开一个集合或插入之前的一个集合），还有 $S(n, m) = \sum_{i = 1}^m S(n - i, m - 1) \times C(n - 1, i - 1)$（枚举第一个数所在集合的大小，然后考虑其他数的选法）。

有恒等式 $n^m = \sum_{i = 0}^{n} S(m, i) \times i! \times C(n, i) = \sum_{i = 0}^{n} S(m, i) \times n^{\underline{i}}$，这样可以把 $x^k$ 转化成下降幂的形式。

## 第二类斯特林数·行

[「Luogu 5395」第二类斯特林数·行](https://www.luogu.com.cn/problem/P5395)

### 题目描述

求 $S(n, 0), S(n, 1), \cdots, S(n, n)$。

数据范围：$n \le 2 \times 10^5$。

###思路分析

前置知识——二项式反演：

$$F(n) = \sum_{i = 0}^{n} \binom{n}{i} \times G(i)$$

$$ G(n) = \sum_{i = 0}^{n} (-1)^{n - i} \times \binom{n}{i} \times F(i)$$

那么，利用二项式反演，我们可以推出第二类斯特林数的通项公式：

$$n^m = \sum_{i = 0}^{n} S(m, i) \times i! \times C(n, i)$$

$$S(m, n) = \frac{1}{n!} \sum_{i = 0}^{n} i^m \times (-1)^{n - i} \times C(n, i)$$

当然这个式子也可以用容斥原理来解释。式子变形一下可得：

$$S(n, m) = \frac{1}{m!} \sum_{i = 0}^{m} (m - i)^n \times (-1)^{i} \times C(m, i)$$

可以把 $i$ 看作空集合的个数，我们把元素随意放在其他的集合中，然后进行容斥。最后由于盒子是相同的，答案要除以 $m!$。

构造多项式 $A_i = \sum_{i} \frac{i^n}{i!} x^i, B_i = \frac{(-1)^{i}}{(i)!} x_i$ 进行卷积即可求出 $S(n, 0), S(n, 1), \cdots, S(n, n)$。时间复杂度 $O(n \log n)$。

### 代码实现

```cpp
#include <bits/stdc++.h>
using namespace std;

const int maxn = 1 << 19, mod = 167772161, g = 3;
int n, p_n[maxn + 3], fact[maxn + 3], finv[maxn + 3];
int lim, k, rev[maxn + 3], A[maxn + 3], B[maxn + 3], C[maxn + 3];

int f(int x) {
	return x < mod ? x : x - mod;
}

int qpow(int a, int b) {
	if (b < 0) b += mod - 1;
	int c = 1;
	for (; b; b >>= 1, a = 1ll * a * a % mod) {
		if (b & 1) c = 1ll * a * c % mod;
	}
	return c;
}

void prework(int n) {
	for (int i = 1; i <= n; i++) {
		p_n[i] = qpow(i, n);
	}
	fact[0] = 1;
	for (int i = 1; i <= n; i++) {
		fact[i] = 1ll * fact[i - 1] * i % mod;
	}
	finv[n] = qpow(fact[n], mod - 2);
	for (int i = n; i; i--) {
		finv[i - 1] = 1ll * finv[i] * i % mod;
	}
}

void dft(int A[], int n, int t) {
	for (int i = 0; i < n; i++) if (i < rev[i]) {
		swap(A[i], A[rev[i]]);
	}
	for (int k = 1; k < n; k <<= 1) {
		int x = qpow(g, (mod - 1) / (k << 1) * t);
		for (int i = 0; i < n; i += k << 1) {
			int y = 1;
			for (int j = i; j < i + k; j++, y = 1ll * x * y % mod) {
				int p = A[j], q = 1ll * A[j + k] * y % mod;
				A[j] = f(p + q), A[j + k] = f(p - q + mod);
			}
		}
	}
	if (t == -1) {
		int x = qpow(n, mod - 2);
		for (int i = 0; i < n; i++) {
			A[i] = 1ll * A[i] * x % mod;
		}
	}
}

int main() {
	scanf("%d", &n);
	prework(n);
	for (int i = 0; i <= n; i++) {
		A[i] = 1ll * p_n[i] * finv[i] % mod;
	}
	for (int i = 0; i <= n; i++) {
		B[i] = 1ll * (i & 1 ? mod - 1 : 1) * finv[i] % mod;
	}
	for (lim = 1, k = 0; lim <= n * 2; lim <<= 1) k++;
	for (int i = 1; i < lim; i++) {
		rev[i] = (rev[i >> 1] >> 1) | ((i & 1) << (k - 1));
	}
	dft(A, lim, 1), dft(B, lim, 1);
	for (int i = 0; i < lim; i++) {
		C[i] = 1ll * A[i] * B[i] % mod;
	}
	dft(C, lim, -1);
	for (int i = 0; i <= n; i++) {
		printf("%d%c", C[i], " \n"[i == n]);
	}
	return 0;
}
```

## Crash 的文明世界

[「Luogu 4827」Crash 的文明世界](https://www.luogu.com.cn/problem/P4827)

### 题目描述

给定 $n$ 个点的树，边权为 $1$，对于每个 $i$，求出 $\sum_{j = 1}^{n} \text{dist}(i, j)^k$。

数据范围：$n \le 5 \times 10^4, k \le 150$。

### 思路分析

首先我们有 $x^k = \sum_{i = 0}^{k} S(k, i) \times i! \times C(x, i)$，我们将 $\text{dist}(i, j)$ 代入其中，这样我们就只用求  $\sum_{j = 1}^{n} C(\text{dist}(i, j), k)$ 即可，而这个显然可以树形 dp 做。时间复杂度 $O(nk)$。

### 代码实现

```cpp
#include <bits/stdc++.h>
using namespace std;

const int maxn = 5e4, maxm = 150, mod = 1e4 + 7;
int n, m, S[maxm + 3][maxm + 3], dp[maxn + 3][maxm + 3];
int F[maxm + 3], f[maxn + 3][maxm + 3], up[maxn + 3][maxm + 3];
vector<int> G[maxn + 3];

int func(int x) {
	return x < mod ? x : x - mod;
}

void dfs(int u, int pa = 0) {
	dp[u][0] = 1;
	for (int i = 0, v; i < G[u].size(); i++) {
		v = G[u][i];
		if (v == pa) continue;
		dfs(v, u);
		dp[u][0] = func(dp[u][0] + dp[v][0]);
		for (int j = 1; j <= m; j++) {
			dp[u][j] = func(dp[u][j] + dp[v][j]);
			dp[u][j] = func(dp[u][j] + dp[v][j - 1]);
		}
	}
}

void solve(int u, int pa = 0) {
	for (int i = 0, v; i < G[u].size(); i++) {
		v = G[u][i];
		if (v == pa) continue;
		for (int j = 0; j <= m; j++) {
			f[u][j] = func(up[u][j] + dp[u][j]);
		}
		f[u][0] = func(f[u][0] - dp[v][0] + mod);
		for (int j = 1; j <= m; j++) {
			f[u][j] = func(f[u][j] - dp[v][j] + mod);
			f[u][j] = func(f[u][j] - dp[v][j - 1] + mod);
		}
		up[v][0] = f[u][0];
		for (int j = 1; j <= m; j++) {
			up[v][j] = func(up[v][j] + f[u][j]);
			up[v][j] = func(up[v][j] + f[u][j - 1]);
		}
		solve(v, u);
	}
}

int main() {
	scanf("%d %d", &n, &m);
	S[0][0] = 1;
	for (int i = 1; i <= m; i++) {
		for (int j = 1; j <= m; j++) {
			S[i][j] = (S[i - 1][j - 1] + S[i - 1][j] * j) % mod;
		}
	}
	F[0] = 1;
	for (int i = 1; i <= m; i++) {
		F[i] = 1ll * F[i - 1] * i % mod;
	}
	for (int i = 1, u, v; i < n; i++) {
		scanf("%d %d", &u, &v);
		G[u].push_back(v), G[v].push_back(u);
	}
	dfs(1);
	solve(1);
	for (int i = 1; i <= n; i++) {
		int ans = 0;
		for (int j = 0; j <= m; j++) {
			int x = func(dp[i][j] + up[i][j]);
			ans = (ans + 1ll * S[m][j] * F[j] * x) % mod;
		}
		printf("%d\n", ans);
	}
	return 0;
}
```

## 求和

[「BZOJ 4555」求和](http://darkbzoj.tk/problem/4555)

### 题目描述

对于给定的 $n$，求：$f(n) = \sum_{i = 0}^{n} \sum_{j = 0}^{i} S(i, j) \times 2^j \times j!$，对 $998244353$ 取模。

数据范围：$n \le 10^5$。

### 思路分析

考虑 $g(n) = \sum_{i = 0}^{n} S(n, i) \times 2^i \times i!$ 的组合意义：将 $n$ 个元素放进若干个有序的集合，每个有元素的集合有两种状态。那么我们就有递推式：$g(n) = \sum_{i = 1}^{n} C(n, i) \times g(n - i) \times 2$，思路是枚举某个集合的大小。使用分治 FFT 计算即可，时间复杂度 $O(n \log^2 n)$。

### 代码实现

```cpp
#include <bits/stdc++.h>
using namespace std;

const int maxn = 1 << 18, mod = 998244353;
int n, f[maxn + 3], g[maxn + 3], h[maxn + 3], fact[maxn + 3], finv[maxn + 3];
int lim, k, rev[maxn + 3], A[maxn + 3], B[maxn + 3], C[maxn + 3];

int func(int x) {
	return x < mod ? x : x - mod;
}

int qpow(int a, int b) {
	if (b < 0) b += mod - 1;
	int c = 1;
	for (; b; b >>= 1, a = 1ll * a * a % mod) {
		if (b & 1) c = 1ll * a * c % mod;
	}
	return c;
}

void prework(int n) {
	fact[0] = 1;
	for (int i = 1; i <= n; i++) {
		fact[i] = 1ll * fact[i - 1] * i % mod;
	}
	finv[n] = qpow(fact[n], mod - 2);
	for (int i = n; i; i--) {
		finv[i - 1] = 1ll * finv[i] * i % mod;
	}
}

void dft(int A[], int n, int t) {
	for (int i = 0; i < n; i++) if (i < rev[i]) {
		swap(A[i], A[rev[i]]);
	}
	for (int k = 1; k < n; k <<= 1) {
		int x = qpow(3, (mod - 1) / (k << 1) * t);
		for (int i = 0; i < n; i += k << 1) {
			int y = 1;
			for (int j = i; j < i + k; j++, y = 1ll * x * y % mod) {
				int p = A[j], q = 1ll * A[j + k] * y % mod;
				A[j] = func(p + q), A[j + k] = func(p - q + mod);
			}
		}
	}
	if (t == -1) {
		int x = qpow(n, mod - 2);
		for (int i = 0; i < n; i++) {
			A[i] = 1ll * A[i] * x % mod;
		}
	}
}

void cdq(int l, int r) {
	if (l == 0 && r == 0) {
		return;
	}
	if (l == r) {
		g[l] = 2ll * g[l] * fact[l] % mod;
		h[l] = 1ll * g[l] * finv[l] % mod;
		return;
	}
	int mid = (l + r) >> 1;
	cdq(l, mid);
	int p = mid - l, q = r - l;
	for (int i = 0; i <= p; i++) {
		A[i] = h[i + l];
	}
	for (int i = 1; i <= q; i++) {
		B[i] = f[i];
	}
	for (lim = 1, k = 0; lim <= p + q; lim <<= 1) k++;
	for (int i = 1; i < lim; i++) {
		rev[i] = (rev[i >> 1] >> 1) | ((i & 1) << (k - 1));
	}
	fill(A + p + 1, A + lim, 0);
	fill(B + q + 1, B + lim, 0);
	dft(A, lim, 1), dft(B, lim, 1);
	for (int i = 0; i < lim; i++) {
		C[i] = 1ll * A[i] * B[i] % mod;
	}
	dft(C, lim, -1);
	for (int i = 1; i <= q - p; i++) {
		g[i + mid] = (g[i + mid] + C[i + p]) % mod;
	}
	cdq(mid + 1, r);
}

int main() {
	scanf("%d", &n);
	prework(n);
	for (int i = 1; i <= n; i++) {
		f[i] = finv[i];
	}
	g[0] = 1, h[0] = 1;
	cdq(0, n);
	int ans = 0;
	for (int i = 0; i <= n; i++) {
		ans = func(ans + g[i]);
	}
	printf("%d\n", ans);
	return 0;
}
```

## Partitions

[「Codeforces 961G」Partitions](https://codeforces.com/problemset/problem/961/G)

### 题目描述

给定 $n$ 个元素 $w_1, w_2, \cdots, w_n$，定义一个集合 $S$ 的权值为 $\vert S \vert \times \sum_{i \in S} w_i$，定义一个划分的权值为分出所有集合的权值和，求将这 $n$ 个元素划成 $k$ 个集合的权值和之和。

数据范围：$n, k \le 2 \times 10^5$。

### 思路分析

记 $W = \sum_{i = 1}^{n} w_i$，枚举某个点所在集合的大小可得答案等于：

$$W \times \sum_{i = 1}^{n} i \times C(n - 1, i - 1) \times S(n - i, k - 1)$$

那么我们开始推式子：

$$ \begin{align*} & \sum_{i = 1}^{n} i \times C(n - 1, i - 1) \times S(n - i, k - 1) \\ = & \sum_{i = 1}^{n} i \times C(n - 1, i - 1) \times \sum_{j = 0}^{k - 1} \frac{(-1)^j \times (k - 1 - j)^{n - i}}{j! \times (k - 1 - j)!} \\ = & \sum_{j = 0}^{k - 1} \frac{(-1)^j}{j! \times (k - 1 - j)!} \sum_{i = 1}^{n} (k - 1 - j)^{n - i} \times i \times C(n - 1, i - 1) \\ = & \sum_{j = 0}^{k - 1} \frac{(-1)^j}{j! \times (k - 1 - j)!} \sum_{i = 1}^{n} \frac{(k - 1 - j)^{n - i} \times i \times (n - 1)!}{(i - 1)! \times (n - i)!} \\ = & \sum_{j = 0}^{k - 1} \frac{(-1)^j}{j! \times (k - 1 - j)!} \sum_{i = 1}^{n} \left[ \frac{(k - 1 - j)^{n - i} \times (n - 1)!}{(i - 1)! \times (n - i)!} + \frac{(k - 1 - j)^{n - i} \times (i - 1) \times (n - 1)!}{(i - 1)! \times (n - i)!} \right] \\ = & \sum_{j = 0}^{k - 1} \frac{(-1)^j}{j! \times (k - 1 - j)!} \sum_{i = 1}^{n} \left[ \frac{(k - 1 - j)^{n - i} \times (n - 1)!}{(i - 1)! \times (n - i)!} + \frac{(k - 1 - j)^{n - i} \times (n - 1)!}{(i - 2)! \times (n - i)!} \right] \\ = & \sum_{j = 0}^{k - 1} \frac{(-1)^j}{j! \times (k - 1 - j)!} \left[ \sum_{i = 1}^{n} (k - 1 - j)^{n - i} \times C(n - 1, i - 1) + (n - 1) \sum_{i = 1}^{n} (k - 1 - j)^{n - i} \times C(n - 2, i - 1) \right] \\ & \sum_{j = 0}^{k - 1} \frac{(-1)^j}{j! \times (k - 1 - j)!} \left[ (k -  j)^{n - 1} + (n - 1)  (k - j)^{n - 2} \right] \end{align*} $$

那么我们直接计算即可。

当然也有巧妙一点的方法：考虑某个元素对答案的贡献。首先每个元素都会贡献自己，贡献是 $w_i \times S(n, k)$；另外如果它和其他元素同在一个集合，我们让该集合中的每个其他元素都给它 $1$ 的贡献，也就是说我们可以先从剩下 $n - 1$ 个元素中选 $k$ 个集合，然后 $n - 1$ 个元素都给新加入的元素贡献 $1$，总贡献就是 $w_i \times (n - 1) \times S(n - 1, k)$。所以答案就是 $W \times \left[ S(n, k) + (n - 1) \times S(n - 1, k) \right]$，直接计算即可。时间复杂度 $O(n)$。

### 代码实现

```cpp
#include <bits/stdc++.h>
using namespace std;

const int maxn = 2e5, mod = 1e9 + 7;
int n, k, sum, num;

int func(int x) {
	return x < mod ? x : x - mod;
}

int qpow(int a, int b) {
	int c = 1;
	for (; b; b >>= 1, a = 1ll * a * a % mod) {
		if (b & 1) c = 1ll * a * c % mod;
	}
	return c;
}

int S(int n, int m) {
	int ret = 0, cur = 1;
	for (int i = 1; i <= m; i++) {
		cur = 1ll * cur * qpow(i, mod - 2) % mod;
	}
	for (int i = 0; i <= m; i++) {
		ret = (ret + 1ll * (i & 1 ? mod - 1 : 1) * cur % mod * qpow(m - i, n)) % mod;
		cur = 1ll * cur * (m - i) % mod * qpow(i + 1, mod - 2) % mod;
	}
	return ret;
}

int main() {
	scanf("%d %d", &n, &k);
	for (int i = 1, x; i <= n; i++) {
		scanf("%d", &x);
		sum = func(sum + x);
	}
	num = (S(n, k) + 1ll * S(n - 1, k) * (n - 1)) % mod;
	printf("%lld\n", 1ll * sum * num % mod);
	return 0;
}
```

## 异或图

### 题目描述

给定 $n$ 张 $m$ 个点的无向图，两个图的异或定义为邻接矩阵的异或，求所有 $2^n$ 个子集的图的异或和中有多少图是联通的。

数据范围：$n \le 60, m \le 10$。

### 思路分析

前置技能——斯特林反演（的变形？）：

$F(m) = \sum_{i = m}^{n} S(i, m) \times G(i)$

$G(m) = \sum_{i = m}^{n} (-1)^{i - m} \times s(i, m) \times F(i)$

我们考虑枚举全集的一个划分，强制划分出的任意两个集合之间不能有边（集合内部可以有边）。那么对于一个有 $m$ 个联通块的异或图，如果我们强制划出了 $n$ 个集合，这个方案会被计算 $S(m, n)$ 次。相当于如果我们强制划出 $i$ 个集合算出的方案数为 $F_i$，有 $i$ 个联通块的异或图共有 $G_i$ 个，那么 $F, G$ 就满足上面斯特林反演的关系。所以，我们先枚举划分，然后用线性基求出满足划分条件的异或图个数，从而求出 $F$ 数组，最后用斯特林反演求出 $G(1)$ 即可（注：$s(n, 1) = (n - 1)!$）。时间复杂度 $O(B(m) \cdot n \cdot \frac{m (m - 1)}{2})$，其中 $B(n) = \sum_{i = 0}^{n} S(n, i)$。

### 代码实现

```cpp
#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn = 60, maxm = 10;
int n, m, a[maxn + 3][maxm + 3][maxm + 3];
int id[maxm + 3], tmp[maxm + 3][maxm + 3];
ll f[maxm + 3], num[maxn + 3], base[maxn + 3];
char s[maxn + 3];

bool insert(ll x, int n) {
	for (int i = n; ~i; i--) {
		if (x >> i & 1) {
			if (!base[i]) {
				base[i] = x;
				return true;
			}
			x ^= base[i];
		}
	}
	return false;
}

ll solve() {
	for (int i = 1; i <= n; i++) {
		num[i] = 0;
	}
	int p = 0;
	for (int i = 1; i <= m; i++) {
		for (int j = i + 1; j <= m; j++) {
			if (id[i] != id[j]) {
				for (int k = 1; k <= n; k++) {
					if (a[k][i][j]) {
						num[k] |= 1ll << (ll) p;
					}
				}
				p++;
			}
		}
	}
	for (int i = 0; i < p; i++) {
		base[i] = 0;
	}
	ll ret = 1;
	for (int i = 1; i <= n; i++) {
		if (!insert(num[i], p - 1)) ret <<= 1;
	}
	return ret;
}

void dfs(int lft, int dep) {
	if (lft == 0) {
		f[dep] += solve();
		return;
	}
	int x = 0;
	for (int i = 1; i <= m; i++) {
		if (!id[i]) {
			x = i;
			break;
		}
	}
	int d = dep + 1, cnt = 0, *cur = tmp[d];
	for (int i = x + 1; i <= m; i++) {
		if (!id[i]) cur[++cnt] = i;
	}
	id[x] = d;
	for (int msk = 0; msk < 1 << cnt; msk++) {
		int y = lft - 1;
		for (int i = 1; i <= cnt; i++) {
			if (msk >> (i - 1) & 1) {
				id[cur[i]] = d, y--;
			}
		}
		dfs(y, d);
		for (int i = 1; i <= cnt; i++) {
			if (msk >> (i - 1) & 1) {
				id[cur[i]] = 0;
			}
		}
	}
}

int main() {
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf("%s", s + 1);
		if (i == 1) {
			int t = strlen(s + 1);
			for (int j = 2; j <= maxm; j++) {
				if (j * (j - 1) == t * 2) {
					m = j;
					break;
				}
			}
		}
		int p = 0;
		for (int j = 1; j <= m; j++) {
			for (int k = j + 1; k <= m; k++) {
				a[i][j][k] = a[i][k][j] = s[++p] - '0';
			}
		}
	}
	dfs(m, 0);
	ll ans = 0, cur = 1;
	for (int i = 1; i <= m; i++) {
		ans += 1ll * (i & 1 ? 1 : -1) * cur * f[i];
		cur *= i;
	}
	printf("%lld\n", ans);
	return 0;
}
```

