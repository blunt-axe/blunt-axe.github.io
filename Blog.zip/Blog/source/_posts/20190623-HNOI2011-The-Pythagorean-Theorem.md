---
title: 「HNOI 2011」勾股定理（数论 + 动态规划）
date: 2019-06-23 00:00:00
mathjax: true
tags:
	- 数论
	- 动态规划

---

# 题目大意
[「HNOI 2011」勾股定理（Luogu 3213）](https://www.luogu.org/problemnew/show/P3213)

给定 $n$ 个数 $a_1, a_2, \cdots, a_n$，问可以选出多少种位置集合，满足集合内部任意两个位置对应的数不形成互素勾股数对。互素勾股数对的意义是：$(a, b) = 1$，且 $a^2 + b^2$ 可以表示成 $c^2$ 的形式。

数据范围：$n \le 10^6$，$1 \le a_i \le 2 \times 10^5$ 或 $2 \times 10^4 \le a_i \le 10^6$。

<!--more-->

# 思路分析
互素勾股数对很少，我们考虑快速地找到他们。通过小学奥数可知，勾股数对一定可以写成如下形式：

$$(x^2 - y^2)^2 + (2xy)^2 = (x^2 + y^2)^2$$

如果 $x^2 - y^2$ 和 $2xy$ 互素，那么 $x, y$ 互素并且不全是奇数。考虑枚举 $x, y$，再对它们进行检验，具体代码如下：

```cpp
void prework() {
	for (int x = 1; x * x <= m; x++) {
		for (int y = x + 1; 2 * x * y <= m; y++) {
			if (y * y > 2 * m) break;
			if (y * y - x * x <= m && (x & 1) != (y & 1) && gcd(x, y) == 1) {
				int a = y * y - x * x, b = 2 * x * y;
				// (a, b) 是一组 <= m 的互素勾股数对
			}
		}
	}
}
```

接下来根据预处理出的勾股数对建图，问题就转化成了求图的独立集个数。我们发现这个图的边数和点数很接近，于是我们可以搞出图的一个 DFS 树，然后对于非树边容斥，做树形 DP 即可。（其实就是[「HNOI2018」毒瘤（Luogu 4426）](https://www.luogu.org/problemnew/show/P4426)一题的弱化版，不需要建虚树）

# 代码实现
```cpp
#include <cstdio>
#include <vector>
using namespace std;

const int maxn = 1e6, mod = 1e9 + 7;
int n, m, bin[maxn + 3], cnt[maxn + 3], k, p[maxn + 3], q[maxn + 3], tm, lim[maxn + 3], f[maxn + 3][2];
bool vis[maxn + 3];
vector<int> G[maxn + 3], T[maxn + 3];

void add(int u, int v) {
	G[u].push_back(v);
}

int gcd(int a, int b) {
	return b ? gcd(b, a % b) : a;
}

void prework() {
	bin[0] = 1;
	for (int i = 1; i <= n; i++) {
		bin[i] = bin[i - 1] * 2 % mod;
	}
	for (int x = 1; x * x <= m; x++) {
		for (int y = x + 1; 2 * x * y <= m; y++) {
			if (y * y > 2 * m) break;
			if (y * y - x * x <= m && (x & 1) != (y & 1) && gcd(x, y) == 1) {
				int a = y * y - x * x, b = 2 * x * y;
				if (cnt[a] && cnt[b]) {
					add(a, b), add(b, a);
				}
			}
		}
	}
}

void dfs(int u, int pa = 0) {
	vis[u] = true;
	for (int i = 0, v; i < G[u].size(); i++) {
		v = G[u][i];
		if (v == pa) continue;
		if (!vis[v]) {
			T[u].push_back(v);
			dfs(v, u);
		} else {
			++k;
			p[k] = u;
			q[k] = v;
		}
	}
}

void dp(int u) {
	f[u][0] = 1, f[u][1] = bin[cnt[u]] - 1;
	if (lim[u] == tm) f[u][0] = 0;
	for (int i = 0, v; i < T[u].size(); i++) {
		dp(v = T[u][i]);
		f[u][0] = 1ll * f[u][0] * (f[v][0] + f[v][1]) % mod;
		f[u][1] = 1ll * f[u][1] * f[v][0] % mod;
	}
}

int bit_cnt(int x) {
	return __builtin_popcount(x);
}

int solve(int u) {
	k = 0;
	dfs(u);
	int ans = 0;
	for (int i = 0; i < 1 << k; i++) {
		++tm;
		for (int j = 1; j <= k; j++) {
			if (i >> (k - j) & 1) {
				lim[p[j]] = lim[q[j]] = tm;
			}
		}
		dp(u);
		ans = (ans + 1ll * (f[u][0] + f[u][1]) * (bit_cnt(i) & 1 ? mod - 1 : 1)) % mod;
	}
	return ans;
}

int main() {
	scanf("%d", &n);
	for (int i = 1, x; i <= n; i++) {
		scanf("%d", &x);
		m = max(m, x), cnt[x]++;
	}
	prework();
	int res = 1;
	for (int i = 1; i <= m; i++) if (cnt[i] && !vis[i]) {
		res = 1ll * res * solve(i) % mod;
	}
	printf("%d\n", (res + mod - 1) % mod);
	return 0;
}
```