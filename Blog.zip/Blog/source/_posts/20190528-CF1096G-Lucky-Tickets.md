---
title: 「Codeforces 1096G」Lucky Tickets（生成函数 + 多项式）
date: 2019-05-28 00:00:00
mathjax: true
tags:
	- 生成函数
	- 多项式
---

# 题目大意
[「Codeforces 1096G」Lucky Tickets](https://codeforces.com/problemset/problem/1096/G)

给定偶数 $n$ 和 $k$ 个数位，求长度为 $n$ 的数字串，满足只使用给定的数位，且前 $\frac{n}{2}$ 位的和等于后 $\frac{n}{2}$ 位的和的个数 $\bmod 998244353$ 的结果。

数据范围：$n \le 2 \times 10^5$。

<!--more-->

# 思路分析
记 $A_i$ 表示使用给定数位，$\frac{n}{2}$ 位的和为 $i$ 的方案数，那么答案为 $\sum_{i = 0}^{\infty}A_i^2$，于是我们只需求 $A$ 即可。

发现 $A$ 是由给定数位形成的生成函数的 $\frac{n}{2}$ 次方，因为生成函数的次数不超过 $9$，所以 $A$ 的最大次数不超过 $4.5n$，用 NTT 求解即可。 时间复杂度 $O(n \log n)$。

# 代码实现
```cpp
#include <cstdio>
#include <algorithm>
using namespace std;

const int maxn = 1 << 20, mod = 998244353, g = 3;
int n, m, q, k, rev[maxn + 3], a[maxn + 3];

inline int func(int x, int y = mod) {
	return x < 0 ? x + y : x < y ? x : x - y;
}

int qpow(int a, int b) {
	int c = 1;
	for (; b; b >>= 1, a = 1ll * a * a % mod) {
		if (b & 1) c = 1ll * a * c % mod;
	}
	return c;
}

void dft(int a[], int n, int type) {
	for (int i = 0; i < n; i++) if (i < rev[i]) {
		swap(a[i], a[rev[i]]);
	}
	for (int k = 1; k < n; k *= 2) {
		int x = qpow(g, func(type * (mod - 1) / (k * 2), mod - 1));
		for (int i = 0; i < n; i += 2 * k) {
			int y = 1;
			for (int j = i; j < i + k; j++, y = 1ll * x * y % mod) {
				int p = a[j], q = 1ll * a[j + k] * y % mod;
				a[j] = func(p + q), a[j + k] = func(p - q);
			}
		}
	}
	if (type == -1) {
		int x = qpow(n, mod - 2);
		for (int i = 0; i < n; i++) {
			a[i] = 1ll * a[i] * x % mod;
		}
	}
}

int main() {
	scanf("%d %d", &n, &q);
	n /= 2, m = n * 9;
	for (int x; q--; ) {
		scanf("%d", &x);
		a[x] = 1;
	}
	for (k = 0; 1 << k < m; k++);
	for (int i = 1; i < 1 << k; i++) {
		rev[i] = (rev[i >> 1] >> 1) | ((i & 1) << (k - 1));
	}
	dft(a, 1 << k, 1);
	for (int i = 0; i < 1 << k; i++) {
		a[i] = qpow(a[i], n);
	}
	dft(a, 1 << k, -1);
	int ans = 0;
	for (int i = 0; i <= m; i++) {
		ans = (ans + 1ll * a[i] * a[i]) % mod;
	}
	printf("%d\n", ans);
	return 0;
}
```