---
title: 「学习笔记」Tarjan 算法总结
date: 2019-06-29 00:00:01
mathjax: true
tags:
	- 学习笔记
	- Tarjan

---

Tarjan 算法是由 Robert Tarjan 提出的，可以求解图中的强连通分量的算法。

# Tarjan 求强连通分量
如果一个有向图是强连通图，那么它的任意一对结点都可以相互到达。一个有向图的某个极大的强连通子图称为强连通分量。不难发现所有强连通分量不会有重叠。

<!--more-->

Tarjan 算法是用来求解图中强连通分量的算法。我们定义 $\text{dfn}(i)$ 表示 $i$ 点在 DFS 树上的 DFS 序，$\text{low}(i)$ 表示 $i$ 点向下走能够访问到的结点中 dfn 的最小值。

对于每一个结点 $u$，我们访问与它相邻的点 $v$。如果这个点没被访问过，那我们就访问这个点，并用 $\text{low}(v)$ 来更新 $\text{low}(u)$。如果这个点被访问过了，我们需要看它是否已经被算进某个强连通分量中。只有它没有被算进去，我们才可以用 $\text{dfn}(v)$ 来更新 $\text{low}(u)$。因为我们要判断某个点是否已经被算进某个强连通分量中，所以我们要维护一个 bool 类型的数组 in。当 $\text{dfn}(u) = \text{low}(u)$ 的时候，我们发现从 $u$ 出发不能访问到比 $u$ 更靠前的结点了，也就是产生了一个以 $u$ 为根的强连通分量。

在 DFS 的过程中，我们维护一个栈，每次 DFS 到一个结点，我们往栈中加入这个结点，并把这个结点的 in 设成 `true`。拓展完所有与该结点相邻的结点后，我们判断该结点是否为一个强连通分量的根。如果是的话，该强连通分量一定是栈顶开始的一个前缀。于是我们暴力弹栈，然后将元素的 in 设为 `false` 即可。

下面的代码对应的题目是[「BZOJ 2438」杀人游戏](https://www.lydsy.com/JudgeOnline/problem.php?id=2438)。[这里](/2019/06/30/20190630-BZOJ2438-Killing-Game/)是本题的题解。

```cpp
#include <cstdio>
#include <cstdlib>
#include <vector>
using namespace std;

const int maxn = 1e5, maxm = 3e5;
int n, m, u[maxm + 3], v[maxm + 3], tm, dfn[maxn + 3], low[maxn + 3];
int top, st[maxn + 3], cnt, sum[maxn + 3], bel[maxn + 3], deg[maxn + 3];
bool in[maxn + 3], ok[maxn + 3];
vector<int> G[maxn + 3];

void add(int u, int v) {
	G[u].push_back(v);
}

void tarjan(int u) {
	dfn[u] = low[u] = ++tm;
	st[++top] = u, in[u] = true;
	for (int i = 0, v; i < G[u].size(); i++) {
		v = G[u][i];
		if (!dfn[v]) {
			tarjan(v);
			low[u] = min(low[u], low[v]);
		} else if (in[v]) {
			low[u] = min(low[u], dfn[v]);
		}
	}
	if (dfn[u] == low[u]) {
		++cnt;
		do {
			sum[cnt]++;
			bel[st[top]] = cnt;
			in[st[top]] = false;
		} while (st[top--] != u);
	}
}

int main() {
	scanf("%d %d", &n, &m);
	for (int i = 1; i <= m; i++) {
		scanf("%d %d", &u[i], &v[i]);
		add(u[i], v[i]);
	}
	for (int i = 1; i <= n; i++) {
		if (!dfn[i]) {
			tarjan(i);
		}
	}
	for (int i = 1; i <= n; i++) {
		G[i].clear();
	}
	for (int i = 1; i <= m; i++) {
		if (bel[u[i]] != bel[v[i]]) {
			deg[bel[v[i]]]++;
			G[bel[u[i]]].push_back(bel[v[i]]);
		}
	}
	int ans = 0;
	for (int i = 1; i <= cnt; i++) {
		ans += !deg[i];
	}
	for (int i = 1; i <= cnt; i++) {
		if (!deg[i] && sum[i] == 1) {
			bool flag = true;
			for (int j = 0; j < G[i].size(); j++) {
				if (deg[G[i][j]] == 1) {
					flag = false;
					break;
				}
			}
			if (flag) {
				ans--;
				break;
			}
		}
	}
	printf("%.6lf\n", 1. * (n - ans) / n);
	return 0;
}
```

# Tarjan 求割点
在一张无向图上，一个结点是割点，当且仅当删除掉这个结点以及与之相邻的所有边后，图变得不再联通。

Tarjan 算法可以推广到无向图上来求割点。我们进行 DFS，按照有向图上 Tarjan 的方法求出 dfn 数组和 low 数组。这里 low 数组的定义稍有改变，$\text{low}(i)$ 表示点 $i$ 不经过它的父亲结点，能够绕到的结点最小 dfn。为了方便起见，对于每条边 $(u, v)$，我们会将 $\text{low}(v) \leftarrow \min \{ \text{low}(v), \text{dfn}(u) \}$。那么如果一个**非根**的结点 $u$ 是割点，那么一定存在 $\text{low(v)} = \text{dfn}(u)$。注意特判根结点是否是割点，如果是它在 DFS 树上就一定有大于等于 $2$ 个孩子。

注意我们在找到访问过的点的时候，它是一定在当前结点到根的路径上的，所以我们不需要维护 in 数组。并且因为我们最后会进行 $\text{low}(v) \leftarrow \min \{ \text{low}(v), \text{dfn}(u) \}$ 的操作，那么我们在如果访问到了一个访问过的结点那么就不用特判它是否为原结点的父亲了，我们就可以直接来用 $\text{dfn}(v)$ 来更新 $\text{low}(u)$。

下面代码对应的题目是：[「模版」割点（Luogu 3388）](https://www.luogu.org/problemnew/show/P3388)。
```cpp
#include <cstdio>
#include <algorithm>
using namespace std;

const int maxn = 1e6, maxm = maxn * 2;
int n, m, tm, dfn[maxn + 3], low[maxn + 3];
int tot, ter[maxm + 3], nxt[maxm + 3], lnk[maxn + 3];
bool cut[maxn + 3];

void add(int u, int v) {
	ter[++tot] = v, nxt[tot] = lnk[u], lnk[u] = tot;
}

void tarjan(int u, bool is_rt = true) {
	dfn[u] = low[u] = ++tm;
	int cnt = 0;
	for (int i = lnk[u], v; i; i = nxt[i]) {
		v = ter[i];
		if (!dfn[v]) {
			tarjan(v, false);
			low[u] = min(low[u], low[v]);
			if (!is_rt && low[v] == dfn[u]) {
				cut[u] = true;
			}
			cnt++;
		} else {
			low[u] = min(low[u], dfn[v]);
		}
	}
	if (is_rt && cnt >= 2) {
		cut[u] = true;
	}
}

int main() {
	scanf("%d %d", &n, &m);
	for (int i = 1, u, v; i <= m; i++) {
		scanf("%d %d", &u, &v);
		add(u, v), add(v, u);
	}
	for (int i = 1; i <= n; i++) if (!dfn[i]) {
		tarjan(i);
	}
	int res = 0;
	for (int i = 1; i <= n; i++) {
		res += cut[i];
	}
	printf("%d\n", res);
	for (int i = 1; i <= n; i++) {
		if (cut[i]) {
			printf("%d%c", i, " \n"[!--res]);
		}
	}
	return 0;
}
```

# Tarjan 求桥
桥是无向图上的某条边，满足删去这条边以后图变得不联通。

桥的求法和割点类似，我们有相同的 dfn 数组和 low 数组的定义。只是我们不再有 “为了方便起见” 对定义的略微修改。那么，如果一个结点到它的父亲的那条边是桥，那么有 $\text{dfn}(u) = \text{low}(u)$。和求割点类似，我们也不需要维护 in 数组。但是如果需要缩点的话我们还是需要维护一个栈。

求桥的难点在于处理重边。对于每一个结点，我们要记录到达每个结点的边的编号 $\text{id}(u)$。在找到一个访问过的结点的时候，我们就要判断到达该结点的边是否是 $\text{id}(u)$。如果不是的话，才使用 $\text{dfn}(v)$ 来更新 $\text{low}(u)$。

下面代码对应的题目是：[「BZOJ 1718」Redundant Paths](https://www.lydsy.com/JudgeOnline/problem.php?id=1718)。[这里](/2019/05/21/20190521-BZOJ1718-Redundant-Paths/)是本题的题解。

```cpp
#include <cstdio>
#include <algorithm>
using namespace std;

const int maxn = 1e6, maxm = maxn * 2;
int n, m, u[maxm + 3], v[maxm + 3];
int tm, dfn[maxn + 3], low[maxn + 3], top, st[maxn + 3];
int cnt, bel[maxn + 3], deg[maxn + 3], cur;
int tot, ter[maxm + 3], nxt[maxm + 3], lnk[maxn + 3];
bool vis[maxn + 3];

void add(int u, int v) {
    ter[++tot] = v, nxt[tot] = lnk[u], lnk[u] = tot;
}

int adj(int x) {
    return x & 1 ? x + 1 : x - 1;
}

void tarjan(int u, int e = 0) {
    dfn[u] = low[u] = ++tm;
    st[++top] = u;
    for (int i = lnk[u], v; i; i = nxt[i]) {
        v = ter[i];
        if (!dfn[v]) {
            tarjan(v, i);
            low[u] = min(low[u], low[v]);
        } else if (i != adj(e)) {
            low[u] = min(low[u], dfn[v]);
        }
    }
    if (dfn[u] == low[u]) {
        cnt++;
        do {
            bel[st[top]] = cnt;
        } while (st[top--] != u);
    }
}

void dfs(int u, int pa = 0) {
    if (pa) {
        cur -= (deg[u] == 1) + (deg[pa] == 1);
        deg[u]++, deg[pa]++;
        cur += (deg[u] == 1) + (deg[pa] == 1);
    }
    vis[u] = true;
    for (int i = lnk[u], v; i; i = nxt[i]) {
        v = ter[i];
        if (!vis[v]) {
            dfs(v, u);
        }
    }
}

int main() {
    scanf("%d %d", &n, &m);
    for (int i = 1; i <= m; i++) {
        scanf("%d %d", &u[i], &v[i]);
        add(u[i], v[i]), add(v[i], u[i]);
    }
    for (int i = 1; i <= n; i++) {
        if (!dfn[i]) tarjan(i);
    }
    tot = 0;
    for (int i = 1; i <= n; i++) {
        lnk[i] = 0;
    }
    for (int i = 1; i <= m; i++) if (bel[u[i]] != bel[v[i]]) {
        add(bel[u[i]], bel[v[i]]), add(bel[v[i]], bel[u[i]]);
    }
    int ans = 0;
    for (int i = 1; i <= cnt; i++) if (!vis[i]) {
        cur = 0, dfs(i);
        ans += (cur + 1) / 2;
    }
    printf("%d\n", ans);
    return 0;
}
```