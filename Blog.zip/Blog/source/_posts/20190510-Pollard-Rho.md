---
title: 「学习笔记」Pollard-Rho 因数分解算法
date: 2019-05-10 00:00:00
mathjax: true
tags:
	- 数论
	- 学习笔记
---

Pollard-Rho 算法可以用期望 $O(\sqrt[4]{n})$ 的时间找到合数 $n$ 的一个非平凡因子。

# 算法流程
这里讲解改进后的 Pollard-Rho 算法变种。

在一次 Pollard-Rho 中，我们随机一个数 $c$，并设定阈值 $k$，初始为 $2$，每次循环后加倍。

对于每一次循环，令 $y$ 等于当前的 $x$，然后进行 $k$ 次，每次让 $x \leftarrow f(x) = (x ^ 2 + c) \bmod n$，然后检查 $\vert x - y \vert$ 和 $n$ 是否有非平凡的 $\gcd$，如果有则退出循环。

<!--more-->

实践后发现这样速度较快，这可说明该算法的复杂度较低，但是笔者不会严格证明算法的复杂度。有一个小优化，就是每次不直接检查 $\gcd$，而是将变量 $z \leftarrow z \times \vert x - y \vert$。进行 $B$ 次乘法后只要检查一次 $z$ 和 $n$ 的 $\gcd$ 即可。这可以节省 $\gcd$ 使用的时间，$B$ 一般使用 $128$。

Pollard-Rho 结合 Miller-Rabin 可以实现快速素因数分解。

# 代码实现

[「模板」Pollard-Rho 算法（Luogu 4718）](https://www.luogu.org/problemnew/show/P4718)
```cpp
#include <ctime>
#include <cstdio>
#include <cstdlib>

typedef long long ll;
int T;
ll n, ans;

inline ll mult(const ll &a, const ll &b, const ll &m) {
    return (__int128) a * b % m;
}

inline ll func(const ll &x, const ll &n) {
    return x < n ? x : x - n;
}

ll qpow(ll a, ll b, ll m) {
    ll c = 1;
    for (; b; b >>= 1, a = mult(a, a, m)) {
        if (b & 1) c = mult(a, c, m);
    }
    return c;
}

bool miller(ll m, ll d, ll r, ll n) {
    if (m > n - 2) return true;
    ll x = qpow(m, d, n);
    if (x == 1 || x == n - 1) return true;
    for (int i = 0; i < r; i++) {
        x = mult(x, x, n);
        if (x == n - 1) return true;
    }
    return false;
}

bool is_prime(ll n) {
    if (n <= 2) return n == 2;
    static ll m[] = { 2, 325, 9375, 28178, 450775, 9780504, 1795265022 };
    ll d = n - 1, r = 0;
    while (~d & 1) d /= 2, r++;
    for (int i = 0; i < 7; i++) {
        if (!miller(m[i], d, r, n)) return false;
    }
    return true;
}

ll randl() {
    return rand() | ((ll) rand() << 31);
}

ll gcd(ll a, ll b) {
    return b ? gcd(b, a % b) : a;
}

ll absl(ll x) {
    return x < 0 ? -x : x;
}

ll factor(ll n) {
    ll c = randl() % (n - 1) + 1, x = 0, y = 0, d = 1;
    for (ll k = 2, t = 1; ; k *= 2, y = x, t = 1) {
        for (ll i = 1; i <= k; i++) {
            x = func(mult(x, x, n) + c, n), t = mult(t, absl(x - y), n);
            if (!(i & 127) && (d = gcd(t, n)) > 1) break;
        }
        if (d > 1 || (d = gcd(t, n)) > 1) break;
    }
    return d;
}

void solve(ll n) {
    if (n == 1 || n <= ans) return;
    if (is_prime(n)) {
        ans = n;
        return;
    }
    ll x = factor(n);
    while (x == n) x = factor(n);
    while (n % x == 0) n /= x;
    solve(x), solve(n);
}

int main() {
    scanf("%d", &T);
    srand(time(0) ^ T);
    while (T--) {
        scanf("%lld", &n);
        ans = 0;
        solve(n);
        if (ans == n) {
            puts("Prime");
        } else {
            printf("%lld\n", ans);
        }
    }
    return 0;
}
```