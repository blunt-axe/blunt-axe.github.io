---
title: 「十二省联考 2019」异或粽子（字典树）
date: 2019-06-24 00:00:02
mathjax: true
tags:
	- 字典树

---

# 题目大意
[「十二省联考 2019」异或粽子（Luogu 5283）](https://www.luogu.org/problemnew/show/P5283)

给定一个长度为 $n$ 的数列 $a_1, a_2, \cdots, a_n$，问区间异或和前 $k$ 大的区间的异或和之和。

数据范围：$n \le 5 \times 10^5, m \le 2 \times 10^5, 0 \le a_i < 2^{32}$。

<!--more-->

# 思路分析
我们设 $S_i$ 表示前 $i$ 个数的异或和，那么区间 $[l, r]$ 的异或和等于 $S_{l - 1} \bigoplus S_{r}$。由于 $x \bigoplus y = y \bigoplus x$，本题的答案等于取 $2k$ 个 $S_i \bigoplus S_j$ 最大的 $(i, j) (0 \le i, j \le n, i \neq j)$ 求和再除以 $2$。又由于 $x \bigoplus x = 0$，所以 $i \neq j$ 的限制也可以去掉。这样，我们使用字典树 + 堆来维护即可。时间复杂度 $O((n + m) \log n)$。

# 代码实现
```cpp
#include <cstdio>
#include <cstring>
#include <queue>
using namespace std;
typedef long long ll;
typedef pair<ll, int> P;

const int maxn = 5e5, maxm = 32, maxk = maxn * maxm;
int n, k, tot, ch[maxk + 3][2], sz[maxk + 3], cnt[maxn + 3];
ll a[maxn + 3];
priority_queue<P> H;

void insert(ll num) {
	int x = 1;
	for (int i = maxm - 1; ~i; i--) {
		int k = num >> i & 1;
		if (!ch[x][k]) {
			ch[x][k] = ++tot;
		}
		x = ch[x][k], sz[x]++;
	}
}

ll query(int y, ll num) {
	int x = 1;
	ll ans = 0;
	for (int i = maxm - 1; ~i; i--) {
		int k = num >> i & 1;
		if (y <= sz[ch[x][k ^ 1]]) {
			ans |= 1ll << i;
			x = ch[x][k ^ 1];
		} else {
			y -= sz[ch[x][k ^ 1]];
			x = ch[x][k];
		}
	}
	return ans;
}

int main() {
	scanf("%d %d", &n, &k), k *= 2;
	for (int i = 1; i <= n; i++) {
		scanf("%lld", &a[i]), a[i] ^= a[i - 1];
	}
	tot = 1;
	for (int i = 0; i <= n; i++) {
		insert(a[i]);
	}
	for (int i = 0; i <= n; i++) {
		cnt[i] = 1;
		H.push(P(query(1, a[i]), i));
	}
	ll ans = 0;
	for (int i; k--; ) {
		P x = H.top();
		H.pop(), i = x.second;
		ans += x.first, cnt[i]++;
		if (cnt[i] <= n + 1) {
			H.push(P(query(cnt[i], a[i]), i));
		}
	}
	printf("%lld\n", ans / 2);
	return 0;
}
```