---
title: 「GXOI / GZOI 2019」特技飞行（扫描线）
mathjax: true
date: 2019-05-20 00:00:00
tags:
	- 扫描线
---

# 题目大意

[「GXOI / GZOI 2019」特技飞行（Luogu 5302）](https://www.luogu.org/problemnew/show/P5302)

给定 $n$ 条线段，它们的起点和终点的 $x$ 坐标分别为 $Sx$ 和 $Tx$，$y$ 坐标在输入中给定。在两条线段 $l_1, l_2$ 交点，可以交换 $l_1, l_2$ 接下来的部分（变成两条折线）。交换或不交换分别可以获得固定的分数 $a$ 和 $b$。要求最后在 $x = Sx$ 处和 $x = Tx$ 处，折线保持相同的顺序。

另外有 $m$ 个观测点可以观测到一定范围内情况（曼哈顿距离），在观测范围内的点额外获得 $c$ 分。问如何交换可以获得最高的得分。保证交点小于等于 $k$ 个。

$n, m \le 10^5, k \le 5 \times 10^5$。

<!--more-->

# 思路分析

不难发现这是一道二合一的题目。

第一部分是安排交换方案。

交换数量最大的方案就是在所有交点处交换，这样一定是可行的。

交换数量最小的方案就是对于每个置换分别考虑。如果置换的大小为 $\text{Size}$，则需要交换 $\text{Size} - 1$ 次。

第二部分是对于每个交点计算是否被评委看到。

由于交点个数小，我们可以预处理出所有交点，然后将坐标系旋转 $45^{\circ}$ 进行二维数点即可。

# 代码实现

```cpp
#include <cstdio>
#include <set>
#include <vector>
#include <algorithm>
using namespace std;

typedef double db;

struct point {
	db x, y;
};

struct event {
	int type, x, y;
	friend bool operator< (const event &a, const event &b) {
		return a.x > b.x;
	}
};

struct ipoint {
	int x, y;
	friend bool operator< (const ipoint &a, const ipoint &b) {
		return a.x > b.x;
	}
};

const int maxn = 1e5, maxm = 2e5, maxk = 5e5;
const db eps = 1e-8;
int n, m, k, a, b, c, tot, Sx, Tx, C, A1, A2, A3;
int ord[maxn + 3], rnk[maxn + 3], r[maxn + 3], bit[maxk + 3];
bool vis[maxn + 3];
point p[maxm + 3], ip[maxk + 3], gst[maxn + 3];
event e[maxk + 3];
ipoint pnt[maxk + 3];
vector<db> Vx, Vy;
set<int> S;

void add(int x, int y) {
	for (int i = x; i; i ^= i & -i) {
		bit[i] += y;
	}
}

int sum(int x) {
	int y = 0;
	for (int i = x; i <= k; i += i & -i) {
		y += bit[i];
	}
	return y;
}

bool comp(int i, int j) {
	return p[n + i].y < p[n + j].y;
}

void get_point(point &pnt, db ly1, db ly2, db ry1, db ry2) {
	db num = -(ly1 - ly2) / (ry1 - ry2);
	pnt.x = (Sx + Tx * num) / (num + 1);
	pnt.y = (ly1 + ry1 * num) / (num + 1);
}

int main() {
	scanf("%d %d %d %d %d %d", &n, &a, &b, &c, &Sx, &Tx);
	for (int i = 1, y; i <= 2 * n; i++) {
		scanf("%d", &y), p[i].y = y;
		p[i].x = i <= n ? Sx : Tx;
	}
	for (int i = 1; i <= n; i++) {
		ord[i] = i;
	}
	sort(ord + 1, ord + n + 1, comp);
	for (int i = 1; i <= n; i++) if (!vis[i]) {
		int x = ord[i];
		while (x != i) {
			vis[x] = true, C++, x = ord[x];
		}
	}
	for (int i = 1; i <= n; i++) {
		rnk[ord[i]] = i;
	}
	S.insert(rnk[1]);
	for (int i = 2; i <= n; i++) {
		set<int>::iterator it = S.end();
		while (true) {
			it--;
			if (*it > rnk[i]) {
				int x = ord[*it];
				get_point(ip[++k], p[i].y, p[x].y, p[n + i].y, p[n + x].y);
			}
			if (*it < rnk[i] || it == S.begin()) {
				break;
			}
		}
		S.insert(rnk[i]);
	}
	A1 = a * k;
	A2 = a * C + b * (k - C);
	scanf("%d", &m);
	for (int i = 1, x, y; i <= m; i++) {
		scanf("%d %d %d", &x, &y, &r[i]);
		gst[i].x = x + y, gst[i].y = x - y;
	}
	for (int i = 1; i <= k; i++) {
		db a = ip[i].x, b = ip[i].y;
		ip[i].x = a + b, ip[i].y = a - b;
		Vx.push_back(ip[i].x), Vy.push_back(ip[i].y);
	}
	sort(Vx.begin(), Vx.end());
	sort(Vy.begin(), Vy.end());
	for (int i = 1; i <= k; i++) {
		pnt[i].x = lower_bound(Vx.begin(), Vx.end(), ip[i].x - .01) - Vx.begin() + 1;
		pnt[i].y = lower_bound(Vy.begin(), Vy.end(), ip[i].y - .01) - Vy.begin() + 1;
	}
	for (int i = 1; i <= m; i++) {
		db lx = gst[i].x - r[i] - eps, rx = gst[i].x + r[i] + eps;
		db ly = gst[i].y - r[i] - eps, ry = gst[i].y + r[i] + eps;
		int Lx = lower_bound(Vx.begin(), Vx.end(), lx) - Vx.begin() + 1 - 1;
		int Rx = upper_bound(Vx.begin(), Vx.end(), rx) - Vx.begin();
		int Ly = lower_bound(Vy.begin(), Vy.end(), ly) - Vy.begin() + 1 - 1;
		int Ry = upper_bound(Vy.begin(), Vy.end(), ry) - Vy.begin();
		e[++tot].type = 1, e[tot].x = Lx, e[tot].y = Ly;
		e[++tot].type = -1, e[tot].x = Lx, e[tot].y = Ry;
		e[++tot].type = -1, e[tot].x = Rx, e[tot].y = Ly;
		e[++tot].type = 1, e[tot].x = Rx, e[tot].y = Ry;
	}
	sort(pnt + 1, pnt + k + 1);
	sort(e + 1, e + tot + 1);
	int cur = 1;
	for (int i = 1; i <= k; i++) {
		while (cur <= tot && e[cur].x >= pnt[i].x) {
			add(e[cur].y, e[cur].type);
			cur++;
		}
		if (sum(pnt[i].y)) {
			A3++;
		}
	}
	A3 *= c;
	if (A1 > A2) {
		swap(A1, A2);
	}
	printf("%d %d\n", A1 + A3, A2 + A3);
	return 0;
}
```