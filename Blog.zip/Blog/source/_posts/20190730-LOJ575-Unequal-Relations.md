---
title: 「LOJ 575」不等关系（容斥原理 + 多项式）
date: 2019-07-30 00:00:02
mathjax: true
tags:
	- 容斥原理
	- 多项式

---

# 题目大意
[「LOJ 575」不等关系](https://loj.ac/problem/575)

给定一个长度为 $n$ 的字符串 $s$，$s_i \in \{<, >\}$。要求计数长度为 $n + 1$ 的排列 $a$，满足 $a_i < a_{i + 1}$ 当且仅当 $s_i$ 为 $<$，模数为 $998244353$。

数据范围：$n \le 10^5$。

<!--more-->

# 思路分析
首先想到一个状态数为 $n^2$ 的 $\text{dp}$，但是发现它不能优化。于是考虑容斥。

对于所有 $<$，我们考虑把它容斥成 $\neq$ 的方案数减去 $>$ 的方案数。这样容斥后，问题就变成了字符串的每一位都是无限制或大于号，求方案数。假设第 $i$ 个大于号的连续段长度为 $\text{len}_i - 1$，则总方案数为 $\displaystyle \frac{n!}{\prod \text{len}_i!}$。这样，我们就得到了一个 $O(2^n)$ 的做法。

![图一](/images/20190730-LOJ575-Unequal-Relations-1.jpg)

我们发现我们可以使用带容斥系数的 $\text{dp}$ 来解决这个问题。那么：

$$
dp_{n} = 
\begin {cases}
1 & (n = 0)\\
\displaystyle \sum_{i = 0}^{n - 1} [i = 0 \text{ or } s_i = \text{<}] \cdot dp_{i} \cdot \frac{(-1) ^ {\text{cnt}_{n - 1} - \text{cnt}_i}}{(n - i)!} & (n \ge 1)
\end {cases}
$$

其中 $\text{cnt}_i$ 表示前 $i$ 个位置有多少个 $\text{<}$，而答案就等于 $dp_{n + 1} \times (n + 1)!$。这样做的时间复杂度为 $O(n^2)$。

发现这个式子可以使用分治 FFT 优化。时间复杂度 $O(n \log^2 n)$，可以通过本题。

# 代码实现
```cpp
#include <bits/stdc++.h>
#define mid ((l + r) >> 1)
using namespace std;

const int maxn = 1 << 18, mod = 998244353;
int n, m, k, cnt[maxn + 3], fact[maxn + 3], finv[maxn + 3], num[maxn + 3];
int f[maxn + 3], g[maxn + 3], a[maxn + 3], b[maxn + 3], rev[maxn + 3], dp[maxn + 3];
char s[maxn + 3];

void add(int &x, int y) {
	x += y, x < mod ? 0 : x -= mod;
}

int qpow(int a, int b) {
	b < 0 ? b += mod - 1 : 0;
	int c = 1;
	for (; b; b >>= 1, a = 1ll * a * a % mod) {
		if (b & 1) c = 1ll * a * c % mod;
	}
	return c;
}

void prework(int n) {
	for (int i = 1; i <= n; i++) {
		cnt[i] = cnt[i - 1] + (s[i] == '<');
	}
	fact[0] = finv[0] = 1;
	for (int i = 1; i <= n; i++) {
		fact[i] = 1ll * fact[i - 1] * i % mod;
	}
	finv[n] = qpow(fact[n], mod - 2);
	for (int i = n; i; i--) {
		finv[i - 1] = 1ll * finv[i] * i % mod;
	}
	num[0] = 1;
	for (int i = 1; i <= n; i++) {
		num[i] = mod - num[i - 1];
	}
}

void dft(int a[], int n, int type) {
	for (int i = 0; i < n; i++) {
		if (i < rev[i]) swap(a[i], a[rev[i]]);
	}
	for (int k = 1; k < n; k <<= 1) {
		int x = qpow(3, (mod - 1) / (k << 1) * type);
		for (int i = 0; i < n; i += k << 1) {
			int y = 1;
			for (int j = i; j < i + k; j++, y = 1ll * x * y % mod) {
				int p = a[j], q = 1ll * y * a[j + k] % mod;
				a[j] = p + q, a[j] < mod ? 0 : a[j] -= mod;
				a[j + k] = p - q, a[j + k] < 0 ? a[j + k] += mod : 0;
			}
		}
	}
	if (type == -1) {
		int x = qpow(n, mod - 2);
		for (int i = 0; i < n; i++) {
			a[i] = 1ll * a[i] * x % mod;
		}
	}
}

void cdq(int l, int r) {
	if (l == r) {
		if (!l) f[l] = 1;
		f[l] = 1ll * f[l] * num[cnt[l - 1]] % mod;
		dp[l] = f[l];
		f[l] = 1ll * f[l] * num[cnt[l]] % mod * (!l || s[l] == '<');
		return;
	}
	cdq(l, mid);
	for (int i = l; i <= mid; i++) {
		a[i - l] = f[i];
	}
	for (int i = 0; i <= r - l; i++) {
		b[i] = g[i]; 
	}
	int x = mid - l, y = r - l;
	for (k = 0, m = 1; m <= x + y; m <<= 1) k++;
	for (int i = x + 1; i < m; i++) {
		a[i] = 0;
	}
	for (int i = y + 1; i < m; i++) {
		b[i] = 0;
	}
	for (int i = 1; i < m; i++) {
		rev[i] = (rev[i >> 1] >> 1) | ((i & 1) << (k - 1));
	}
	dft(a, m, 1), dft(b, m, 1);
	for (int i = 0; i < m; i++) {
		a[i] = 1ll * a[i] * b[i] % mod; 
	}
	dft(a, m, -1);
	for (int i = mid + 1; i <= r; i++) {
		add(f[i], a[i - l]);
	}
	cdq(mid + 1, r);
}

int main() {
	scanf("%s", s + 1);
	n = strlen(s + 1) + 1;
	prework(n);
	for (int i = 1; i <= n; i++) {
		g[i] = finv[i];
	}
	cdq(0, n);
	int ans = 1ll * dp[n] * fact[n] % mod;
	printf("%d\n", ans);
	return 0;
}
```