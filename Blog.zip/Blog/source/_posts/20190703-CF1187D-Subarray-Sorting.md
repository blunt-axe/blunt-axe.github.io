---
title: 「Codeforces 1187D」Subarray Sorting（排序）
date: 2019-07-03 00:00:00
mathjax: true
tags:
	- 排序

---

# 题目大意
[「Codeforces 1187D」Subarray Sorting](https://codeforc.es/contest/1187/problem/D)

给定长度为 $n$ 的两个数列 	$A, B$，问是否可以做若干次「将 $A$ 的某个区间升序排序」把 $A$ 变为 $B$。

数据范围：$n \le 3 \times 10^5$。

<!--more-->

# 思路分析
发现自己最近连水题都不会做了 QAQ。

首先把「将 $A$ 的某个区间升序排序」这种操作替换成「将 $A$ 的某两个相邻的数升序排序」这种操作以方便思考。转化后的题目其实本质没有变化，因为我们可以用冒泡排序的方式实现「将一个区间排序」。

然后逐位考虑，假设现在考虑到 $A_i$，前 $i - 1$ 位已经排好了。那么我们如果要让操作过后的 $A_i$ 要和 $B_i$ 相等，就必须从 $A$ 的后面把一个等于 $B_i$ 的数调动到第 $i$ 位。我们找到数列 $A$ 从 $i$ 开始的第一个 $A_j = B_i$，考虑调动 $A_j$。不难发现这个数能被成功调动当且仅当所有 $A_k (i \le k < j)$ 都小于它自己。于是我们暴力地模拟这个过程即可得到一个 $O(n^2)$ 的算法。

可惜这并不能通过本题，考虑使用数据结构优化。我们可以直接使用平衡树维护这个过程，但我们还有更简单的方法。发现我们只需要用到一个数列没被调动过的数的前缀最大值。于是我们每次调动完一个数后，我们将它赋值为 $-1$，这样，它就不会被算进最大值中了。对于还可使用的数，我们使用线段树维护区间最大值即可。如何实现寻找 $A$ 中可使用的第一个 $A_j = B_i$ 呢？我们开 $n$ 个队列，第 $i$ 个存储 $A$ 中数值为 $i$ 的数的出现位置；每次找数时，我们只需取出队首即可。总时间复杂度 $O(n \log n)$。

# 代码实现
```cpp
#include <cstdio>
#include <queue>
#include <algorithm>
#define ls (x << 1)
#define rs (ls | 1)
#define mid ((l + r) / 2)
using namespace std;

const int maxn = 3e5, maxm = maxn * 4;
int T, n, a[maxn + 3], b[maxn + 3], mx[maxm + 3];
queue<int> app[maxn + 3];

void maintain(int x) {
	mx[x] = max(mx[ls], mx[rs]);
}

void modify(int x, int l, int r, int y, int z) {
	if (l == r) {
		mx[x] = z;
		return;
	}
	if (y <= mid) {
		modify(ls, l, mid, y, z);
	} else {
		modify(rs, mid + 1, r, y, z);
	}
	maintain(x);
}

int query(int x, int l, int r, int lx, int rx) {
	if (lx > rx) {
		return 0;
	}
	if (l >= lx && r <= rx) {
		return mx[x];
	}
	int res = 0;
	if (lx <= mid) {
		res = max(res, query(ls, l, mid, lx, rx));
	}
	if (rx > mid) {
		res = max(res, query(rs, mid + 1, r, lx, rx));
	}
	return res;
}

int main() {
	scanf("%d", &T);
	while (T--) {
		for (int i = 1; i <= n; i++) {
			queue<int> t;
			swap(t, app[i]);
		}
		for (int i = 1; i <= n * 4; i++) {
			mx[i] = 0;
		}
		scanf("%d", &n);
		for (int i = 1; i <= n; i++) {
			scanf("%d", &a[i]);
			a[i] = n - a[i] + 1;
			app[a[i]].push(i);
			modify(1, 1, n, i, a[i]);
		}
		for (int i = 1; i <= n; i++) {
			scanf("%d", &b[i]);
			b[i] = n - b[i] + 1;
		}
		bool flag = true;
		for (int i = 1; i <= n; i++) {
			if (app[b[i]].empty()) {
				flag = false;
				break;
			}
			int x = app[b[i]].front();
			app[b[i]].pop();
			if (query(1, 1, n, 1, x - 1) > a[x]) {
				flag = false;
				break;
			}
			modify(1, 1, n, x, 0);
		}
		puts(flag ? "YES" : "NO");
	}
	return 0;
}
```