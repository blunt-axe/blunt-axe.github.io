---
title: 「专题选做」简单计数题选做 1
date: 2019-12-03 00:00:00
mathjax: true
tags:
	- 专题选做
	- 组合计数
	- 并查集
	- 容斥原理
	- 动态规划
---

# SetAndSet

[「Topcoder 12004」SetAndSet](https://vjudge.net/problem/TopCoder-12004)

## 题目描述

给 $n$ 个数 $a_1, a_2, \cdots, a_n$，要把它们划分成两个集合，使得两边的 And 一样，问方案数。

数据范围：$n \le 50, 0 \le a_i < 2^{20}$。

<!--more-->

## 思路分析

也就是说对于每一位，如果存在一个数这一位为 $0$，那么这一位为 $0$ 的数不能全在同一边。考虑容斥，每次强制某些位让这一位为 $0$ 的数全在同一边。使用并查集维护即可，直接实现时间复杂度 $O(2^{20} \times 20n)$，容斥用 dfs 实现复杂度为 $O(2^{20} n)$，可以通过（忽略并查集复杂度）。

## 代码实现

```cpp
#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn = 50, maxm = 20;

class SetAndSet {
public:
	int n, a[maxn + 3], fa[maxm + 3][maxn + 3];
	vector<int> S[maxm + 3];
	bool vis[maxn + 3];
	ll ans;

	int find(int i, int x) {
		return fa[i][x] == x ? x : fa[i][x] = find(i, fa[i][x]);
	}

	void dfs(int i, int x) {
		if (i == maxm) {
			for (int j = 1; j <= n; j++) {
				vis[j] = false;
			}
			for (int j = 1; j <= n; j++) {
				vis[find(i, j)] = true;
			}
			ll y = 1;
			for (int j = 1; j <= n; j++) {
				if (vis[j]) y <<= 1;
			}
			ans += x * (y - 2);
			return;
		}
		memcpy(fa[i + 1], fa[i], sizeof(fa[i]));
		dfs(i + 1, x);
		if (!S[i].empty()) {
			memcpy(fa[i + 1], fa[i], sizeof(fa[i]));
			for (int j = 0; j < S[i].size() - 1; j++) {
				fa[i + 1][find(i + 1, S[i][j])] = find(i + 1, S[i][j + 1]);
			}
			dfs(i + 1, -x);
		}
	}

	ll countandset(vector<int> A) {
		n = A.size();
		for (int i = 1; i <= n; i++) {
			a[i] = A[i - 1];
			for (int j = 0; j < maxm; j++) {
				if (~a[i] >> j & 1) {
					S[j].push_back(i);
				}
			}
		}
		for (int i = 1; i <= n; i++) {
			fa[0][i] = i;
		}
		ans = 0;
		dfs(0, 1);
		return ans;
	}
};
```

# Endless Spin

[「HDU 4624」Endless Spin](http://acm.hdu.edu.cn/showproblem.php?pid=4624)

## 题目描述

有 $n$ 个格子，每次随机选择一个区间染黑，问全染黑的期望时间。答案保留 $15$ 位小数。

数据范围：$T, n \le 50$。

## 思路分析

我们要求的是 $\max(T_1, T_2, \cdots, T_n)$，其中 $T_i$ 表示第 $i$ 个格子被覆盖的时间。考虑 Min-Max 容斥，计算 $\sum_{S \in [n]} (-1)^{\vert S \vert - 1} \min_{i \in S}(T_i)$。对于某个 $S$，我们要算出经过 $S$ 种某个点的区间个数 $x$，设总区间个数为 $y$，那么它对答案的贡献是容斥系数乘上 $\frac{y}{x}$。带上容斥系数套个 dp 即可，由于精度要求较高可以使用高精度 / int128，时间复杂度 $O(n^4)$。

## 代码实现

```cpp
#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef __int128 lll;
typedef double db;
const int maxn = 50, maxm = maxn * (maxn + 1) >> 1;
const ll inf = 1e18;
ll dp[maxn + 3][maxm + 3], f[maxn + 3][maxm + 3];
lll ans[maxn + 3];
int T;

inline int func(const int &x) {
	return x * (x + 1) >> 1;
}

int main() {
	for (int i = 1; i <= maxn; i++) {
		dp[i][func(i - 1)] = 1;
		for (int j = 1; j < i; j++) {
			for (int k = 0; k <= func(j - 1); k++) {
				dp[i][func(i - j - 1) + k] -= dp[j][k];
			}
		}
	}
	for (int i = 1; i <= maxn; i++) {
		for (int j = 1; j <= i; j++) {
			for (int k = 0; k <= func(j - 1); k++) {
				f[i][func(i - j) + k] += dp[j][k];
			}
		}
	}
	for (int i = 1; i <= maxn; i++) {
		for (int j = 0; j <= func(i - 1); j++) {
			ans[i] += (lll) f[i][j] * func(i) * inf / (func(i) - j);
		}
	}
	scanf("%d", &T);
	for (int n; T --> 0; ) {
		scanf("%d", &n);
		printf("%d.%015lld\n", (int) (ans[n] / inf), ((ll) (ans[n] % inf) + 500) / 1000);
	}
	return 0;
}
```

# 随机立方体

[「CTS 2019」随机立方体（Luogu 5400）](https://www.luogu.com.cn/problem/P5400)

## 题目描述

有 $n \times m \times l$ 的立方体，每个位置有 $[0, 1]$ 范围内随机的实数，一个数是极大的当且仅当它大于任何一个与它某一维坐标相同的数。问恰好有 $k$ 个极大的数的概率。

数据范围：$T \le 10, n, m, l \le 5 \times 10^6, k \le 100$。

## 思路分析

记 $N = \min(n, m, l)$，以及钦定 $i$ 个数极大，其他随便选的概率的和为 $A_i$，那么根据二项式反演，答案等于：
$$
\text{Ans} = \sum_{i = k}^{N} \binom{i}{k} A_i (-1)^{i - k}
$$
我们考虑 $A_i$ 怎么求。首先从小到大钦定 $i$ 个数，之后我们会得到一棵表示大小关系的树：

![](/images/20191203-Easy-Counting-1-1.png)

上图是二维时 $n = 4, m = 3, i = 2$ 的情况，两个极大值分别是 $(1, 1)$ 和 $(2, 2)$，一个格子指向另一个格子表示一个格子大于另一个格子。根据经典结论，概率应该是子树大小的倒数相乘，所以最终的式子是：
$$
\begin {align*}
& A_i = n^{\underline i} m^{\underline i} l^{\underline i} \prod_{j = 1}^{i} \frac{1}{nml - (n - j)(m - j)(l - j)} \\
& \text{Ans} = \sum_{i = k}^{N} \binom{i}{k} A_i (-1)^{i - k} \\
= & \sum_{i = k}^{N} \binom{i}{k} (-1)^{i - k} n^{\underline i} m^{\underline i} l^{\underline i} \prod_{j = 1}^{i} \frac{1}{nml - (n - j)(m - j)(l - j)}
\end {align*}
$$
直接计算即可，注意要用到线性求逆元，时间复杂度 $O(Tn)$。

## 代码实现

```cpp
#include <bits/stdc++.h>
using namespace std;

const int maxn = 5e6, mod = 998244353;
int T, n, m, l, k, N, fact[maxn + 3], finv[maxn + 3], a[maxn + 3];

int qpow(int a, int b) {
	int c = 1;
	for (; b; b >>= 1, a = 1ll * a * a % mod) {
		if (b & 1) c = 1ll * a * c % mod;
	}
	return c;
}

void prework(int n) {
	fact[0] = 1;
	for (int i = 1; i <= n; i++) {
		fact[i] = 1ll * fact[i - 1] * i % mod;
	}
	finv[n] = qpow(fact[n], mod - 2);
	for (int i = n; i; i--) {
		finv[i - 1] = 1ll * finv[i] * i % mod;
	}
}

int C(int n, int m) {
	return 1ll * fact[n] * finv[m] % mod * finv[n - m] % mod;
}

void solve(int a[], int n) {
	int prod = 1;
	for (int i = 1; i <= n; i++) {
		prod = 1ll * prod * a[i] % mod;
	}
	int inv = qpow(prod, mod - 2);
	for (int i = n, x; i; i--) {
		x = a[i], a[i] = inv;
		inv = 1ll * inv * x % mod;
	}
}

int main() {
	prework(maxn);
	scanf("%d", &T);
	while (T --> 0) {
		scanf("%d %d %d %d", &n, &m, &l, &k);
		N = min(n, min(m, l));
		for (int i = 1; i <= N; i++) {
			a[i] = (1ll * n * m % mod * l - 1ll * (n - i) * (m - i) % mod * (l - i)) % mod;
			a[i] < 0 ? a[i] += mod : 0;
		}
		solve(a, N);
		int cur = 1;
		for (int i = 1; i < k; i++) {
			cur = 1ll * cur * (n - i + 1) % mod * (m - i + 1) % mod * (l - i + 1) % mod;
		}
		int ans = 0;
		for (int i = k; i <= N; i++) {
			cur = 1ll * cur * (n - i + 1) % mod * (m - i + 1) % mod * (l - i + 1) % mod;
			ans = (ans + 1ll * C(i, k) * ((i - k) & 1 ? -1 : 1) * cur % mod * a[i]) % mod;
		}
		ans < 0 ? ans += mod : 0;
		printf("%d\n", ans);
	}
	return 0;
}
```

# Square Constraints

[「AGC 036F」Square Constraints](https://agc036.contest.atcoder.jp/tasks/agc036_f)

## 题目描述

求有多少个 $0, 1, \cdots, 2n - 1$ 的排列 $p$，满足 $n^2 \le i^2 + p_i^2 \le 4n^2$。

数据范围：$n \le 250$。

## 思路分析

考虑子问题：长度为 $0, 2, \cdots, m - 1$ 的排列 $p$ 有多少个满足 $p_i < a_i$。考虑先把 $a_i$ 从小到大排序，根据乘法原理，方案数就是 $\prod_{i = 0}^{m - 1} (a_i - i)$。

注意到这个做法是基于 $a_i$ 的大小排名的。考虑原题，发现限制的形状如下：

![](/images/20191203-Easy-Counting-1-2.png)

阴影部分是 $(i, p_i)$ 可以选的地方，空白部分是不能选的地方。我们考虑容斥，把前 $n$ 个限制拆成 $[p_i \le r_i] - [p_i \le l_i - 1]$。考虑把所有限制分成三类：A 类，B 类和 C 类。我们把所有限制按照高度从小到大排序，得到的序列一定长成这样：$\text{ACACAACACCBBBBB}$。在序列中，我们要选择所有的 C，以及第 $i$ 个 A 和第 $i$ 个 B 中的一个。额外地，每选到一个 A 后，系数就要乘上 $-1$。

考虑 dp 前 $2n$ 个字符，$f(i, j)$ 表示考虑前 $i$ 个字符，A 选了 $j$ 个的方案数。对于一个 A / C，我们容易计算它的排名，但是对于一个 A 对应的 B，我们就不能得到它的排名了。于是，我们考虑事先枚举要用 $k$ 个 A，然后再 dp，这样就可以得到 B 的排名。这样我们就得到了一个时间复杂度为 $O(n^3)$ 的做法。

## 代码实现

```cpp
#include <bits/stdc++.h>
#define fi first
#define se second
using namespace std;

const int maxn = 500;
int n, mod, L[maxn + 3], R[maxn + 3], dp[maxn + 3][maxn + 3];
pair<int, int> a[maxn + 3];

int get(int x, int y) {
	int z = 0;
	while (z < n * 2 - 1 && (z + 1) * (z + 1) + x <= y) {
		z++;
	}
	return z;
}

int solve(int k) {
	memset(dp, 0, sizeof(dp));
	dp[0][0] = 1;
	int A = 0, C = 0;
	for (int i = 0; i < n * 2; i++) {
		if (~a[i].se) {
			for (int j = 0; j <= A; j++) {
				dp[i + 1][j + 1] = (dp[i + 1][j + 1] + 1ll * dp[i][j] * (a[i].fi - j - C)) % mod;
			}
			for (int j = 0; j <= A; j++) {
				dp[i + 1][j] = (dp[i + 1][j] + 1ll * dp[i][j] * (a[i].se - k - n - (A - j))) % mod;
			}
			A++;
		} else {
			for (int j = 0; j <= A; j++) {
				dp[i + 1][j] = (dp[i + 1][j] + 1ll * dp[i][j] * (a[i].fi - j - C)) % mod;
			}
			C++;
		}
	}
	return dp[n * 2][k];
}

int main() {
	scanf("%d %d", &n, &mod);
	for (int i = 0; i < n; i++) {
		a[i] = make_pair(get(i * i, n * n - 1) + 1, get(i * i, n * n * 4) + 1);
	}
	for (int i = n; i < n * 2; i++) {
		a[i] = make_pair(get(i * i, n * n * 4) + 1, -1);
	}
	sort(a, a + n * 2);
	int ans = 0;
	for (int i = 0; i <= n; i++) {
		ans = (ans + 1ll * (i & 1 ? mod - 1 : 1) * solve(i)) % mod;
	}
	printf("%d\n", ans);
	return 0;
}
```

# HamiltonianPaths

[「Topcoder 14250」HamiltonianPaths](https://vjudge.net/problem/TopCoder-14250)

## 题目描述

给定一个 $n$ 个点的图，把它复制 $k$ 边，然后取补图，问新图的哈密尔顿路径条数，对 $998244353$ 取模。

数据范围：$n \le 14, k \le 5 \times 10^4$。

## 思路分析

也就是说限制整个完全图中不能经过 $km$ 条边。考虑容斥，枚举必须经过 $c$ 条边，那么对答案的贡献就是 $(-1)^c$ 乘上方案数。假设一个子图里经过了 $d$ 条不合法边，组成了 $e$ 条有向的链，那么将链定向后，对答案的贡献就是 $(-1)^d$，也就是说权值为 $(-1)^d$。最后如果缩点后还剩 $f$ 个点，方案数就是 $f!$。所以要算出每个图缩成 $g$ 个点的权值和，然后用 fft 求出大图缩成 $f$ 个点的权值和。一个子图的权值和可以通过简单状压 dp 实现，总时间复杂度 $O(2^n n^2 + 3^n n + kn \log kn)$。

## 代码实现

```cpp
#include <bits/stdc++.h>
using namespace std;

const int maxn = 14, maxk = 1 << maxn, maxm = 1 << 20, mod = 998244353;

class HamiltonianPaths {
public:
	bool a[maxn + 3][maxn + 3];
	int n, k, dp[maxk + 3][maxn + 3], cnt[maxk + 3], f[maxk + 3][maxn + 3];
	int g[maxm + 3], h[maxm + 3], g_n, h_n, lim, bit, rev[maxm + 3], A[maxm + 3], B[maxm + 3];

	inline int func(const int &x) {
		return x < mod ? x : x - mod;
	}

	int qpow(int a, int b) {
		b < 0 ? b += mod - 1 : 0;
		int c = 1;
		for (; b; b >>= 1, a = 1ll * a * a % mod) {
			if (b & 1) c = 1ll * a * c % mod;
		}
		return c;
	}

	void dft(int a[], int n, int type) {
		for (int i = 0; i < n; i++) {
			if (i < rev[i]) swap(a[i], a[rev[i]]);
		}
		for (int k = 1; k < n; k <<= 1) {
			int x = qpow(3, (mod - 1) / (k << 1) * type);
			for (int i = 0; i < n; i += k << 1) {
				int y = 1;
				for (int j = i; j < i + k; j++, y = 1ll * x * y % mod) {
					int p = a[j], q = 1ll * a[j + k] * y % mod;
					a[j] = func(p + q), a[j + k] = func(p - q + mod);
				}
			}
		}
		if (type == -1) {
			int x = qpow(n, mod - 2);
			for (int i = 0; i < n; i++) {
				a[i] = 1ll * a[i] * x % mod;
			}
		}
	}

	void mult(int a[], int &n, int b[], int m) {
		for (lim = 1, bit = 0; lim <= n + m; lim <<= 1) bit++;
		for (int i = 1; i < lim; i++) {
			rev[i] = (rev[i >> 1] >> 1) | ((i & 1) << (bit - 1));
		}
		for (int i = 0; i <= n; i++) {
			A[i] = a[i];
		}
		for (int i = 0; i <= m; i++) {
			B[i] = b[i];
		}
		fill(A + n + 1, A + lim, 0);
		fill(B + m + 1, B + lim, 0);
		dft(A, lim, 1), dft(B, lim, 1);
		for (int i = 0; i < lim; i++) {
			A[i] = 1ll * A[i] * B[i] % mod;
		}
		dft(A, lim, -1);
		n += m;
		for (int i = 0; i <= n; i++) {
			a[i] = A[i];
		}
	}

	int countPaths(int N, vector<int> A, vector<int> B, int K) {
		n = N, k = K;
		for (int i = 0; i < A.size(); i++) {
			a[A[i] + 1][B[i] + 1] = true;
			a[B[i] + 1][A[i] + 1] = true;
		}
		for (int i = 1; i <= n; i++) {
			dp[1 << (i - 1)][i] = 1;
		}
		for (int msk = 1; msk < 1 << n; msk++) {
			for (int i = 1; i <= n; i++) if (dp[msk][i]) {
				for (int j = 1; j <= n; j++) if (a[i][j] && (~msk >> (j - 1) & 1)) {
					dp[msk | (1 << (j - 1))][j] = func(dp[msk | (1 << (j - 1))][j] - dp[msk][i] + mod);
				}
			}
			for (int i = 1; i <= n; i++) if (dp[msk][i]) {
				cnt[msk] = func(cnt[msk] + dp[msk][i]);
			}
		}
		f[0][0] = 1;
		for (int msk = 1; msk < 1 << n; msk++) {
			int p = 0;
			for (int i = 1; i <= n; i++) {
				if (msk >> (i - 1) & 1) {
					p = i;
					break;
				}
			}
			int t = msk ^ (1 << (p - 1));
			for (int k = 0; k < n; k++) {
				f[msk][k + 1] = f[t][k];
			}
			for (int i = t; i; i = (i - 1) & t) {
				for (int k = 0; k < n; k++) {
					f[msk][k + 1] = (f[msk][k + 1] + 1ll * cnt[i | (1 << (p - 1))] * f[msk ^ (i | 1 << (p - 1))][k]) % mod;
				}
			}
		}
		for (int i = 1; i <= n; i++) {
			g[i] = f[(1 << n) - 1][i];
		}
		h[0] = 1;
		int g_n = n, h_n = 0;
		for (int i = k; i; i >>= 1, mult(g, g_n, g, g_n)) {
			if (i & 1) mult(h, h_n, g, g_n);
		}
		int cur = 1, ret = 0;
		for (int i = 1; i <= n * k; i++) {
			cur = 1ll * cur * i % mod;
			ret = (ret + 1ll * h[i] * cur) % mod;
		}
		return ret;
	}
};
```

# Fireflies

[「HDU 6355」Fireflies](http://acm.hdu.edu.cn/showproblem.php?pid=6355)

## 题目描述

给定 $n$ 个数 $p_1, p_2, \cdots, p_n$，令 $M = \lfloor \frac{\sum_{i = 1}^{n} (p_i + 1)}{2} \rfloor$，问有多少 $n$ 元组 $(x_1, x_2, \cdots, x_n)$ 满足：

+ $1 \le x_i \le p_i$
+ $\sum_{i = 1}^{n} x_i = M$

数据范围：$T \le 2000, n \le 32$，至多两组数据满足 $n > 24$。

## 思路分析

注意：此题中的 $\binom{n}{m}$ 定义为 $\frac{n^{\underline{m}}}{m!}$，所以 $n < 0$ 时的组合数也可以计算。

考虑容斥，$1 \le x_i \le p_i$ 的方案数为 $[x_i > 0] - [x_i > p_i]$。考虑将强制大于 $p_i$ 的数减去 $p_i$，然后使用插板法，问题就转化成了计算：

$$\sum_{S \in [n]} (-1)^{\vert S \vert} \binom{M - 1 - \sum_{i \in S} p_i}{n - 1} [M - 1 - \sum_{i \in S} p_i \ge 0]$$

直接计算不行，考虑折半搜索。使用范德蒙德恒等式：

$$\binom{a + b}{n} = \sum_{i = 0}^{n} \binom{a}{i} \binom{b}{n - i}$$

用到这题里就是：
$$
\begin {align*}
& (-1)^{\vert S \vert} \binom{M - 1 - \sum_{i \in S} p_i}{n - 1} [M - 1 - \sum_{i \in S} p_i \ge 0] \\
= & (-1)^{\vert L \vert + \vert R \vert} [M - 1 - \sum_{i \in S} p_i \ge 0] \times \sum_{i = 0}^{n - 1} \binom{M - 1 - \sum_{i \in L} p_i}{n - 1 - i} \binom{- \sum_{i \in R} p_i}{i}
\end {align*}
$$
那么我们左边、右边分别预处理组合数，然后 2 - pointers 合并即可。时间复杂度 $O(2^{\frac{n}{2}} n)$。

## 代码实现

```cpp
#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn = 32, maxm = 1 << (maxn >> 1), mod = 1e9 + 7;
int T, n, A, B, k, l, p[maxn + 3], inv[maxn + 3], s[maxn + 3];
ll m;

struct thing {
	ll fi;
	int se[maxn + 3];
	friend bool operator < (const thing &a, const thing &b) {
		return a.fi < b.fi;
	}
} a[maxm + 3], b[maxm + 3];

inline int func(const int &x) {
	return x < mod ? x : x - mod;
}

void prework(int n) {
	inv[1] = 1;
	for (int i = 2; i <= n; i++) {
		inv[i] = 1ll * (mod - mod / i) * inv[mod % i] % mod;
	}
}

int main() {
	prework(maxn);
	scanf("%d", &T);
	while (T --> 0) {
		scanf("%d", &n);
		ll sum = 0;
		for (int i = 1; i <= n; i++) {
			scanf("%d", &p[i]);
			sum += p[i] + 1;
		}
		m = (sum >> 1);
		A = n >> 1, B = n - A;
		k = l = 0;
		int ans = 0;
		for (int msk = 0; msk < 1 << A; msk++) {
			int y = 1;
			ll z = 0;
			for (int i = 1; i <= A; i++) {
				if (msk >> (i - 1) & 1) {
					y = mod - y, z += p[i];
				}
			}
			a[++k].fi = m - 1 - z;
			int x = func((m - 1 - z) % mod + mod);
			a[k].se[0] = y;
			for (int i = 1; i < n; i++) {
				a[k].se[i] = 1ll * a[k].se[i - 1] * (x - i + 1 + mod) % mod * inv[i] % mod;
			}
		}
		for (int msk = 0; msk < 1 << B; msk++) {
			int y = 1;
			ll z = 0;
			for (int i = 1; i <= B; i++) {
				if (msk >> (i - 1) & 1) {
					y = mod - y, z += p[i + A];
				}
			}
			b[++l].fi = -z;
			int x = func((-z) % mod + mod);
			b[l].se[0] = y;
			for (int i = 1; i < n; i++) {
				b[l].se[i] = 1ll * b[l].se[i - 1] * (x - i + 1 + mod) % mod * inv[i] % mod;
			}
		}
		sort(a + 1, a + k + 1);
		sort(b + 1, b + l + 1);
		int p = l;
		for (int i = 0; i < n; i++) {
			s[i] = 0;
		}
		for (int i = 1; i <= k; i++) {
			while (p && a[i].fi + b[p].fi >= 0) {
				for (int j = 0; j < n; j++) {
					s[j] = func(s[j] + b[p].se[j]);
				}
				p--;
			}
			for (int j = 0; j < n; j++) {
				ans = (ans + 1ll * a[i].se[j] * s[n - j - 1]) % mod;
			}
		}
		printf("%d\n", ans);
	}
	return 0;
}
```