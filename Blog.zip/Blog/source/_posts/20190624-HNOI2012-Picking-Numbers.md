---
title: 「HNOI 2012」集合选数（动态规划）
date: 2019-06-24 00:00:01
mathjax: true
tags:
	- 动态规划

---

# 题目大意
从集合 $\{ 1, 2, \cdots, n \}$ 中选出一个子集，满足其中不存在两个数互相是两倍或三倍关系。求选的方案总数$\bmod 10^9 + 1$ 的结果。

数据范围：$n \le 10^5$。

<!--more-->

# 思路分析
Yet another problem about independent set.

我们把数视作结点，矛盾视作边，那么发现所有矛盾形成了多个网格图，且行数不超过 $17$，列数不超过 $11$。于是直接 DP，然后再相乘即可。

时间复杂度 $O(17 \times 11 \times 2^{11})$。

# 代码实现
```cpp
#include <cstdio>
#include <algorithm>
using namespace std;

const int maxn = 1e5, maxh = 17, maxw = 11, maxs = 1 << maxw, mod = 1e9 + 1;
int n, pw2[maxh + 3], pw3[maxw + 3], h, w, a[maxh + 3][maxw + 3], dp[maxh + 3][maxw + 3][maxs + 3];
bool vis[maxn + 3];

void prework() {
	pw2[0] = pw3[0] = 1;
	for (int i = 1; i <= maxh; i++) {
		pw2[i] = pw2[i - 1] * 2;
	}
	for (int i = 1; i <= maxw; i++) {
		pw3[i] = pw3[i - 1] * 3;
	}
}

void upd(int &x, int y) {
	x += y, x < mod ? 0 : x -= mod;
}

int solve(int x) {
	for (int i = 1; i <= h; i++) {
		for (int j = 1; j <= w; j++) {
			a[i][j] = 0;
		}
	}
	h = w = 0;
	for (int i = 0; pw2[i] * x <= n; i++) {
		h = max(h, i + 1);
		for (int j = 0; pw2[i] * pw3[j] * x <= n; j++) {
			w = max(w, j + 1);
			a[i + 1][j + 1] = pw2[i] * pw3[j] * x;
			vis[pw2[i] * pw3[j] * x] = true;
		}
	}
	dp[0][w][0] = 1;
	for (int msk = 1; msk < 1 << w; msk++) {
		dp[0][w][msk] = 0;
	}
	for (int i = 1; i <= h; i++) {
		for (int msk = 0; msk < 1 << w; msk++) {
			dp[i][0][msk] = dp[i - 1][w][msk];
		}
		for (int j = 1; j <= w; j++) {
			for (int msk = 0; msk < 1 << w; msk++) {
				dp[i][j][msk] = 0;
			}
			for (int msk = 0; msk < 1 << w; msk++) {
				if (!dp[i][j - 1][msk]) continue;
				upd(dp[i][j][msk & (((1 << w) - 1) ^ (1 << (j - 1)))], dp[i][j - 1][msk]);
				if (a[i][j] && (~msk >> (j - 1) & 1) && (j == 1 || (~msk >> (j - 2) & 1))) {
					upd(dp[i][j][msk | (1 << (j - 1))], dp[i][j - 1][msk]);
				}
			}
		}
	}
	int ans = 0;
	for (int msk = 0; msk < 1 << w; msk++) {
		upd(ans, dp[h][w][msk]);
	}
	return ans;
}

int main() {
	prework();
	scanf("%d", &n);
	int ans = 1;
	for (int i = 1; i <= n; i++) if (!vis[i]) {
		ans = 1ll * ans * solve(i) % mod;
	}
	printf("%d\n", ans);
	return 0;
}
```