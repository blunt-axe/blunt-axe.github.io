---
title: 「BZOJ 3580」冒泡排序（排序 + 二分）
date: 2019-07-03 00:00:01
mathjax: true
tags:
	- 排序
	- 二分

---

# 题目大意
[「BZOJ 3580」冒泡排序](https://www.lydsy.com/JudgeOnline/problem.php?id=3580)

对于长度为 $n$ 的排列 $a$，给定如下的冒泡排序的代码：

```cpp
for (int i = 1; i < n; i++) {
	for (int j = 1; j <= n - i; j++) {
		if (a[j] > a[j + 1]) {
			swap(a[j], a[j + 1]);
		}
	}
}
```

问第 $k$ 次 swap 操作过后的 $a$。

数据范围：$n \le 10^6$。

<!--more-->

# 思路分析
对于每个位置记在它前面大于它的数的个数 $c_i$。我们先计算出第 $k$ 次操作以前总共进行了几轮完整的冒泡。考虑二分答案 $x$，我们要计算 $x$ 轮冒泡之后的 swap 次数。我们发现每一轮，如果某个数前面有比它大的数，那么这个数肯定会向前挪动一步；否则它就不会向前挪动了。而对于每一个数，向前挪动一次就代表 swap 一次。所以，$x$ 轮以后第 $i$ 个数的移动次数就是 $\min \{ x, c_i \}$，总移动次数就是 $\sum_i \min \{ x, c_i \}$。

我们二分出了总共进行了几轮完整的冒泡，接下来只要处理剩下的半轮冒泡即可。考虑先解出若干轮完整冒泡后的数列，假设轮数是 $x$。那么，对于 $c_i \ge x$ 的时候，$a_i$ 会被挪到 $a_{i - c_i}$ 处；对于剩下的所有 $c_i < x$ 的数，我们发现它们之间的相对顺序已经被排好了，我们只要在当前还没有数的位置中从小到大地填入这些数即可。对于剩下的半轮冒泡，我们直接模拟即可。这样的总时间复杂度就是 $O(n \log n)$，可以通过本题。

# 代码实现
```cpp
#include <cstdio>
#include <algorithm>
using namespace std;

typedef long long ll;
const int maxn = 1e6;
int n, a[maxn + 3], b[maxn + 3], c[maxn + 3], d[maxn + 3], m, t[maxn + 3];
ll k;

void add(int x) {
	for (int i = x; i; i ^= i & -i) {
		b[i]++;
	}
}

int sum(int x) {
	int y = 0;
	for (int i = x; i <= n; i += i & -i) {
		y += b[i];
	}
	return y;
}

ll solve(int x) {
	ll y = 0;
	for (int i = 1; i <= n; i++) {
		y += min(c[i], x);
	}
	return y;
}

int main() {
	scanf("%d %lld", &n, &k);
	ll s = 0;
	for (int i = 1; i <= n; i++) {
		scanf("%d", &a[i]);
		c[i] = sum(a[i]);
		add(a[i]);
		s += c[i];
	}
	if (k > s) {
		puts("Impossible!");
		return 0;
	}
	int l = 0, r = n, mid;
	while (l < r) {
		mid = (l + r + 1) / 2;
		if (solve(mid) <= k) {
			l = mid;
		} else {
			r = mid - 1;
		}
	}
	k -= solve(l);
	for (int i = 1; i <= n; i++) {
		if (c[i] >= l) {
			d[i - l] = a[i];
		} else {
			t[++m] = a[i];
		}
	}
	sort(t + 1, t + m + 1);
	for (int i = 1, p = 1; i <= n; i++) {
		if (!d[i]) {
			d[i] = t[p++];
		} 
	}
	for (int i = 1; k && i < n; i++) {
		if (d[i] > d[i + 1]) {
			swap(d[i], d[i + 1]), k--;
		}
	}
	for (int i = 1; i <= n; i++) {
		printf("%d%c", d[i], " \n"[i == n]);
	}
	return 0;
}
```