---
title: 「NOI 2018」情报中心（线段树 + 虚树）
date: 2019-10-28 00:00:00
mathjax: true
tags:
	- 线段树
	- 虚树
---

![](/images/20191028-NOI2018-Intelligence-Center.png)

<!--more-->

# 题目描述

[「NOI 2018」情报中心（LOJ 2722）](https://loj.ac/problem/2722)

给定一棵 $n$ 个点的树，第 $i$ 条边有权值 $c_i$。有 $m$ 条路径，第 $i$ 条路径有权值 $v_i$。求从 $m$ 条路径中选出两条**至少有一条边相交**的路径，得到的 $链并上的边权和 − 两条链的总费用$ 的最大值​。

数据范围：$\sum{n} \le 10^6, \sum {m} \le 2 \times 10^6, 0 \le c_i \le 10^9, 0 \le v_i \le 10^{10} \times n$。

提示：分两条路径的 LCA 相同或不同讨论。

# 思路分析

## 第一部分

发现如果两条路径的 LCA 不同，那么它们的交一定是直上直下的一段。

![](/images/20191028-NOI2018-Intelligence-Center-1.jpg)

如上图所示，我们考虑红色和蓝色两条路径。这两条路径形成的权值为：$两条链的总长度 - 两条链的总费用 - (红点到根的距离 - 绿点到根的距离)$。

我们考虑枚举红点，并同时维护经过红点的所有路径。具体地，我们对每个点 $x$ 维护 $f(x, y)$ 表示所有经过点 $x$ 的、LCA 为 $y$ 的路径中，$长度 - 费用$ 的最大值。这样，我们求出 $f(x)$ 后，就可以用 $\max_{i, j}\lbrace f(x, i) + f(x, j) + \max\lbrace d(i), d(j)\rbrace \rbrace - d(x)$ 更新答案，其中 $d(x)$ 表示点 $x$ 到根的距离。当然，我们发现答案要求的是最大值，所以上式就可以简化为：$\max_{i, j}\lbrace f(x, i) + f(x, j) + d(i)\rbrace - d(x)$。

我们考虑使用**下标为结点深度**的线段树来维护这样一个过程。在遍历到某个点时，我们要加入所有以它为端点的路径；在 DFS 完某个点儿子时，我们要将儿子的 $f$ 数组合并到自己身上；在某个点从 DFS 栈中出去时，我们要删除所有 LCA 恰好为它的路径。也就是说，我们只需要支持单点更新，单点清除，以及合并。在修改 / 合并过程进行的同时，我们要进行答案的更新。注意红点的下方必须分叉，所以**加入某个子树之前需要先更新答案**。对于修改，我们用新加入的链和原来线段树中的点更新答案；在合并两棵树 $x, y$ 的时候，我们在合并之前用 $(\text{ls}(x), \text{rs}(y))$ 以及 $(\text{rs}(x), \text{ls}(y))$ 来更新答案即可。具体实现见代码。

## 第二部分

如果两条路径的 LCA 相同，那么它们的交一定过 LCA。

![](https://wx1.sinaimg.cn/mw690/0060lm7Tly1fukvljd5ipj30bf06twev.jpg)

如上图，这两条路径的权值为 $\frac{两条链的总长度 + 蓝点距离 + 绿点距离 - 两条链的总费用 \times 2}{2}$。

我们首先假设所有链的 LCA 都是根结点。我们还是考虑枚举红点。对于某个蓝点，我们给它对应的绿点赋值为 $链长 - 费用 + 蓝点深度$。这样，对于某个红点下面的两个在不同子树内部的蓝点就可以用 $\frac{绿点权值和 + 绿点距离 - 红点深度 \times 2}{2}$ 来更新答案了。

这就相当于对于每个红点子树内的蓝点求绿点的最远点对。有一个性质是如果边权为正，那么两个集合的最远点对的端点一定是某个集合中最远点对的端点。于是我们合并最远点对即可。注意到红点下面还是需要分叉，处理的方法参考第一部分。

那么如果我们有多个 LCA 该怎么办呢？对每个 LCA 建虚树再跑上面的算法即可。

这样问题就得到了全面的解决，时间复杂度 $O(n \log n)$。

~~这道题目，无疑是善良的出题人无私的馈赠。不仅巧妙考察了选手二合一的思维能力，还对选手的手指速度有着极高的要求。无论是 NOI 测试还是平时练习，这都是一道一个顶俩的题目。出题人相信，这道美妙的题目，可以给拼搏于逐梦之路上的你，提供一个有力的援助。~~

# 代码实现

```cpp
#include <bits/stdc++.h>
#define mid ((l + r) >> 1)
using namespace std;

typedef long long ll;
const int maxn = 1e5, logn = 16;
const ll inf = 1e18, lim = 1e17;
int T, n, m, tot, dfn[maxn + 3], mn[logn + 3][maxn + 3], l_2[maxn + 3];
int num[maxn + 3], dep[maxn + 3], a[maxn + 3], b[maxn + 3], c[maxn + 3];
ll d_v[maxn + 3], val[maxn + 3], dist[maxn + 3];
vector<int> G[maxn + 3];

void dfs(int u) {
	dfn[u] = ++tot, mn[0][tot] = u;
	for (int i = 0, v; i < G[u].size(); i++) {
		v = G[u][i];
		dep[v] = dep[u] + 1;
		d_v[v] = d_v[u] + num[v];
		dfs(v);
		mn[0][++tot] = u;
	}
}

void prework() {
	for (int i = 2; i <= tot; i++) {
		l_2[i] = l_2[i >> 1] + 1;
	}
	for (int k = 1; 1 << k <= tot; k++) {
		for (int i = 1, j = (1 << (k - 1)) + 1; i <= tot - (1 << k) + 1; i++, j++) {
			mn[k][i] = min(mn[k - 1][i], mn[k - 1][j]);
		}
	}
}

int lca(int x, int y) {
	x = dfn[x], y = dfn[y];
	if (x > y) swap(x, y);
	int t = l_2[y - x + 1];
	return min(mn[t][x], mn[t][y - (1 << t) + 1]);
}

namespace sub_1 {
	const int maxm = 4e6;
	int tot, rt[maxn + 3];
	ll ans, res;
	vector<int> S[maxn + 3];

	struct node {
		int ls, rs;
		ll f, g;
	} tr[maxm + 3];

	void maintain(int x) {
		tr[x].f = max(tr[tr[x].ls].f, tr[tr[x].rs].f);
		tr[x].g = max(tr[tr[x].ls].g, tr[tr[x].rs].g);
	}

	void modify(int &x, int l, int r, int y, ll f, ll g, bool type) {
		if (!x) {
			x = ++tot, tr[x].ls = tr[x].rs = 0;
			tr[x].f = tr[x].g = -inf;
		}
		if (l == r) {
			if (type) {
				tr[x].f = f, tr[x].g = g;
			} else {
				tr[x].f = max(tr[x].f, f);
				tr[x].g = max(tr[x].g, g);
			}
			return;
		}
		if (y <= mid) {
			res = max(res, f + tr[tr[x].rs].g);
			modify(tr[x].ls, l, mid, y, f, g, type);
		} else {
			res = max(res, tr[tr[x].ls].f + g);
			modify(tr[x].rs, mid + 1, r, y, f, g, type);
		}
		maintain(x);
	}

	int merge(int x, int y) {
		if (!x || !y) {
			return x | y;
		}
		res = max(res, tr[tr[x].ls].f + tr[tr[y].rs].g);
		res = max(res, tr[tr[y].ls].f + tr[tr[x].rs].g);
		tr[x].ls = merge(tr[x].ls, tr[y].ls);
		tr[x].rs = merge(tr[x].rs, tr[y].rs);
		tr[x].f = max(tr[x].f, tr[y].f);
		tr[x].g = max(tr[x].g, tr[y].g);
		return x;
	}

	void dfs(int u) {
		for (int i = 0; i < S[u].size(); i++) {
			int x = S[u][i];
			if (u == c[x]) continue;
			res = -inf;
			modify(rt[u], 0, n - 1, dep[c[x]], dist[x] - val[x], dist[x] - val[x] + d_v[c[x]], false);
			ans = max(ans, res - d_v[u]);
		}
		for (int i = 0, v; i < G[u].size(); i++) {
			v = G[u][i];
			dfs(v);
			modify(rt[v], 0, n - 1, dep[u], -inf, -inf, true);
			res = -inf;
			rt[u] = merge(rt[u], rt[v]);
			ans = max(ans, res - d_v[u]);
		}
	}

	ll main() {
		for (int i = 1; i <= n; i++) {
			vector<int>().swap(S[i]);
			rt[i] = 0;
		}
		ans = -inf;
		for (int i = 1; i <= m; i++) {
			S[a[i]].push_back(i);
			S[b[i]].push_back(i);
		}
		tot = 0;
		tr[0].f = -inf, tr[0].g = -inf;
		dfs(1);
		return ans;
	}
}

namespace sub_2 {
	int tot, k, top, st[maxn + 3], vis[maxn + 3];
	ll num[maxn + 3], ans;
	vector<int> S[maxn + 3], T[maxn + 3], V[maxn + 3];
	pair<int, int> pr[maxn * 2 + 3];

	struct point {
		int x; ll w;
		point(int x = 0, ll w = 0): x(x), w(w) {}
	};

	struct diameter {
		point a, b; ll w;
		diameter(point a = point(), point b = point(), ll w = -inf): a(a), b(b), w(w) {}
		friend bool operator < (const diameter &x, const diameter &y) {
			return x.w < y.w || (x.w == y.w && !x.a.x);
		}
	} f[maxn + 3];

	void clear(int x) {
		if (vis[x] != tot) {
			vis[x] = tot;
			vector<int>().swap(T[x]);
			vector<int>().swap(V[x]);
		}
	}

	void add(int u, int v) {
		clear(u), clear(v);
		T[u].push_back(v);
	}

	ll get_dist(int x, int y) {
		return d_v[x] + d_v[y] - d_v[lca(x, y)] * 2;
	}

	diameter func(point a, point b, ll x, bool type) {
		if (!a.x || !b.x) return point(!a.x ? b : a);
		diameter ret = diameter(a, b, (a.w + b.w + get_dist(a.x, b.x)) / 2);
		if (type) ans = max(ans, ret.w - x);
		return ret;
	}

	diameter merge(diameter x, diameter y, ll z) {
		diameter ret;
		ret = max(ret, func(x.a, y.a, z, true));
		ret = max(ret, func(x.a, y.b, z, true));
		ret = max(ret, func(x.b, y.a, z, true));
		ret = max(ret, func(x.b, y.b, z, true));
		ret = max(ret, max(x, y));
		return ret;
	}

	void dfs(int u) {
		f[u] = diameter();
		for (int i = 0, x, y; i < V[u].size(); i++) {
			x = V[u][i], y = u ^ a[x] ^ b[x];
			point p = point(y, num[x] + d_v[u]);
			f[u] = merge(f[u], func(p, p, 0, false), d_v[u]);
		}
		for (int i = 0, v; i < T[u].size(); i++) {
			v = T[u][i], dfs(v);
			f[u] = merge(f[u], f[v], d_v[u]);
		}
	}

	ll main() {
		for (int i = 1; i <= n; i++) {
			vector<int>().swap(S[i]);
			vis[i] = 0;
		}
		for (int i = 1; i <= m; i++) {
			S[c[i]].push_back(i);
		}
		tot = 0, ans = -inf;
		for (int i = 1; i <= n; i++) {
			k = 0;
			for (int j = 0; j < S[i].size(); j++) {
				int x = S[i][j];
				pr[++k] = make_pair(dfn[a[x]], a[x]);
				pr[++k] = make_pair(dfn[b[x]], b[x]);
			}
			sort(pr + 1, pr + k + 1);
			top = 0, st[++top] = i;
			++tot, clear(i);
			for (int j = 1, x, y; j <= k; j++) {
				x = pr[j].second;
				if (x == st[top]) continue;
				y = lca(x, st[top]);
				if (y != st[top]) {
					while (top > 1 && dfn[y] < dfn[st[top - 1]]) {
						add(st[top - 1], st[top]), top--;
					}
					if (dfn[y] > dfn[st[top - 1]]) {
						add(y, st[top]);
						st[top] = y;
					} else {
						add(y, st[top]);
						top--;
					}
				}
				st[++top] = x;
			}
			for (int j = 1; j < top; j++) {
				add(st[j], st[j + 1]);
			}
			for (int j = 0; j < S[i].size(); j++) {
				int x = S[i][j];
				V[a[x]].push_back(x), V[b[x]].push_back(x);
				num[x] = dist[x] - val[x] * 2;
			}
			for (int j = 0, v; j < T[i].size(); j++) {
				v = T[i][j], dfs(v);
			}
			for (int j = 0; j < S[i].size(); j++) {
				int x = S[i][j];
			}
		}
		return ans;
	}
}

void settings() {
#ifdef ONLINE_JUDGE
	freopen("center.in", "r", stdin);
	freopen("center.out", "w", stdout);
#endif
}

int main() {
	settings();
	scanf("%d", &T);
	while (T --> 0) {
		scanf("%d", &n);
		tot = 0;
		for (int i = 1; i <= n; i++) {
			vector<int>().swap(G[i]);
		}
		for (int i = 1, u, v, w; i < n; i++) {
			scanf("%d %d %d", &u, &v, &w);
			G[u].push_back(v), num[v] = w;
		}
		dfs(1);
		prework();
		scanf("%d", &m);
		for (int i = 1; i <= m; i++) {
			scanf("%d %d %lld", &a[i], &b[i], &val[i]);
			c[i] = lca(a[i], b[i]);
			dist[i] = d_v[a[i]] + d_v[b[i]] - d_v[c[i]] * 2;
		}
		ll ans = max(sub_1::main(), sub_2::main());
		if (ans < -lim) {
			puts("F");
		} else {
			printf("%lld\n", ans);
		}
	}
	return 0;
}
```

