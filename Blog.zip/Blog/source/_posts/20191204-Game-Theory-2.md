---
title: 「专题选做」博弈论题目选做 2
date: 2019-12-04 00:00:00
mathjax: true
tags:
	- 专题选做
	- 博弈论
	- 线段树
---

# Sharti

[「Codeforces 494E」Sharti](https://codeforces.com/contest/494/problem/E)

## 题目描述

$n \times n$ 的网格，给定 $m$ 个矩形，它们的并是白色的，剩下的格子是黑色的。两人博弈，每次可以选择一个边长不超过 $k$ 的正方形满足它的右下角是白色，然后反转这个正方形的颜色。不能操作者输，问先手是否必胜。

数据范围：$m \le 5 \times 10^4, k \le n \le 10^9$。

<!--more-->

## 思路分析

介绍一个翻硬币的模型：给定一排硬币，每次选择一个右端点正面朝上的区间反转，不能操作者输。那么整个局面的 sg 值等于所有正面朝上的硬币单独存在时 sg 值的异或和。证明是考虑另一个问题：本来正面朝上的硬币处有棋子，每次选择一个右端点有棋子的区间然后拿掉右端点的一个棋子，并给其他点加上一个棋子。这两个问题是等价的，因为一个点有两个棋子时它们 sg 值为 $0$，就可以拿掉它们。

这个模型放到这个题里照样成立，所以我们考虑每个白格单独存在时的 sg 值。考虑打表：

```plain
1 1 1 1 1 1 1 1
1 2 1 2 1 2 1 2
1 1 1 1 1 1 1 1
1 2 1 2 1 2 1 2
1 1 1 1 1 1 1 1
1 2 1 2 1 2 1 2
1 1 1 1 1 1 1 1
1 2 1 2 1 2 1 2
---------------
1 1 1 1 1 1 1 1
1 2 1 2 1 2 1 2
1 1 1 1 1 1 1 1
1 2 1 4 1 2 1 4
1 1 1 1 1 1 1 1
1 2 1 2 1 2 1 2
1 1 1 1 1 1 1 1
1 2 1 4 1 2 1 4
```

发现 $k = 2, 3$ 时 sg 值都是上面的表，$k = 4, 5, 6, 7$ 时 sg 值都是下面的表。所以可以猜测表和不超过 $k$ 的最大 $2$ 的幂次有关。记 $b$ 表示满足 $2^x \le k$ 的最大 $x$，那么有：
$$
\text{sg}(x, y) = 2^{\min\{\text{lowbit}(x), \text{lowbit}(y), b\}}
$$
考虑对于每个 $2^i$ 分别计算。发现我们最后只要求矩形的面积并，考虑线段树维护两个值：$\text{cov(x)}, \text{ans(x)}$。每次区间 $\pm 1$ 时，我们找出区间对应的 $O(\log n)$ 个结点把它们的 $\text{cov}(x) \pm 1$。然后对于每个点，都有：
$$
\text{ans}(x) = \begin{cases}
\text{len}(x) & (\text{cov}(x) > 0) \\
0 & (\text{cov}(x) = 0 \text{ and } x \text{ is leaf}) \\
\text{ans}(\text{lson(x)}) + \text{ans}(\text{rson(x)}) & (\text{otherwise})
\end {cases}
$$
直接更新即可。时间复杂度 $O(n \log k \log n)$，具体细节见代码。

## 代码实现

```cpp
#include <bits/stdc++.h>
#define mid ((l + r) >> 1)
#define ls (x << 1)
#define rs (ls | 1)
using namespace std;

typedef long long ll;
const int maxn = 1e5, maxm = 1 << 18;
int n, m, k, bit, a[maxn + 3], b[maxn + 3], c[maxn + 3], d[maxn + 3];
int cnt, pos[maxn + 3], tot, cov[maxm + 3], len[maxm + 3], ans[50];

struct event {
	int x, l, r, y;
	friend bool operator < (const event &a, const event &b) {
		return a.x == b.x ? a.y > b.y : a.x < b.x;
	}
} eve[maxn + 3];

void maintain(int x, int l, int r) {
	if (cov[x]) {
		len[x] = pos[r + 1] - pos[l];
	} else if (l == r) {
		len[x] = 0;
	} else {
		len[x] = len[ls] + len[rs];
	}
}

void build(int x, int l, int r) {
	cov[x] = len[x] = 0;
	if (l == r) {
		return;
	}
	build(ls, l, mid);
	build(rs, mid + 1, r);
}

void modify(int x, int l, int r, int lx, int rx, int y) {
	if (l >= lx && r <= rx) {
		cov[x] += y;
		maintain(x, l, r);
		return;
	}
	if (lx <= mid) {
		modify(ls, l, mid, lx, rx, y);
	}
	if (rx > mid) {
		modify(rs, mid + 1, r, lx, rx, y);
	}
	maintain(x, l, r);
}

ll solve() {
	cnt = tot = 0;
	for (int i = 1; i <= m; i++) if (b[i] < d[i]) {
		pos[++cnt] = b[i], pos[++cnt] = d[i];
	}
	if (!cnt) {
		return 0;
	}
	sort(pos + 1, pos + cnt + 1);
	cnt = unique(pos + 1, pos + cnt + 1) - (pos + 1);
	for (int i = 1; i <= m; i++) if (b[i] < d[i]) {
		int l = lower_bound(pos + 1, pos + cnt + 1, b[i]) - pos;
		int r = lower_bound(pos + 1, pos + cnt + 1, d[i]) - (pos + 1);
		eve[++tot].x = a[i], eve[tot].l = l, eve[tot].r = r, eve[tot].y = 1;
		eve[++tot].x = c[i], eve[tot].l = l, eve[tot].r = r, eve[tot].y = -1;
	}
	sort(eve + 1, eve + tot + 1);
	cnt--;
	build(1, 1, cnt);
	ll sum = 0;
	for (int i = 1; i <= tot; i++) {
		sum += 1ll * (eve[i].x - eve[i - 1].x) * len[1];
		modify(1, 1, cnt, eve[i].l, eve[i].r, eve[i].y);
	}
	return sum;
}

int main() {
	scanf("%d %d %d", &n, &m, &k);
	for (int i = 1; i <= m; i++) {
		scanf("%d %d %d %d", &a[i], &b[i], &c[i], &d[i]);
		a[i]--, b[i]--;
	}
	for (bit = 0; 1 << bit <= k; bit++);
	for (int i = 0; i < bit; i++) {
		ans[i] = solve() & 1;
		for (int j = 1; j <= m; j++) {
			a[j] >>= 1, b[j] >>= 1, c[j] >>= 1, d[j] >>= 1;
		}
	}
	int sg = 0;
	for (int i = 0; i < bit; i++) {
		if (ans[i] ^ ans[i + 1]) {
			sg ^= 1 << i;
		}
	}
	if (sg) {
		puts("Hamed");
	} else {
		puts("Malek");
	}
	return 0;
}
```

# Tree-Tac-Toe

[「Codeforces 1110G」Tree-Tac-Toe](https://codeforces.com/problemset/problem/1110/G)

## 题目描述

一棵 $n$ 个点的树，一开始一些点是白色。先手是白色，后手是黑色，每次一个人可以把一个没有颜色的点涂成自己的颜色。出现三个连续的同种颜色时持有该颜色的人就赢了，问最后是谁赢，或平局。

数据范围：$T \le 5 \times 10^4, \sum n \le 10^5$。

## 思路分析

首先我们可以去掉所有白点。考虑下图中的白点：

![](/images/20191204-Game-Theory-2-1.png)

我们把它变成：

![](/images/20191204-Game-Theory-2-2.png)

考虑这样的正确性。注意到 BDEF 这棵子树中谁都不可能赢，所以我们的最优策略是把 B 点变成自己的颜色。假设先手把 B 变成白色，那么如果后手不把 E 变成黑色，那么先手在下一步就能把 B 变成白色，然后他就赢了。也就是说第二步后手一定会把 E 变成黑色。那么剩下的两个点就和原图没有关系了，如果后手选了其中一个点先手把另一个点选掉即可。

接下来考虑没有白点的图。考虑下面两种情况：

![](/images/20191204-Game-Theory-2-3.png)

![](/images/20191204-Game-Theory-2-4.png)

如果一个点度数为 $4$，或者它度数为 $3$ 且有至少两个非叶儿子，那么一定先手必胜。

考虑排出这些情况的图，图中每个点的度数都不超过 $3$，并且度数为 $3$ 的点最多只有 $2$ 个。考虑下面这种情况：

![](/images/20191204-Game-Theory-2-5.png)

即两个度数为 $3$ 的点中间夹着奇数个点，其实它等价于下面的图：

![](/images/20191204-Game-Theory-2-6.png)

即两个白点之间夹着奇数个点。考虑这样的策略：每次选择左边白点向右的第二个点，这样黑点必须填在左边两个白点之间，然后问题就转化成了 $n' = n - 2$ 的子问题。可以证明除了这种情况一定是平局，直接模拟，时间复杂度 $O(n)$。

## 代码实现

```cpp
#include <bits/stdc++.h>
using namespace std;

const int maxn = 2e6;
int T, n, deg[maxn + 3];
vector<int> G[maxn + 3];
char s[maxn + 3];

void clear(int i) {
	vector<int>().swap(G[i]);
	deg[i] = 0;
}

void add(int u, int v) {
	G[u].push_back(v), G[v].push_back(u);
	deg[u]++, deg[v]++;
}

int main() {
	scanf("%d", &T);
	while (T --> 0) {
		scanf("%d", &n);
		for (int i = 1; i <= n; i++) {
			clear(i);
		}
		for (int i = 1, u, v; i < n; i++) {
			scanf("%d %d", &u, &v), add(u, v);
		}
		scanf("%s", s + 1);
		for (int i = 1; i <= n; i++) {
			if (s[i] == 'W') {
				clear(++n), add(i, n);
				clear(++n), add(n - 1, n);
				clear(++n), add(n - 2, n);
			}
		}
		bool flag = false;
		for (int i = 1; i <= n; i++) {
			if (deg[i] >= 4) {
				puts("White");
				flag = true;
				break;
			}
			if (deg[i] == 3) {
				int cnt = 0;
				for (int j = 0; j < 3; j++) {
					cnt += deg[G[i][j]] != 1;
				}
				if (cnt >= 2) {
					puts("White");
					flag = true;
					break;
				}
			}
		}
		if (!flag) {
			int x = 0, y = 0;
			for (int i = 1; i <= n; i++) {
				if (deg[i] == 3) {
					if (!x) {
						x = i;
					} else if (!y) {
						y = i;
					} else {
						exit(1);
					}
				}
			}
			if (x && y && ((n - 4) & 1)) {
				puts("White");
			} else {
				puts("Draw");
			}
		}
	}
	return 0;
}
```

