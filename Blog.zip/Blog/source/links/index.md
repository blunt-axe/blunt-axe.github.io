---
title: 链接
date: 2019-04-01 00:00:00
---

# Online Judges

+ [Luogu](https://www.luogu.org) | [BZOJ](https://lydsy.com) | [UOJ](http://uoj.ac) | [LOJ](https://loj.ac)  
+ [Codeforces](https://codeforces.com) | [Atcoder](https://atcoder.jp) | [Vjudge](https://vjudge.net)

# Tools

+ [OI Wiki](https://oi-wiki.org) | [OIerDb](http://bytew.net/OIer/) | [Ubuntu Pastebin](https://paste.ubuntu.com) | [Graph Editor](https://csacademy.com/app/graph_editor)  
+ [OEIS](https://oeis.org) | [WolframAlpha](https://www.wolframalpha.com) | [Katex Supported Functions](https://katex.org/docs/supported.html)